const fs = require('fs')


// ======= [ System ] ======== \\
global.botName = "Hoshino - MD"
global.botNumber = "6287794585528"
global.ownerName = "Rizki"
global.ownerNumber = "6287794585528"
global.sessionN = "session"

/** info id **/
global.owner = "6287794585528@s.whatsapp.net"
global.idch = "120363313702511471@newsletter"
global.linkCh = "https://whatsapp.com/channel/0029VadfVP5ElagswfEltW0L"
global.namaCh = "Rizki Engine"

/** jika bernilai "true" berarti aktif, dan sebaliknya kalau "false" **/
global.status = true 
global.welcome = false
global.antispam = false
global.autoread = false

/** Thumbanil **/
global.thumbnail = "https://files.catbox.moe/qjjz9k.jpg"

/** sticker watermark **/
global.packname = 'Hoshino - MD'
global.author = 'Rizki'

/** link group atau link channel WhatsApp **/
global.linkch = ''

/** limit user premium dan bukan premium **/
global.gcount = {
    prem : 500,
    user: 15
}

/** limit **/
global.limitCount = 10,

/** message **/
global.mess = {
    group: "ngapain? khusus grup njrr",
    admin: "ngapain? khusus admin njrr",
    owner: "apalah, bukan owner",
    premium: "bukan user premium njrr",
    botadmin: "bot bukan admin",
    limited: "limitmu habis, kembali besok/sore nanti",
    private: "khusus private chat",
    query: "Masukan Query Parameters!",
    url: "Masukan Urls Parameters!",
    wait: "Mohon Tunggu Sebentar!"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
