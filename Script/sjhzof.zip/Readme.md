Halo, Terima Kasih Telah Memakai Script Ini.

Recode: Rizki

Terima Kasih Kepada:

 - 𝐙͢𝐱𝐕 𝐕𝐢͢𝐒𝐢𝚹͢𝐍
 - 𝐓𝐝𝐗
 - KyuuRzy ( Kiuur )
 - devorsixcore
 - dittsans
 - skyzoo
 - Fizzy ( Baileys )
 - ver6core
 - PakTzy
 - Sally ( Fadli )

*Jangan Perjual Belikan Script Ini Karena Saya Share Secara Gratis!!*

[ Dilarang Mengahapus/Ganti Credit Di Atas ]


// ======== [ Cara Penginstalan & Menjalankan ] ======== //

# Install Dependencies

- npm i 
- yarn install

# Menjalankan

- npm start 
- node index.js