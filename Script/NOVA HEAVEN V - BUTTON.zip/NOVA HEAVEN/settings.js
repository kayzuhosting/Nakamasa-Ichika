require("./all/module.js")
const { color } = require('./all/function')
const version = require("@whiskeysockets/baileys/package.json").version
//========== Setting Owner ==========//
global.owner = "6282285899023"
global.namaowner = "Rim Official WA⚡"
global.namaowner2 = "Rim Official WA ⚡"

//======== Setting Bot & Link ========//
global.namabot = "Rim Official WA V - Button" 
global.botname = "Rim Official WA V - Button"
global.namabot2 = "Rim Official WA V - Button V9.0"
global.version = "V - Button Support"
global.foother = "𝙎𝘾𝙍𝙄𝙋𝙏 𝘾𝙍𝙀𝘼𝙏𝙀𝘿 𝘽𝙔  © Rim Official WA"
global.idsaluran = "120363338102578213@newsletter"
global.linkgc = 'https://whatsapp.com/channel/0029VaiLyT45EjxqIAcObu3n'
global.linksaluran = "https://whatsapp.com/channel/0029Vap84RE8KMqfYnd0V41A"
global.linkyt = 'https://www.youtube.com/@rimoffc'
global.linktele = "https://t.me/rimofficial"
global.packname = "Created By Rim Official WA"
global.author = "Rim Official WA"

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false
global.autoreadsw = false
global.owneroff = false
global.antibug = true

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 5500

//========== Setting Foto ===========//

//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.domain = "https://ibzzofficial.panel-riz.me"
global.apikey = "ptla_mlxwE4xbozmGpL9vz7TkBKBNulwgQSOEhm0JvBJ59BQ"
global.capikey = "ptlc_AJPyj5M8tytURmQIyovLKBDZsVmxTdmPTWaef9JXY49"

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = false
global.gopay = false
global.ovo = false
global.qris = fs.readFileSync("./media/qris.jpg")
                             
//=========== Api Domain ===========//
global.zone1 = "c2047082b74a80e5be03959bad59592a"
global.apitoken1 = "Nop2RDsy0Uyh1WHE17CC59aEhen-ZA61MWNrAqVl"
global.tld1 = "digitalserver.biz.id"

//========== Api Domain 2 ==========//
global.zone2 = "a476ffcf9243c44a02220f184da527e8";
global.apitoken2 = "RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ";
global.tld2 = "mypanell.biz.id";
//========== Api Domain 3 ==========//
global.zone3 = "5f4a582dd80c518fb2c7a425256fb491";
global.apitoken3 = "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby";
global.tld3 = "tokopanellku.my.id";
//========== Api Domain 4 ==========//
global.zone4 = "d41a17e101c0f89f0aec609c31137f91";
global.apitoken4 = "miC4wpso1vMcRFR62ZvOFfFd9xTlawvHcXPYZgwi";
global.tld4 = "panellstore.net";

//========= Setting Message =========//
global.msg = {
"error": "ᴇʀʀᴏʀ ᴅɪᴋɪᴛ ɢᴀ ɴɢᴀʀᴜʜ",
"done": "ᴅᴏɴᴇ ᴄɪᴋ", 
"wait": "Nova Bot - By Rim Official, Be Patience", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})