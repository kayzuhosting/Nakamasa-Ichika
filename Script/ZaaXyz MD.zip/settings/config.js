
//𝙎𝘾𝙍𝙄𝙋𝙏 𝙄𝙉𝙄 𝙁𝙍𝙀𝙀 𝙂𝘼 𝘿𝙄𝙅𝙐𝘼𝙇 𝘽𝙀𝙇𝙄𝙆𝘼𝙉
//CREATOR : © PanzzLetus


const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6282285661325" //ganti aja
global.nama = "Zaa" //ganti aja
global.namaowner = "Zaa" 
global.namaBot = "ZaaXyz" 
global.ch = '-' 
global.ownername = "Zaa" 
global.botname = "ZaaXyz" 
global.status = true 
global.foother = "©ZaaXyz" 
global.namach = '+' 
global.idch = '-' // diemin kalau gda
global.namafile = 'ZaaXyz' 
global.yt = '' 
global.themeemoji = '🔥' 
global.packname = "sticker by zaa" 
global.author = "\n\n\n\n\nzaa" 
global.creator = "6283126511272@s.whatsapp.net" 
global.welcome = false
global.autoswview = true //auto status/story view
global.delayPushkontak = 7900
//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "" 
global.ovo = "" 
global.qris = "𝗺𝗶𝗻𝘁𝗮 𝗼𝘄𝗻𝗲𝗿 𝘀𝗮𝗷𝗮 𝗰𝘂𝘆𝘆!!" 
//====== [ THEME URL & URL ] ========//
global.thumb = fs.readFileSync('./zaa.jpeg'); // Buffer Image
global.thumbfurina = 'https://img1.pixhost.to/images/6030/604200711_levvihosting.jpg'
global.thumbnail = 'https://img1.pixhost.to/images/6030/604200711_levvihosting.jpg' 
global.reply = 'https://img1.pixhost.to/images/6030/604200711_levvihosting.jpg' 
global.Url = 'https://ẉ.ceo/zaa' //
global.logodana = "https://img100.pixhost.to/images/667/540082364_skyzopedia.jpg",  
global.logoovo = "https://img100.pixhost.to/images/667/540082774_skyzopedia.jpg",  
//===================== Setting Apikey V1 =========================//
global.domain = 'https://zalplaydoffc.myserver.biz.id'
global.apikey = 'ptla_hS3P2U2OgUicVP1IBG5noRjVBVZE17K2yRcIg2NlDl3'
global.capikey = 'ptlc_r2CcwsPNMrNzex50nnBSHcti9Jx7pD1hlJLZ7MOC8N0'
//===================== Setting Apikey V2 =========================//
global.domain2 = "https://hanzo-hosting-publik.pterodactyl-vvip.my.id"
global.apikey2 = "ptla_ZbBr2eO8jepwKpJ8zNMvHAyx6mTxMUeD3IND7QMzLRO"
global.capikey2 = "ptlc_73mP8JX8pOoxKi7h55obFyOUKmG3e4GTDhuc8Xtq8kL"
//===================== Setting Apikey V3 =========================//
global.domain3 = "https://kenzstore-mujib.zackyoffc.xyz"
global.apikey3 = "ptla_h51ID3CRoGZxwAMA2OAQXSDZ5xUoGGXSBICCEICV8dM"
global.capikey3 = "ptlc_9H4b9yPFtunO8K17xcZzn1wHThwvoO9oyEW3LwIJN4I"
//===================== BIARIN!!!! =========================//
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

// jpm ch isi id nya
global.jpmch1 = "120363395770194330@newsletter"
global.jpmch2 = ""
global.jpmch3 = ""
global.jpmch4 = ""
global.jpmch5 = ""
global.jpmch6 = ""
global.jpmch7 = ""
global.jpmch8 = ""
global.jpmch9 = ""
global.jpmch10 = ""
global.jpmch11 = ""
global.jpmch12 = ""
global.jpmch13 = ""
global.jpmch14 = ""
global.jpmch15 = ""
global.jpmch16 = ""
global.jpmch17 = ""
global.jpmch18 = ""
global.jpmch19 = ""
global.jpmch20 = ""
global.jpmch21 = ""
global.jpmch22 = ""
global.jpmch23 = ""
global.jpmch24 = ""
global.jpmch25 = ""
global.jpmch26 = ""
global.jpmch27 = ""
global.jpmch28 = ""
global.jpmch29 = ""
global.jpmch30 = ""
global.jpmch31 = ""
global.jpmch32 = ""
global.jpmch33 = ""
global.jpmch34 = ""
global.jpmch35 = ""
global.jpmch36 = ""
global.jpmch37 = ""
global.jpmch38 = ""
global.jpmch39 = ""
global.jpmch40 = ""
global.jpmch41 = ""
global.jpmch42 = ""
global.jpmch43 = ""
global.jpmch44 = ""
global.jpmch45 = ""
global.jpmch46 = ""
global.jpmch47 = ""
global.jpmch48 = ""
global.jpmch49 = ""
global.jpmch50 = ""
global.jpmch51 = ""
global.jpmch52 = ""
global.jpmch53 = ""
global.jpmch54 = ""
global.jpmch55 = ""
global.jpmch56 = ""
global.jpmch57 = ""
global.jpmch58 = ""
global.jpmch59 = ""
global.jpmch60 = ""
global.jpmch61 = ""
global.jpmch62 = ""
global.jpmch63 = ""
global.jpmch64 = ""
global.jpmch65 = ""
global.jpmch66 = ""
global.jpmch67 = ""
global.jpmch68 = ""
global.jpmch69 = ""
global.jpmch70 = ""
global.jpmch71 = ""
global.jpmch72 = ""
global.jpmch73 = ""
global.jpmch74 = ""
global.jpmch75 = ""
global.jpmch76 = ""
global.jpmch77 = ""
global.jpmch78 = ""
global.jpmch79 = ""
global.jpmch80 = ""
global.jpmch81 = ""
global.jpmch82 = ""
global.jpmch83 = ""
global.jpmch84 = ""
global.jpmch85 = ""
global.jpmch86 = ""
global.jpmch87 = ""
global.jpmch88 = ""
global.jpmch89 = ""
global.jpmch90 = ""
global.jpmch91 = ""
global.jpmch92 = ""
global.jpmch93 = ""
global.jpmch94 = ""
global.jpmch95 = ""
global.jpmch96 = ""
global.jpmch97 = ""
global.jpmch98 = ""
global.jpmch99 = ""
global.jpmch100 = ""
global.jpmch101 = ""
global.jpmch102 = ""
global.jpmch103 = ""
global.jpmch104 = ""
global.jpmch105 = ""
global.jpmch106 = ""
global.jpmch107 = ""
global.jpmch108 = ""
global.jpmch109 = ""
global.jpmch110 = ""
global.jpmch111 = ""
global.jpmch112 = ""
global.jpmch113 = ""
global.jpmch114 = ""
global.jpmch115 = ""
global.jpmch116 = ""
global.jpmch117 = ""
global.jpmch118 = ""
global.jpmch119 = ""
global.jpmch120 = ""
global.jpmch121 = ""
global.jpmch122 = ""
global.jpmch123 = ""
global.jpmch124 = ""
global.jpmch125 = ""
global.jpmch126 = ""
global.jpmch127 = ""
global.jpmch128 = ""
global.jpmch129 = ""
global.jpmch130 = ""
global.jpmch131 = ""
global.jpmch132 = ""
global.jpmch133 = ""
global.jpmch134 = ""
global.jpmch135 = ""
global.jpmch136 = ""
global.jpmch137 = ""
global.jpmch138 = ""
global.jpmch139 = ""
global.jpmch140 = ""
global.jpmch141 = ""
global.jpmch142 = ""
global.jpmch143 = ""
global.jpmch144 = ""
global.jpmch145 = ""
global.jpmch146 = ""
global.jpmch147 = ""
global.jpmch148 = ""
global.jpmch149 = ""
global.jpmch150 = ""
//~~~~~~~~~ Settings reply ~~~~~~~~~//
global.mess = {
    owner: "𝗧𝗛𝗜𝗦 𝗙𝗘𝗔𝗧𝗨𝗥𝗘 𝗙𝗢𝗥 𝗢𝗪𝗡𝗘𝗥 𝗡𝗢𝗧 𝗙𝗢𝗥 𝗬𝗢𝗨 !",
    prem: "𝗧𝗛𝗜𝗦 𝗙𝗘𝗔𝗧𝗨𝗥𝗘 𝗙𝗢𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗕𝗢𝗧 𝗙𝗢𝗥 𝗬𝗢𝗨 !",
    group: "𝗧𝗛𝗜𝗦 𝗙𝗘𝗔𝗧𝗨𝗥𝗘 𝗙𝗢𝗥 𝗚𝗥𝗢𝗨𝗣 𝗢𝗡𝗟𝗬 !",
    private: "𝗣𝗥𝗜𝗩𝗔𝗧𝗘 𝗖𝗛𝗔𝗧 𝗢𝗡𝗟𝗬 𝗕𝗔𝗕𝗬:𝟯"
}


global.packname = 'zaaxyz' 
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nZaa' 
//~~~~~~~~~~~ DIEMIN ~~~~~~~~~~//
global.pairing = "" // Jangan Di Apa Apain
global.qrcode = "120363395770194330@newsletter" // Jangan Di Apa Apain

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
