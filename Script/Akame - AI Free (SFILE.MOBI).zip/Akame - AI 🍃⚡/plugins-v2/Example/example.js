module.exports = {
    type: 'convert',
    command: ['shorten', 'shortlink', 'shorturl', 'shortenlink'],
    operate: async (context) => {
        const { Kyyhst, m, q, prefix, command, replyURL } = context;
 /*
 
        YOU CODE
 
 
 */
    }
};