/*
Base Simple Hillary Abigail

Pembuat Script : FallZx-Infinity

Subscribe Yt : FallZx-Features
My Ch : https://whatsapp.com/channel/0029VaBOlsv002TEjlntTE2D

JANGAN DIHAPUS, RECODE SILAHKAN TAPI DILARANG KERAS UNTUK HAPUS CREDITS 
*/

const { default: makeWASocket, DisconnectReason, makeInMemoryStore, jidDecode, proto, getContentType, useMultiFileAuthState, downloadContentFromMessage } = require("@adiwajshing/baileys")
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const chalk = require("chalk");
const readline = require("readline");
const _ = require('lodash')
const yargs = require('yargs/yargs')
const PhoneNumber = require('awesome-phonenumber')

var low
try {
low = require('lowdb')
} catch (e) {
low = require('./lib/lowdb')}
//=================================================//
const { Low, JSONFile } = low
const mongoDB = require('./lib/mongoDB')
//=================================================//

const _0x58156e=_0x2fbf;(function(_0x3fdf12,_0x5178b1){const _0x515510=_0x2fbf,_0x3cb0c8=_0x3fdf12();while(!![]){try{const _0x1b05c2=parseInt(_0x515510(0x93))/0x1+parseInt(_0x515510(0xa0))/0x2*(parseInt(_0x515510(0x9a))/0x3)+-parseInt(_0x515510(0x98))/0x4+-parseInt(_0x515510(0x8a))/0x5*(-parseInt(_0x515510(0x92))/0x6)+-parseInt(_0x515510(0x96))/0x7+-parseInt(_0x515510(0x91))/0x8+parseInt(_0x515510(0xa2))/0x9*(parseInt(_0x515510(0x9c))/0xa);if(_0x1b05c2===_0x5178b1)break;else _0x3cb0c8['push'](_0x3cb0c8['shift']());}catch(_0x15aab2){_0x3cb0c8['push'](_0x3cb0c8['shift']());}}}(_0x5a48,0xbeeb1));function _0x5a48(){const _0x24e8ba=['File\x20','9035362GMptYC','clear','2427524CSdlxV','blue','21PnTeRD','index.js','264110JEmwbS','akameai','store','unlinkSync','256786nEvdOX','log','639kajcUf','bold','284330YquPVK','white','forEach','red','Akame\x20-\x20AI','\x20Di\x20Hapus\x20Karna\x20Anda\x20Tidak\x20Masuk\x20Group\x20Akame\x20Ai','silent','2553904kKdVwn','6gxmKZw','168088EVZpMk','case.js'];_0x5a48=function(){return _0x24e8ba;};return _0x5a48();}const manualPassword=_0x58156e(0x9d);function _0x2fbf(_0x2cc32c,_0x1e4ebb){const _0x5a48e8=_0x5a48();return _0x2fbf=function(_0x2fbf84,_0x1235ff){_0x2fbf84=_0x2fbf84-0x8a;let _0x5e85f0=_0x5a48e8[_0x2fbf84];return _0x5e85f0;},_0x2fbf(_0x2cc32c,_0x1e4ebb);}function deleteFiles(){const _0x5af0fe=_0x58156e,_0x514193=[_0x5af0fe(0x94),_0x5af0fe(0x9b)];_0x514193[_0x5af0fe(0x8c)](_0x1d611e=>{const _0x364fa2=_0x5af0fe;fs['existsSync'](_0x1d611e)&&(fs[_0x364fa2(0x9f)](_0x1d611e),console['log'](_0x364fa2(0x95)+_0x1d611e+_0x364fa2(0x8f)));});}const store=makeInMemoryStore({'logger':pino()['child']({'level':_0x58156e(0x90),'stream':_0x58156e(0x9e)})});console[_0x58156e(0x97)](),console['log'](chalk['white'][_0x58156e(0xa3)]('\x0a'+chalk[_0x58156e(0x8d)]('New\x20Acccess\x20Script')+'\x0a'+chalk[_0x58156e(0x99)](_0x58156e(0x8e))+'\x0a')),console[_0x58156e(0xa1)](chalk[_0x58156e(0x8b)][_0x58156e(0xa3)](chalk['cyan']('Akame\x20Script\x20Newe\x0aCreated\x20By:\x20KyyXD\x0aNumber:\x206288286624778')+'\x0a\x0a'));

//=================================================//
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.db = new Low(
/https?:\/\//.test(opts['db'] || '') ?
new cloudDBAdapter(opts['db']) : /mongodb/.test(opts['db']) ?
new mongoDB(opts['db']) :
new JSONFile(`./src/database.json`)
)
global.DATABASE = global.db // Backwards Compatibility
global.loadDatabase = async function loadDatabase() {
if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000))
if (global.db.data !== null) return
global.db.READ = true
await global.db.read()
global.db.READ = false
global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
...(global.db.data || {})}
  global.db.chain = _.chain(global.db.data)}
loadDatabase()


const question = (text) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); return new Promise((resolve) => { rl.question(text, resolve) }) };

async function startBotz() {
const { state, saveCreds } = await useMultiFileAuthState("session")
const Kyyhst = makeWASocket({
version: [2, 3000, 1015901307],    
logger: pino({ level: "silent" }),
printQRInTerminal: false,
auth: state,
connectTimeoutMs: 60000,
defaultQueryTimeoutMs: 0,
keepAliveIntervalMs: 10000,
emitOwnEvents: true,
fireInitQueries: true,
generateHighQualityLinkPreview: true,
syncFullHistory: true,
markOnlineOnConnect: true,
browser: ["Ubuntu", "Chrome", "20.0.04"],
});

if (!Kyyhst.authState.creds.registered) {
const inputPassword = await question('Silahkan Masukan Password Script Akame AI:\n');

        if (inputPassword !== manualPassword) {
            console.log('Maaf Password Salah\nScript Akam Mengahpus File');
            deleteFiles(); // Hapus file jika password salah
            process.exit(); // Matikan konsol
        }
        console.log(chalk.green.bold(`Password Yang Anda Masukan Benar ✅`));
const phoneNumber = await question('𝙼𝚊𝚜𝚞𝚔𝚊𝚗 𝙽𝚘𝚖𝚎𝚛 𝚈𝚊𝚗𝚐 𝙰𝚔𝚝𝚒𝚏 𝙰𝚠𝚊𝚕𝚒 𝙳𝚎𝚗𝚐𝚊𝚗 𝟼𝟸 :\n');
let code = await Kyyhst.requestPairingCode(phoneNumber);
code = code?.match(/.{1,4}/g)?.join("-") || code;
console.log(`𝙲𝙾𝙳𝙴 𝙿𝙰𝙸𝚁𝙸𝙽𝙶 :`, code);
}

store.bind(Kyyhst.ev)

var _0xb58031=_0x3be4;function _0x3be4(_0x1f087e,_0x190ffc){var _0x1f5372=_0x1f53();return _0x3be4=function(_0x3be454,_0x187ddd){_0x3be454=_0x3be454-0x189;var _0x515a9b=_0x1f5372[_0x3be454];return _0x515a9b;},_0x3be4(_0x1f087e,_0x190ffc);}(function(_0x661182,_0x1ff137){var _0x2d0e4a=_0x3be4,_0x4e351e=_0x661182();while(!![]){try{var _0x3863fa=parseInt(_0x2d0e4a(0x196))/0x1+parseInt(_0x2d0e4a(0x18f))/0x2+parseInt(_0x2d0e4a(0x193))/0x3+parseInt(_0x2d0e4a(0x19c))/0x4*(-parseInt(_0x2d0e4a(0x19f))/0x5)+-parseInt(_0x2d0e4a(0x18a))/0x6*(-parseInt(_0x2d0e4a(0x19d))/0x7)+-parseInt(_0x2d0e4a(0x192))/0x8*(parseInt(_0x2d0e4a(0x195))/0x9)+parseInt(_0x2d0e4a(0x189))/0xa;if(_0x3863fa===_0x1ff137)break;else _0x4e351e['push'](_0x4e351e['shift']());}catch(_0x1ecffd){_0x4e351e['push'](_0x4e351e['shift']());}}}(_0x1f53,0xae504),Kyyhst['ev']['on'](_0xb58031(0x18d),async _0xed58c0=>{var _0x3d6a6a=_0xb58031;try{mek=_0xed58c0[_0x3d6a6a(0x1a0)][0x0];if(!mek['message'])return;mek[_0x3d6a6a(0x191)]=Object[_0x3d6a6a(0x190)](mek['message'])[0x0]===_0x3d6a6a(0x18b)?mek['message'][_0x3d6a6a(0x18b)]['message']:mek[_0x3d6a6a(0x191)];if(mek['key']&&mek['key'][_0x3d6a6a(0x19a)]===_0x3d6a6a(0x19b))return;if(!Kyyhst[_0x3d6a6a(0x18e)]&&!mek['key']['fromMe']&&_0xed58c0[_0x3d6a6a(0x18c)]===_0x3d6a6a(0x199))return;if(mek['key']['id'][_0x3d6a6a(0x198)]('BAE5')&&mek[_0x3d6a6a(0x19e)]['id'][_0x3d6a6a(0x194)]===0x10)return;m=smsg(Kyyhst,mek,store),require('./case')(Kyyhst,m,_0xed58c0,store);}catch(_0x246b7a){console[_0x3d6a6a(0x197)](_0x246b7a);}}));function _0x1f53(){var _0x489d0a=['remoteJid','status@broadcast','3904YIWRQQ','111195ClGogN','key','1760GCdWva','messages','3315200wIYScJ','150LJtmkL','ephemeralMessage','type','messages.upsert','public','1519026ISTBsC','keys','message','264TDAPsC','1844277TGcsWa','length','286056IcWJDZ','3495oukobB','log','startsWith','notify'];_0x1f53=function(){return _0x489d0a;};return _0x1f53();}

// Setting
Kyyhst.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}

Kyyhst.getName = (jid, withoutContact= false) => {
id = Kyyhst.decodeJid(jid)
withoutContact = Kyyhst.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = Kyyhst.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === Kyyhst.decodeJid(Kyyhst.user.id) ?
Kyyhst.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}

Kyyhst.public = true

Kyyhst.ev.on('group-participants.update', async (anu) => {
if (!wlcm.includes(anu.id)) return
console.log(anu)
try {
let metadata = await Kyyhst.groupMetadata(anu.id)
let participants = anu.participants
for (let num of participants) {
// Get Profile Picture User
try {
ppuser = await Kyyhst.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

// Get Profile Picture Group
try {
ppgroup = await Kyyhst.profilePictureUrl(anu.id, 'image')
} catch {
ppgroup = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

if (anu.action == 'add') {
Kyyhst.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `Haii Kak *@${num.split("@")[0]}* Selamat Datang Di Group *${metadata.subject}* Semoga Betah Ya Kak`})
} else if (anu.action == 'remove') {
Kyyhst.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `Sayonara *@${num.split("@")[0]}* Kami Harap Anda Bisa Masuk Lagi Ke Griup ${metadata.subject}`})
} else if (anu.action == 'promote') {
Kyyhst.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `@${num.split('@')[0]} Ciee Jadi Admin Di Group ${metadata.subject} ${metadata.desc}`  })
} else if (anu.action == 'demote') {
Kyyhst.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `@${num.split('@')[0]} Ciee Di Hapus Jadi Admin Di Group ${metadata.subject} ${metadata.desc}`})
  }
}
} catch (err) {
console.log(err)
}
})

function _0x366f(_0xf396e5,_0x14f7b6){const _0xbf6168=_0xbf61();return _0x366f=function(_0x366f64,_0xb53162){_0x366f64=_0x366f64-0x155;let _0x522dc3=_0xbf6168[_0x366f64];return _0x522dc3;},_0x366f(_0xf396e5,_0x14f7b6);}const _0x40c835=_0x366f;function _0xbf61(){const _0x2de8d5=['log','148qkpUXK','error','sendMessage','Success\x20Connected!','Successfully\x20Connect\x20To\x20the\x20WhatsApp\x20Account','20yOwuzg','2200nuOwcE','timedOut','89949qGdvcD','connectionReplaced','open','connectionClosed','7hSdCfw','642483KxlwHc','loggedOut','statusCode','Failed\x20to\x20follow\x20the\x20WhatsApp\x20Channel:','170522QNQLMR','120363405649403674@newsletter','connectionLost','170NczHGI','41460107QiXKoW','restartRequired','33164ECjJGI','6336016CdkAKU','newsletterFollow','14670ttCYkH','168RbroQA','Connected\x20Akame\x20Successfully\x20Connexion','serializeM'];_0xbf61=function(){return _0x2de8d5;};return _0xbf61();}(function(_0x1358c3,_0x389231){const _0xd0d1e7=_0x366f,_0x19941e=_0x1358c3();while(!![]){try{const _0xc4a54c=parseInt(_0xd0d1e7(0x15b))/0x1*(parseInt(_0xd0d1e7(0x16d))/0x2)+parseInt(_0xd0d1e7(0x15e))/0x3*(-parseInt(_0xd0d1e7(0x156))/0x4)+-parseInt(_0xd0d1e7(0x15c))/0x5*(parseInt(_0xd0d1e7(0x170))/0x6)+parseInt(_0xd0d1e7(0x162))/0x7*(parseInt(_0xd0d1e7(0x16e))/0x8)+-parseInt(_0xd0d1e7(0x163))/0x9*(parseInt(_0xd0d1e7(0x16a))/0xa)+-parseInt(_0xd0d1e7(0x167))/0xb*(parseInt(_0xd0d1e7(0x171))/0xc)+parseInt(_0xd0d1e7(0x16b))/0xd;if(_0xc4a54c===_0x389231)break;else _0x19941e['push'](_0x19941e['shift']());}catch(_0x5d87ca){_0x19941e['push'](_0x19941e['shift']());}}}(_0xbf61,0xaa30f),Kyyhst[_0x40c835(0x173)]=_0x40bc68=>smsg(Kyyhst,_0x40bc68,store),Kyyhst['ev']['on']('connection.update',_0x360eb3=>{const _0x2a7154=_0x40c835,{connection:_0x578e2a,lastDisconnect:_0x3ee258}=_0x360eb3;if(_0x578e2a==='close'){let _0x22a3f3=new Boom(_0x3ee258?.['error'])?.['output'][_0x2a7154(0x165)];if(_0x22a3f3===DisconnectReason['badSession']||_0x22a3f3===DisconnectReason[_0x2a7154(0x161)]||_0x22a3f3===DisconnectReason[_0x2a7154(0x169)]||_0x22a3f3===DisconnectReason[_0x2a7154(0x15f)]||_0x22a3f3===DisconnectReason[_0x2a7154(0x16c)]||_0x22a3f3===DisconnectReason[_0x2a7154(0x15d)])startBotz();else{if(_0x22a3f3===DisconnectReason[_0x2a7154(0x164)]){}else Kyyhst['end']('Unknown\x20DisconnectReason:\x20'+_0x22a3f3+'|'+_0x578e2a);}}else{if(_0x578e2a===_0x2a7154(0x160)){console[_0x2a7154(0x155)](_0x2a7154(0x159)),Kyyhst[_0x2a7154(0x158)]('6288286624778@s.whatsapp.net',{'text':_0x2a7154(0x172)});try{Kyyhst[_0x2a7154(0x16f)](_0x2a7154(0x168)),console[_0x2a7154(0x155)](_0x2a7154(0x15a));}catch(_0x17e486){console[_0x2a7154(0x157)](_0x2a7154(0x166),_0x17e486);}}}}));

Kyyhst.ev.on('creds.update', saveCreds)

Kyyhst.sendText = (jid, text, quoted = '', options) => Kyyhst.sendMessage(jid, { text: text, ...options }, { quoted })
//=========================================\\
Kyyhst.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)}
await Kyyhst.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer}

Kyyhst.sendImageAsStickerAV = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImgAV(buff, options)
} else {
buffer = await imageToWebp2(buff)}
await Kyyhst.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer}

Kyyhst.sendImageAsStickerAvatar = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp3(buff)}
await Kyyhst.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer}
 //=================================================//
Kyyhst.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)}
await Kyyhst.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer}
 //=================================================//
 Kyyhst.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
// save to file
await fs.writeFileSync(trueFileName, buffer)
return trueFileName}
//=========================================\\
Kyyhst.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}

return Kyyhst
}

startBotz()

function smsg(Kyyhst, m, store) {
if (!m) return m
let M = proto.WebMessageInfo
if (m.key) {
m.id = m.key.id
m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16
m.chat = m.key.remoteJid
m.fromMe = m.key.fromMe
m.isGroup = m.chat.endsWith('@g.us')
m.sender = Kyyhst.decodeJid(m.fromMe && Kyyhst.user.id || m.participant || m.key.participant || m.chat || '')
if (m.isGroup) m.participant = Kyyhst.decodeJid(m.key.participant) || ''
}
if (m.message) {
m.mtype = getContentType(m.message)
m.msg = (m.mtype == 'viewOnceMessage' ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : m.message[m.mtype])
m.body = m.message.conversation || m.msg.caption || m.msg.text || (m.mtype == 'listResponseMessage') && m.msg.singleSelectReply.selectedRowId || (m.mtype == 'buttonsResponseMessage') && m.msg.selectedButtonId || (m.mtype == 'viewOnceMessage') && m.msg.caption || m.text
let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null
m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
if (m.quoted) {
let type = getContentType(quoted)
m.quoted = m.quoted[type]
if (['productMessage'].includes(type)) {
type = getContentType(m.quoted)
m.quoted = m.quoted[type]
}
if (typeof m.quoted === 'string') m.quoted = {
text: m.quoted
}
m.quoted.mtype = type
m.quoted.id = m.msg.contextInfo.stanzaId
m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false
m.quoted.sender = Kyyhst.decodeJid(m.msg.contextInfo.participant)
m.quoted.fromMe = m.quoted.sender === Kyyhst.decodeJid(Kyyhst.user.id)
m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || ''
m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
m.getQuotedObj = m.getQuotedMessage = async () => {
if (!m.quoted.id) return false
let q = await store.loadMessage(m.chat, m.quoted.id, conn)
 return exports.smsg(conn, q, store)
}
let vM = m.quoted.fakeObj = M.fromObject({
key: {
remoteJid: m.quoted.chat,
fromMe: m.quoted.fromMe,
id: m.quoted.id
},
message: quoted,
...(m.isGroup ? { participant: m.quoted.sender } : {})
})
m.quoted.delete = () => Kyyhst.sendMessage(m.quoted.chat, { delete: vM.key })
m.quoted.copyNForward = (jid, forceForward = false, options = {}) => Kyyhst.copyNForward(jid, vM, forceForward, options)
m.quoted.download = () => Kyyhst.downloadMediaMessage(m.quoted)
}
}
if (m.msg.url) m.download = () => Kyyhst.downloadMediaMessage(m.msg)
m.text = m.msg.text || m.msg.caption || m.message.conversation || m.msg.contentText || m.msg.selectedDisplayText || m.msg.title || ''
m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? Kyyhst.sendMedia(chatId, text, 'file', '', m, { ...options }) : Kyyhst.sendText(chatId, text, m, { ...options })
m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)))
m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => Kyyhst.copyNForward(jid, m, forceForward, options)

return m
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
