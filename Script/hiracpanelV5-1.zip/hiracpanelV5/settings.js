/*
#𝘗𝘵𝘦𝘳𝘰𝘹𝘪𝘴 𝘗𝘳𝘰𝘫𝘦𝘤𝘵!!
youtube : KeanuAaboxer
#Recode By xyzhiraa
https://whatsapp.com/channel/0029VaoNzzlJJhzQTJBL5n0F
*/

require("./all/module.js")
const { color } = require('./all/function')
const { version } = require("./package.json")
//========== Setting Owner ==========//
global.owner = "6285763800289"
global.owner2 = "6289518928221"
global.namaowner = "xyzhiraa!"
global.botname = "HiraCpanelV5"
//======== Setting Bot & Link ========//
global.namabot = "HiraCpanelV5" 
global.namabot2 = "HiraCpanelV5"
global.foother = "© - hira cpanel V5"
global.idsaluran = false
global.linkgc = 'https://chat.whatsapp.com/KM6AHNSG8J17HBFuqRG96T'
global.linksaluran = "https://whatsapp.com/channel/0029VaoNzzlJJhzQTJBL5n0F"
global.linkyt = 'https://youtube.com/@hiraazxd'
global.linktele = 'https://t.me/lynnzxd'
global.packname = "Hira Cpanel V5"
global.author = "𝖯𝗍𝖾𝗋𝗈𝗑𝗂𝗌 𝖠𝗅𝗅 𝖣𝖾𝗏"

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false
global.owneroff = false


//========== Setting Panel Server  1==========//
global.domain = "-" // ISI DOMAIN PANEL MU
global.apikey = "-" // ISI PLTA PANEL MU
global.capikey = "-" // ISI PLTC PANEL MU

//======== egg & loc biasanya sama jadi gausah ========//
global.egg = "15"
global.loc = "1"

//========= Setting Message =========//
global.msg = {
"error": "Maaf terjadi kesalahan..",
"done": "Succesfully ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar . . .", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})