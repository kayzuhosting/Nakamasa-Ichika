#include <stdio.h>

int main(void){
puts("Itsuka-Chan");
return 0;
}
