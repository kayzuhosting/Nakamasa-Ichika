let fetch = require('node-fetch')
let handler = async (m, { conn, text, usedPrefix, command }) => {
let tulisane = `Nih kak random ${command}`
if (command == 'futanari') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/futanari?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'cum') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/cum_jpg?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'eroyuri') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/eroyuri?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'hentai') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/hentai?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'femdom') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/femdom?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'pussy') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/pussy?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'lewdk') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/lewdk?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'feetg') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/feetg?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'solog') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/solog?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'erok') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/erok?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'kuni') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/kuni?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'tits') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/tits?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'holo') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/holo?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'gasm') { // stiker
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/gasm?apikey=${global.lolkey}`, 'gasm.webp', '', m, false, { asSticker: true })
}
if (command == 'ntrap') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/trap?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'yuri') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/yuri?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'feet') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/feet?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'hneko') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/neko?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'cum2') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random2/cum?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'biganimetiddies') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/biganimetiddies?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'lewdanimegirls') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/lewdanimegirls?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'hentaifemdom') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/hentaifemdom?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'animearmpits') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/animearmpits?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'booty') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/animebooty?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'animefeets') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/animefeets?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'oppai') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/sideoppai?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'hololewd') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/hololewd?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'ahegao') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/ahegao?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'rhentai') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/hentai?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'ecchi') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/ecchi?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'milf') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/milf?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'yaoi') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/yaoi?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'nblowjob') { // stiker 
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/blowjob?apikey=${global.lolkey}`, 'blowjob.webp', '', m, false, { asSticker: true })
}
if (command == 'ntrap2') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/trap?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'nloli') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/chiisaihentai?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'nloli2') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/loli?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'nloli3') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/loli?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'hwaifu') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/waifu?apikey=${global.lolkey}`, '', tulisane, m)
}
if (command == 'hneko2') {
conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/nsfw/neko?apikey=${global.lolkey}`, '', tulisane, m)
}
}

handler.command = handler.help = [
'nloli',
'nloli2',
'nloli3',
'cum',
'cum2',
'eroyuri',
'futanari',
'femdom',
'hentai',
'hneko2',
'hwaifu',
'ntrap',
'ntrap2',
'lewdk',
'pussy',
'femdom',
'erok',
'solog',
'feetg',
'holo',
'tits',
'kuni',
'yuri',
'gasm',
'hneko',
'feet',
'hentaifemdom',
'lewdanimegirls',
'biganimetiddies',
'animefeets',
'animearmpits',
'booty',
'hololewd',
'oppai',
'ecchi',
'rhentai',
'ahegao',
'yaoi',
'milf']
handler.tags = ['18+']
handler.limit = 10

module.exports = handler