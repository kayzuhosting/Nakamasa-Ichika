//SC BY REINZZID VyL
// © BY ReinzzID Vyl 2022 - 2025
//JANGAN HAPUS CREDITS!! HAPUS? = GW ENC SEMUA!! 

# MAHIRU - MD // Ryuu Reinzz  
Mahiru - MD adalah bot WhatsApp berbasis **Baileys** yang memiliki berbagai fitur keren buat memudahkan hidup lo!  

## 🔹 **Group Room Chat Mahiru:** [Klik Disini](https://chat.whatsapp.com/DyBYRT6G7aJ63bHwhNzHYb)  
//JAN DIUBAH

## Fitur Utama  

✅ **𝙂𝙍𝙊𝙐𝙋 𝙈𝙀𝙉𝙐** (Welcome, Anti-link, Auto Close Group)  
✅ **𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 𝙈𝙀𝙉𝙐** (YouTube, TikTok DLL)  
✅ **𝙎𝙏𝙄𝘾𝙆𝙀𝙍 & 𝙈𝙀𝘿𝙄𝘼** (Convert ke stiker, brat image/video)  
✅ **𝙁𝙐𝙉 𝙈𝙀𝙉𝙐 & 𝙍𝙋𝙂** (KERJA, CRAFT, BANKCEK DLL)  
✅ **𝙄𝙎𝙇𝘼𝙈𝙄 𝙈𝙀𝙉𝙐** (PENGINGAT ADZAN, PENGINGAT SHOLAT, AUTO ADZAN DLL)
#WAJIB 𝐁𝐀𝐂𝐀 !!
Edit file `settings.js` sebelum menjalankan bot:  

```---    settings.js
global.ownername = "Ryuu Reinzz"
global.botname = "Mahiru - Assistant"
global.ownernumber = "6288246552068"
global.idSaluran = "120363393200270830@newsletter"
```  

## 𝙂𝘼𝘽𝙐𝙉𝙂 𝙆𝙊𝙈𝙐𝙉𝙄𝙏𝘼𝙎 REINZZ 𝘾𝙃𝙓

🔹 **𝙂𝙍𝙊𝙐𝙋 𝘾𝙃𝘼𝙏** [Klik Disini](https://chat.whatsapp.com/DyBYRT6G7aJ63bHwhNzHYb)  
🔹 **𝘾𝙃𝘼𝙉𝙉𝙀𝙇 𝙊𝙍𝙄 REINZZ** [Klik Disini](https://whatsapp.com/channel/0029Vb5xetZBadmS2IPdmG1X)  
#DILARANG HAPUS CREDITS 
#footer '© ReinzzID VyL | Mahiru - Assistant'