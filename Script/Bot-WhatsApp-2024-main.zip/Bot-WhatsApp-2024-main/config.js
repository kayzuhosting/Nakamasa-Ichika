/* <============== CREDITS ==============>
Author: @berkahesport.id
Contact me: 62895375950107

Do not delete the source.
Thanks you...
*/
export default {
        settings: {
            prefix: ".",
            session: "auth_session",
            store: false // using store
        },
        name: {
            bot: "ʙᴇʀᴋᴀʜᴇꜱᴘᴏʀᴛ.ɪᴅ",
            owner: "@moexti"
        },
        number: {
            bot: "", // If you want
            mods: ["62895375950107"],
            owner: "62895375950107"
        },
        group: {
            ofc: "https://chat.whatsapp.com/JKdIWr5fj990Ux2oqTjTo5"
        },
        text: {
            ty: "Hopefully this is useful, don't forget to support and subscribe to the BERKAHESPORT.ID YouTube channel at _https://youtube.com/@berkahesportid_. Thank you 😊."
        },
        Exif: { // For sticker
            packId: "https://moexti.jw.lt/",
            packName: `ʙᴇʀᴋᴀʜᴇꜱᴘᴏʀᴛ.ɪᴅ\nChatBOT: 6289649672623`,
            packPublish: "Thank's to:\nAllah S.W.T",
            packEmail: "berkahesport@gmail.com",
            packWebsite: "https://moexti.jw.lt/",
            androidApp: "https://play.google.com/store/apps/details?id=com.bitsmedia.android.muslimpro",
            iOSApp: "https://apps.apple.com/id/app/muslim-pro-al-quran-adzan/id388389451?|=id",
            emojis: [],
            isAvatar: 0,
        }
}
