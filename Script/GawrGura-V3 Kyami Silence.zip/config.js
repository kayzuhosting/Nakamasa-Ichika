global.owner = ['6285167249152']  
global.mods = ['6285167249152'] 
global.prems = ['6285167249152']
global.nameowner = 'Kyami Silence'
global.namecreator = 'Kyami Silence'
global.namebot = 'GawrGura V3'
global.numberowner = '6285167249152' 
global.mail = '@slnckyami' 
global.gc = 'https://whatsapp.com/channel/0029VanWleP0lwghgX4Iib2D'
global.instagram = 'https://instagram.com/'
global.wm = '© Kyami Silence'
global.wait = '_*Tunggu sedang di proses...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'
global.packname = 'Made With'
global.author = 'Kyami Silence'
global.autobio = false // Set true untuk mengaktifkan autobio
global.maxwarn = '3' // Peringatan maksimum
global.antiporn = true // Auto delete pesan porno (bot harus admin)

global.my = {
	yt: 'https://youtube.com/@slnckyami',
	gh: 'Kyami Silence',
	gc: 'https://chat.whatsapp.com/Fg7lZNth6WPCkTmxfNzvdh',
	ch: '120363366790950043@newsletter',
}
//INI WAJIB DI ISI!//
global.btc = 'tnUW4mZs' 
//Daftar terlebih dahulu https://api.botcahx.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.lann = 'apikey'
//Daftar https://api.betabotz.eu.org 

//jangan diganti!
global.APIs = {   
  btc: 'https://api.botcahx.eu.org'
}

//ini tidak di isi juga tidak apa-apa
global.APIKeys = { 
  'https://api.botcahx.eu.org': 'tnUW4mZs' 
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
