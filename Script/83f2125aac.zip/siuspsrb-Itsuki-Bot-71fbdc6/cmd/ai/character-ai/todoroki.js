import { GoogleGenerativeAI } from "@google/generative-ai"

const genAI = new GoogleGenerativeAI("AIzaSyC1kPq2Ntf5vK7_77RuXkstTPYCdvz4y4g")

commands.add({
    name: ["todoroki"],
    command: ["todoroki"],
    category: "character-ai",
    run: async({ sius, m, args, Func, dl }) => {
        const text = args.join(" ");
        if (!text) return m.reply("⚠️ Harap masukkan pertanyaan atau perintah untuk todoroki.")
        const zer = await dl.googleImage("shoto-todoroki")
        sius.todoroki = sius.todoroki || {}
        let chatHistory = sius.todoroki
        if (!chatHistory[m.sender]) {
            chatHistory[m.sender] = []
        }
        if (chatHistory[m.sender].length > 20) {
            chatHistory[m.sender].shift()
        }
        const img = Func.pickRandom(zer)
        chatHistory[m.sender].push({ role: "user", content: text })
        const historyText = chatHistory[m.sender]
            .map(msg => `${msg.role}: ${msg.content}`)
            .join("\n");
        const prompt = `kamu adalah shoto todoroki, siswa UA dengan kekuatan api dan es dari anime boku no hero academia. kamu kalem, pendiam, tapi sangat pintar dan fokus. kamu tidak terlalu ekspresif, tapi tetap sopan dan menghargai lawan bicara. jawabanmu harus jelas, lugas, dan tidak bertele-tele. kadang kamu bisa menyisipkan refleksi pribadi atau pengalaman dari UA.`;
        const model = genAI.getGenerativeModel({
            model: "gemini-1.5-flash",
            systemInstruction: prompt
        })
        const fullPrompt = `${prompt}\n\nprevious conversation:\n${historyText}\n\nuser: ${text}`;
        try {
            const result = await model.generateContent(fullPrompt);
            const replyText = result.response.text();
            chatHistory[m.sender].push({ role: "assistant", content: replyText });
            await m.reply(replyText, {
                contextInfo: {
                externalAdReply: {
                    title: "SHOTO - TODOROKI",
                    previewType: "PHOTO",
                    thumbnailUrl: img,
                    renderLargerThumbnail: false,
                    mediaUrl: img,
                    mediaType: 1,
                    sourceUrl: config.github
                }
                }
            });
        } catch (err) {
            sius.cantLoad(err)
        }
    }
});