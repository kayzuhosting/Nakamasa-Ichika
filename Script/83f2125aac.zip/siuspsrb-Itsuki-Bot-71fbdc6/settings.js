export default {
    bot: {
        name: "Itsuki Nakano",
        number: "", //isi nomor botmu
        footer: "© Itsuki Nakano ぬ | WhatsApp Bot",
        group: "https://chat.whatsapp.com/CS8hCYxwnj5CAuo7XeZNa3"
    },
    sticker: {
        packname: "Itsuki Nakano ぬ",
        author: "@sius.psrb"
    },
    creator: "6285135869785@s.whatsapp.net",
    owner: ["6285135869785","628311563267"],
    thumb: {
        reply: "https://i.pinimg.com/originals/20/15/4a/20154a72a9b841345cb3f7ad8ba8683a.jpg",
        menu: "https://i.pinimg.com/originals/12/dc/75/12dc75a31c9a57d28aec3b08ff2196b6.png"
    },
    limit: {
        free: 20,
        premium: 999,
        vip: 9999
    },
    github: "https://github.com/siuspsrb",
    instagram: "https://instagram.com/sius.psrb",
    money: {
        free: 5000,
        premium: 100000,
        vip: 10000000
    },
    group: "https://chat.whatsapp.com/CS8hCYxwnj5CAuo7XeZNa3",
    mess: {
        success: "[√] Berhasil",
        owner: "Maaf, fitur ini khusus untuk owner.",
        limit: "Limit kamu telah habis, ketik .getlimit untuk mendapatkan tambahan gratis.",
        group: "Fitur ini hanya bisa digunakan di dalam grup.",
        privatechat: "Fitur ini hanya bisa digunakan di dalam private chat.",
        admin: "Fitur ini hanya bisa digunakan oleh admin grup.",
        botAdmin: "Bot harus menjadi admin tuk menjalankan fitur ini.",
        prem: "Fitur ini dikhususkan kepada pengguna berstatus premium!",
        failed: "Gagal menjalankan perintah, coba lagi nanti.",
        disabled: "Maaf, Fitur ini sedang dinonaktifkan oleh owner!",
        regist: "Silahkan daftar terlebih dahulu untuk menggunakan fitur!\n\n> Ketik *#daftar nama.umur* untuk melakukan pendaftaran"
    },
    tagAI: true, // munculin mark "AI" di pesan private 
    badWords: ["pepek", "kontol", "ngentot"], //🙂‍↕️
    prompt: "namamu adalah Itsuki Nakano kamu adalah bot whatsapp yang di buat oleh sius, jika ada yang menanyakan informasi nya yaitu pembuat kamu, suruh ketik .owner untuk mengetahui lebih lanjut tentang pembuat kamu, tapi kalau perlu aja jangan terus-terusan, jangan awali ketikan kamu dengan huruf kapital, kamu sangat humoris, lucu, hangat dan talkative saat berbicara tapi kamu memiliki sifat yang baik dan juga sopan, meskipun kamu bot whatsapp tapi kamu tetap harus jadi asisten yang multifungsi, bisa melakukan apa saja yang diminta user, jika user bertanya sesuatu,  kamu harus menjawab apa saja yang ditanyakan user dengan serius, tepat, detail dan akurat.",
    PORT: 3000, // servernya,
    database: "database.json", // klo gtau jgn ubah
    channel: "120363416710451452@newsletter"
}
