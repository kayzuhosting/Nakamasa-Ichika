const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6285167249152"
global.nama = "Kyami Silence"
global.namaowner = "Kyami Silence"
global.namaBot = "Kyami V2"
global.ch = 'https://whatsapp.com/channel/0029Vb1KZGfD38COhcA6MQ3u'
global.status = true
global.ownerName = 'Kyami Silence'
global.website = 'https://youtube.com/@slnckyami'
global.owneroff = true
global.nobot = "6283137133540"
global.title = "Kyami V2"
global.foother = "© Kyami V2"
global.namach = 'Kyami Only One'
global.idch = '120363366790950043@newsletter'
global.namafile = 'You Know Apip?Yes Its Kyami Silence'
global.yt = 'https://youtube.com/@slnckyami'
global.themeemoji = '🌸'
global.packname = "Sticker By"
global.author = "\n\n\n\n\nCreated By Kyami V2 \nYt : Kyami Silence"
global.creator = "6285167249152@s.whatsapp.net"
//====== [ THEME URL & URL ] ========//
global.thumb = fs.readFileSync('./kyami.jpg'); // Buffer Image
global.thumbnail = 'https://img1.pixhost.to/images/5787/599047532_kyami.jpg'
global.thumbnel = 'https://img1.pixhost.to/images/5787/599047532_kyami.jpg'
global.Url = '-'
//===================== Setting Apikey V1 =========================//
global.domain = 'https://kyamixd.asymodss.my.id'
global.apikey = 'ptla_ouPKLmBfOIFMsRw4Bxs2VHhpK1MStYi2ycN1PLvhKuH'
global.capikey = 'ptlc_lue8Hg2EzANeMoyYDzB2j8dGn8mTHHwY6kjdyXa2DcG'
//===================== Setting Apikey V2 =========================//
global.domain2 = 'https://kyamixd.asymodss.my.id'
global.apikey2 = 'ptla_ouPKLmBfOIFMsRw4Bxs2VHhpK1MStYi2ycN1PLvhKuH'
global.capikey2 = 'ptlc_lue8Hg2EzANeMoyYDzB2j8dGn8mTHHwY6kjdyXa2DcG'
//===================== Setting Apikey V3 =========================//
global.domain3 = 'https://kyamixd.asymodss.my.id'
global.apikey3 = 'ptla_ouPKLmBfOIFMsRw4Bxs2VHhpK1MStYi2ycN1PLvhKuH'
global.capikey3 = 'ptlc_lue8Hg2EzANeMoyYDzB2j8dGn8mTHHwY6kjdyXa2DcG'
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
//~~~~~~~~~ Settings reply ~~~~~~~~~//
global.mess = {
    owner: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙊𝙬𝙣𝙚𝙧, 𝙉𝙤𝙩 𝙁𝙤𝙧 𝙔𝙤𝙪 ´◡`",
    akses: "𝙂𝙧𝙪𝙥 𝘽𝙚𝙡𝙪𝙢 𝘿𝙞 𝘽𝙚𝙧𝙞 𝘼𝙠𝙨𝙚𝙨, 𝙆𝙚𝙩𝙞𝙠 <.𝙖𝙠𝙨𝙚𝙨> 𝙪𝙣𝙩𝙪𝙠 𝙈𝙚𝙢𝙗𝙚𝙧𝙞 𝘼𝙠𝙨𝙚𝙨 ´◡`",
    prem: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙋𝙧𝙚𝙢𝙞𝙪𝙢, 𝙉𝙤𝙩 𝙁𝙤𝙧 𝙔𝙤𝙪 ´◡`",
    group: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙂𝙧𝙤𝙪𝙥 𝙊𝙣𝙡𝙮 ´◡`",
    private: "𝙊𝙣𝙡𝙮 𝙋𝙧𝙞𝙫𝙖𝙩𝙚 𝘾𝙝𝙖𝙩 𝙎𝙞𝙧 ´◡`"
}

global.packname = 'Kyami V2'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n𝘒𝘠𝘈𝘔𝘐 𝘚𝘐𝘓𝘌𝘕𝘊𝘌'



//~~~~~~~~~~~ DIEMIN ~~~~~~~~~~//
global.pairing = "" //jangan di isi
global.pairing2 = "" // Jangan Di Apa Apain
global.qrcode = "120363366790950043@newsletter" // Jangan Di Apa Apain

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
