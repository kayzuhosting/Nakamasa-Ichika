let handler = async (m, { conn }) => {
    let url = global.API('xteam', '/asupan/darkjoke', {}, 'APIKEY')
    await conn.sendFile(m.chat, url, '', '', m, 0, { thumbnail: await (await fetch(url)).buffer() })
}
handler.help = ['darkjoke']
handler.tags = ['internet']
handler.command = /^((drag|dark)joke)$/i

module.exports = handler
