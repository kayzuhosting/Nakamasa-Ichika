/*

 * Created By KyyXD
 * Base : Dpt Dr Pengikut Ceha
 * Whatsapp : 6288286624778
 * Chanel : https://whatsapp.com/channel/0029Vb7gTNO5a2450z5MnD0k
 
*/

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ SETTINGS OWNER ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ \\
global.owner = ["6288286624778"]
global.ownerName = "Kyy"
global.fother = "Akame × Kyy"
global.packname = 'Stick By'
global.author = 'Kyy\nAkame'

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ SETTINGS BOT ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.namabot = "Akame"
global.baileys = "@fizzxydev/baileys-pro"
global.self = false
global.public = true
global.nomorbot = "6288287134883"
global.version = "4.0.0"
global.autoread = true
global.autotyping = true
global.wlcm = []
global.wlcmm = []

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ SETTINGS IMAGE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ \\
global.warn = "https://img12.pixhost.to/images/1490/584818417_6726.jpg"
global.qris = "https://files.catbox.moe/bb3hfw.jpg"
global.thumblist = "https://img1.pixhost.to/images/5640/596847853_ikyjs.jpg"
global.thumb = "https://img1.pixhost.to/images/5455/594473518_ikyjs.jpg"

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ SETTINGS CPANEL ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ \\
global.egg = "15"
global.nestid = "5"
global.loc = "1"
global.domain = "https://arthazy-salvador.cloudly.fun"//domain
global.apikey = "ptla_vt5PTG7u6hh1YdDt8rB2SuZSHNSeIGEIS15qqnn9j78"//plta
global.capikey = "ptlc_6nGMJ8o0iQXwRs3TfAUtw9m1AGlmjnTyvA7tnrMtggs"//pltc

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ SETTINGS API ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ \\
global.qriscode = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214103107926384650303UMI51440014ID.CO.QRIS.WWW0215ID20253865335610303UMI5204481253033605802ID5920LUKMANUL%20C%20OK23344206005BOGOR61051611062070703A01630434EA" // Generate Di ReadQR
global.kyyapi = " " // Buy Aja Di 6288286624778 https://restapi.kyyapiz.biz.id/
global.merchan = " " // Ambil di okeconnect
global.keyorkut = " " // Ambil Di Okeconnect

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ SETTINGS ALL INFO ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ \\
global.website = "https://chat.whatsapp.com/KM6AHNSG8J17HBFuqRG96T"
global.idch = ['120363335989645846@newsletter'] 
global.ceha = "https://whatsapp.com/channel/0029VaoNzzlJJhzQTJBL5n0F"
global.linkgc = "https://chat.whatsapp.com/KM6AHNSG8J17HBFuqRG96T"
global.yt = "https://www.youtube.com/@hiraazxd"


// MESSEGAE BOTZ SETTING = JANGAN DI OTAK ATIK \\
global.mess = {
    success: 'sᴜᴄᴄᴇssғᴜʟʏ',
    admin: '[ !! ] *sʏsᴛᴇᴍ*\nᴋʜᴜsᴜs ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ',
    botAdmin: '[ !! ] *sʏsᴛᴇᴍ*\nᴀᴋᴀᴍᴇ ʙᴇʟᴜᴍ ᴊᴀᴅɪ ᴀᴅᴍɪɴ',
    creator: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ɪɴɪ ᴋʜᴜsᴜs ᴋʏʏ ᴅᴏᴀɴᴋ',
    group: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ɪɴᴜ ᴋʜᴜsᴜs ɢʀᴏᴜᴘ ᴀᴊᴀ',
    private: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ ᴀᴋᴀᴍᴇ',
    wait: '[ !! ] *sʏsᴛᴇᴍ*\nᴡᴀɪᴛ ᴀᴋᴀᴍᴇ ᴘʀᴏsᴇs ᴅᴜʟᴜ',
    notregist: 'ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴛᴇʀᴅᴀғᴛᴀʀ ᴅɪ ᴅᴀᴛᴀʙᴀsᴇ ᴀᴋᴀᴍᴇ sɪʟᴀʜᴋᴀɴ ᴅᴀғᴛᴀʀ ᴅᴇɴɢᴀɴ ᴄᴀʀᴀ\n\n.ᴅᴀғᴛᴀʀ ɴᴀᴍᴀ,ᴜᴍᴜʀ\n.ᴅᴀғᴛᴀʀ ᴋʏʏ.𝟸𝟶',
    premium: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ ᴀᴋᴀᴍᴇ',
    endLimit: '[ !! ] *sʏsᴛᴇᴍ*\nʟɪᴍɪᴛ ᴀɴᴅᴀ ʜᴀʙɪs ,, ᴀᴋᴀɴ ᴅɪ ʀᴇsᴇᴛ sᴇᴛᴇʟᴀʜ sᴇʜᴀʀɪ',
}


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ SETTINGS LIMITZ ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ //
global.limitawal = {
    premium: "Infinity",
    free: 30
}


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ SETTINGS RPG ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ \\
global.rpg = {
emoticon(string) {
string = string.toLowerCase()
let emot = {
level: '📊',
limit: '🎫',
health: '❤️',
exp: '✨',
atm: '💳',
money: '💰',
bank: '🏦',
potion: '🥤',
diamond: '💎',
common: '📦',
uncommon: '🛍️',
mythic: '🎁',
legendary: '🗃️',
superior: '💼',
pet: '🔖',
trash: '🗑',
armor: '🥼',
sword: '⚔️',
pickaxe: '⛏️',
fishingrod: '🎣',
wood: '🪵',
rock: '🪨',
string: '🕸️',
horse: '🐴',
cat: '🐱',
dog: '🐶',
fox: '🦊',
robo: '🤖',
petfood: '🍖',
iron: '⛓️',
gold: '🪙',
emerald: '❇️',
upgrader: '🧰',
bibitanggur: '🌱',
bibitjeruk: '🌿',
bibitapel: '☘️',
bibitmangga: '🍀',
bibitpisang: '🌴',
anggur: '🍇',
jeruk: '🍊',
apel: '🍎',
mangga: '🥭',
pisang: '🍌',
botol: '🍾',
kardus: '📦',
kaleng: '🏮',
plastik: '📜',
gelas: '🧋',
chip: '♋',
umpan: '🪱',
skata: '🧩'
}
let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
if (!results.length) return ''
else return emot[results[0][0]]
}
}

// SETTING GAME
global.gamewaktu = 60 // Game waktu

// DATABASE GAME
global.suit = {};
global.tictactoe = {};
global.petakbom = {};
global.kuis = {};
global.siapakahaku = {};
global.asahotak = {};
global.susunkata = {};
global.caklontong = {};
global.family100 = {};
global.tebaklirik = {};
global.tebaklagu = {};
global.tebakgambar2 = {};
global.tebakkimia = {};
global.tebakkata = {};
global.tebakkalimat = {};
global.tebakbendera = {};
global.tebakanime = {};
global.kuismath = {};


let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})