/*
ɪɴɪ ʙᴀsᴇ ʏᴀ ɪsɪ ᴍᴇɴᴜ ᴋᴀʟɪᴀɴ ᴊᴀɴɢᴀɴ ᴍᴀɴᴊᴀ*/
require('./settings');
const fs = require('fs');
const util = require('util')
const { exec } = require("child_process")

module.exports = async (Usztzy, m) => {
try {
const body = (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) ? (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) : '';

const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (Usztzy.user.id.split(':')[0]+'@s.whatsapp.net' || Usztzy.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await Usztzy.decodeJid(Usztzy.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)

//~~~~~Fitur Case~~~~~//
switch(command) {
case "menu": {
let teksnya = `
ʟɪsᴛ ᴍᴇɴᴜ 
ʙᴜɢ👾
ᴅʟᴀʏᴠɪʙᴇʟ☠️
ʙᴜɢ-ɢʀᴏᴜᴘ
ᴅʟᴀʏɪɴᴠɪs
ᴛʀᴀᴠᴀsᴛᴢʏ
`;

  await Usztzy.sendMessage(m.chat, {
    footer: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴛʀᴀᴠᴀsᴛᴢʏ`,
    image: { url: 'https://img1.pixhost.to/images/6243/607336307_erlangga.jpg' },
    caption: teksnya,
  }, { quoted: text });
}
break;

default:
}
} catch (err) {
console.log(util.format(err))
}
}

//~~~~~Status Diperbarui~~~~~//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
